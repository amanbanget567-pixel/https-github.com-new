package com.cbt.helper;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#121212"));
        layout.setGravity(Gravity.CENTER);

        TextView logo = new TextView(this);
        logo.setText("🤖");
        logo.setTextSize(80);
        logo.setGravity(Gravity.CENTER);
        
        ScaleAnimation pulse = new ScaleAnimation(1f, 1.1f, 1f, 1.1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        pulse.setDuration(1000);
        pulse.setRepeatMode(Animation.REVERSE);
        pulse.setRepeatCount(Animation.INFINITE);
        logo.startAnimation(pulse);

        TextView title = new TextView(this);
        title.setText("CBT HELPER AI");
        title.setTextColor(Color.parseColor("#BB86FC"));
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 20, 0, 50);

        Button btnStart = new Button(this);
        btnStart.setText("PILIH MODE");
        btnStart.setTextColor(Color.WHITE);
        btnStart.setBackgroundColor(Color.parseColor("#3700B3"));
        btnStart.setOnClickListener(v -> {
            String[] modes = {"Mode Teks (Ketik Soal)", "Mode Layar (Bot Melayang)"};
            new AlertDialog.Builder(this)
                    .setTitle("Pilih Mode Bot")
                    .setItems(modes, (dialog, which) -> {
                        if (which == 0) startActivity(new Intent(MainActivity.this, TextModeActivity.class));
                        else startActivity(new Intent(MainActivity.this, ScreenModeActivity.class));
                    }).show();
        });

        layout.addView(logo);
        layout.addView(title);
        layout.addView(btnStart);
        setContentView(layout);
    }
}