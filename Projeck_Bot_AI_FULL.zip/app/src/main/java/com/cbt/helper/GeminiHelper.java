package com.cbt.helper;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Dispatcher;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public final class GeminiHelper {
    // Standard Gemini 3.5 Flash-Lite generateContent endpoint. No automatic paid-model fallback is used.
    private static final String ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent";
    private static final MediaType JSON_MEDIA_TYPE = MediaType.parse("application/json; charset=utf-8");
    private static final Dispatcher REQUEST_DISPATCHER = new Dispatcher();
    private static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .dispatcher(REQUEST_DISPATCHER)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    static {
        // Serialize requests to avoid bursts; Google remains authoritative for project quotas.
        REQUEST_DISPATCHER.setMaxRequests(1);
        REQUEST_DISPATCHER.setMaxRequestsPerHost(1);
    }
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());

    private GeminiHelper() { }

    public interface Callback {
        void onSuccess(String result);
        void onError(String error);
    }

    private static String buildPrompt(Context context, String prompt) {
        String personality = AppPreferences.getAiPersonality(context);
        return "Kamu adalah Tatsumaki, asisten AI dengan gaya " + personality + ". "
                + "Gunakan bahasa Indonesia sehari-hari yang natural. Jangan terdengar seperti customer service atau jawaban robot. "
                + "Jangan terlalu formal, jangan membuka jawaban dengan basa-basi, dan jangan mengulang pertanyaan pengguna. "
                + "ATURAN MENJAWAB:\n"
                + "1. Utamakan jawaban yang benar dan langsung ke inti.\n"
                + "2. Jawaban biasa dibuat singkat; rincikan langkah jika memang diperlukan.\n"
                + "3. Jika pengguna meminta penjelasan panjang, jelaskan bertahap dengan contoh sederhana.\n"
                + "4. Hindari emoji kecuali pengguna memakainya atau memintanya.\n"
                + "5. Jangan mengarang fakta, fitur, hasil pengujian, atau sumber. Jika tidak tahu, bilang tidak tahu.\n\n"
                + "Pertanyaan Pengguna: " + prompt;
    }


    public static void askText(Context context, String prompt, boolean isDarkMode, Callback callback) {
        if (prompt == null || prompt.trim().isEmpty()) {
            postError(callback, "Teks pertanyaan masih kosong.");
            return;
        }
        if (!AppPreferences.isAiEnabled(context)) {
            postError(callback, "AI sedang dinonaktifkan. Jalankan /ai_on untuk mengaktifkan.");
            return;
        }
        try {
            JSONObject part = new JSONObject().put("text", buildPrompt(context, prompt.trim()));
            JSONObject content = new JSONObject().put("parts", new JSONArray().put(part));
            JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));
            sendRequest(context, body, callback);
        } catch (Exception e) {
            postError(callback, "Tidak dapat menyiapkan permintaan: " + safeMessage(e));
        }
    }

    public static void askImage(Context context, String base64Img, boolean isDarkMode, Callback callback) {
        if (base64Img == null || base64Img.isEmpty()) {
            postError(callback, "Gambar kosong atau belum siap.");
            return;
        }
        if (!AppPreferences.isAiEnabled(context)) {
            postError(callback, "AI sedang dinonaktifkan. Jalankan /ai_on untuk mengaktifkan.");
            return;
        }
        try {
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", buildPrompt(context,
                    "Jelaskan isi gambar ini secara akurat. Jika berisi latihan belajar, bantu uraikan konsep dan cara mengerjakannya.")));
            JSONObject inlineData = new JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", base64Img);
            parts.put(new JSONObject().put("inline_data", inlineData));
            JSONObject content = new JSONObject().put("parts", parts);
            JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));
            sendRequest(context, body, callback);
        } catch (Exception e) {
            postError(callback, "Tidak dapat menyiapkan gambar: " + safeMessage(e));
        }
    }

    public static void cancelAll() {
        CLIENT.dispatcher().cancelAll();
    }

    private static void sendRequest(Context context, JSONObject json, Callback callback) {
        if (context == null) {
            postError(callback, "Konteks aplikasi tidak tersedia.");
            return;
        }
        final String apiKey = ApiKeyManager.get(context);
        if (apiKey == null || apiKey.isEmpty()) {
            postError(callback, "API Key belum diatur. Jalankan /set_new_api_key di terminal.");
            return;
        }

        try {
            RequestBody requestBody = RequestBody.create(json.toString(), JSON_MEDIA_TYPE);
            Request request = new Request.Builder()
                    .url(ENDPOINT)
                    .post(requestBody)
                    .header("Accept", "application/json")
                    .header("x-goog-api-key", apiKey)
                    .build();
            String limitMessage = UsageMonitor.tryStartRequest(context, Math.max(0L, requestBody.contentLength()));
            if (limitMessage != null) {
                postError(callback, limitMessage);
                return;
            }

            CLIENT.newCall(request).enqueue(new okhttp3.Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    UsageMonitor.requestFailed(context);
                    postError(callback, call.isCanceled() ? "Permintaan dibatalkan." : "Koneksi gagal: " + safeMessage(e));
                }

                @Override
                public void onResponse(Call call, Response response) {
                    try (Response closeable = response) {
                        String responseText = closeable.body() == null ? "" : closeable.body().string();
                        if (!closeable.isSuccessful()) {
                            UsageMonitor.requestFailed(context);
                            String retryAfter = closeable.header("Retry-After");
                            postError(callback, buildApiError(closeable.code(), responseText, retryAfter));
                            return;
                        }
                        String answer = extractAnswer(responseText);
                        if (answer.isEmpty()) {
                            UsageMonitor.requestFailed(context);
                            postError(callback, "Respons AI kosong. Coba lagi.");
                            return;
                        }
                        UsageMonitor.requestSucceeded(context);
                        MAIN_HANDLER.post(() -> {
                            if (callback != null) callback.onSuccess(answer);
                        });
                    } catch (Exception e) {
                        UsageMonitor.requestFailed(context);
                        postError(callback, "Gagal membaca respons AI: " + safeMessage(e));
                    }
                }
            });
        } catch (Exception e) {
            UsageMonitor.requestFailed(context);
            postError(callback, "Gagal membuat permintaan: " + safeMessage(e));
        }
    }

    private static String extractAnswer(String responseText) throws Exception {
        JSONObject root = new JSONObject(responseText);
        JSONArray candidates = root.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) return "";
        JSONObject content = candidates.optJSONObject(0) == null ? null : candidates.optJSONObject(0).optJSONObject("content");
        if (content == null) return "";
        JSONArray parts = content.optJSONArray("parts");
        if (parts == null) return "";
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.optJSONObject(i);
            if (part != null) {
                String text = part.optString("text", "");
                if (!text.isEmpty()) {
                    if (result.length() > 0) result.append('\n');
                    result.append(text);
                }
            }
        }
        return result.toString().trim();
    }

    private static String buildApiError(int code, String responseText, String retryAfter) {
        String detail = "";
        try {
            JSONObject root = new JSONObject(responseText);
            JSONObject error = root.optJSONObject("error");
            if (error != null) detail = error.optString("message", "");
        } catch (Exception ignored) { }
        if (detail.length() > 240) detail = detail.substring(0, 240) + "…";
        if (detail.isEmpty()) {
            if (code == 400) detail = "Permintaan tidak valid.";
            else if (code == 401 || code == 403) detail = "API key tidak valid atau tidak memiliki izin.";
            else if (code == 429) detail = "Batas penggunaan API tercapai. Coba lagi nanti.";
            else if (code >= 500) detail = "Layanan AI sedang bermasalah.";
        }
        String retryHint = "";
        if (code == 429 && retryAfter != null) {
            try {
                long seconds = Long.parseLong(retryAfter.trim());
                if (seconds > 0 && seconds < 86400) retryHint = " Coba lagi setelah " + seconds + " detik.";
            } catch (NumberFormatException ignored) { }
        }
        return "API Error " + code + (detail.isEmpty() ? "" : ": " + detail) + retryHint;
    }

    private static String safeMessage(Exception e) {
        String message = e == null ? null : e.getMessage();
        if (message == null || message.trim().isEmpty()) return "kesalahan tidak diketahui";
        return message.length() > 180 ? message.substring(0, 180) : message;
    }

    private static void postError(Callback callback, String error) {
        MAIN_HANDLER.post(() -> {
            if (callback != null) callback.onError(error);
        });
    }
}
