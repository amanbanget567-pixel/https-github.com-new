# Tatsumaki AI / CBT Helper — Android Studio Project

Versi sumber: **1.1.2**.

Project ini mempertahankan aset, floating bot, Text Mode, sesi screen capture berbasis izin Android, API Key Manager terenkripsi, diagnostics, usage monitor, dan command router sambil merapikan halaman utama sesuai desain terminal. Pembaruan 1.1.2 memusatkan halaman utama pada terminal, memindahkan pengelolaan API Key ke command, menambahkan PIN opsional dan AI Control, serta memperbaiki statistik penggunaan dan navigasi command.

## Fitur yang tersedia

- Halaman utama menggunakan tampilan terminal hitam-hijau monospaced dengan judul `TATSUMAKI TERMINAL`, satu command awal `[1] /Listcommaind`, dan prompt `>`. Command lain baru ditampilkan setelah `/Listcommaind` dipanggil.
- Welcome/Copyright tidak ditampilkan di halaman utama; judul terminal tetap.
- API Key Manager hanya dapat dioperasikan melalui command terminal, bukan panel Settings.
- Floating bot dengan animasi, menu, kontrol transparansi, dan posisi yang bisa dipindahkan.
- Screen Assist menggunakan MediaProjection setelah persetujuan Android dan foreground service yang terlihat oleh sistem.
- Scan manual dan Auto Scan yang hanya mulai setelah pengguna menyalakannya. Interval Auto Scan adalah 15 detik; permintaan diserialkan melalui antrean OkHttp dan kuota resmi tetap ditentukan Google.
- Text Mode dan input teks melalui floating bot.
- API Key Manager dengan AES/GCM dan kunci enkripsi yang disimpan di Android Keystore.
- System Diagnostics melalui command untuk status API, overlay, notifikasi, jaringan, service, projection, RAM, storage, CPU/ABI, uptime, dan versi.
- Usage Monitor lokal untuk jumlah request, berhasil/gagal, perkiraan byte terkirim, statistik hari/bulan, dan waktu request terakhir. Kuota resmi tetap mengikuti project Google AI Studio; tidak ada angka kuota lokal yang diklaim sebagai kuota Google.
- AI Control melalui command untuk mengaktifkan/menonaktifkan AI, melihat model/status, mengubah gaya persona, dan membatalkan request aktif.
- Floating Bot dapat ditampilkan/disembunyikan dan posisinya direset melalui command saat sesi aktif.
- PIN aplikasi opsional (default OFF), diaktifkan/diubah/dimatikan dari menu Security Settings (ikon ⋮ di header terminal, bukan command); PIN diverifikasi menggunakan hash PBKDF2 salted, bukan plaintext.
- Terminal dengan perintah allowlist; tidak menjalankan shell bebas.
- Accessibility Text Assist nonaktif secara default dan hanya bekerja setelah pengguna mengaktifkan sakelar pada Security Settings serta mengaktifkan Accessibility Service Android.
- Screenshot protection menggunakan `FLAG_SECURE` pada Activity milik Tatsumaki dan pada window Floating Bot. Perilaku overlay perlu diuji pada perangkat Android karena implementasi OEM dapat berbeda; ini tidak menyembunyikan konten aplikasi lain.

## Gemini API dan Free Tier

Aplikasi menggunakan endpoint `gemini-3.5-flash-lite:generateContent` (Gemini 3.5 Flash-Lite) untuk permintaan teks dan gambar. API key dikirim melalui header `x-goog-api-key`. Tidak ada fallback otomatis ke model lain atau model berbayar.

Gemini 3.5 Flash-Lite mencantumkan biaya input dan output standar **gratis pada Free Tier**. Pada Paid Tier, harga standar yang tercantum adalah USD 0,30 per 1 juta token input dan USD 2,50 per 1 juta token output; harga dapat berubah. Batas RPM, TPM, dan RPD ditentukan menurut project dan tingkat penggunaan; angka yang aktif harus dilihat di AI Studio. Batas request dihitung pada tingkat project, bukan per API key. Lihat dokumentasi resmi:

- Pricing: https://ai.google.dev/gemini-api/docs/pricing
- Rate limits: https://ai.google.dev/gemini-api/docs/rate-limits
- GenerateContent: https://ai.google.dev/api/generate-content

Aplikasi tidak memaksakan angka RPM/RPD lokal yang belum tentu cocok dengan project pengguna. Request dicatat oleh Usage Monitor, sementara batas RPM/TPM/RPD resmi diterapkan oleh Google pada tingkat project. Auto Scan memakai interval 15 detik untuk mengurangi intensitas request. Jika Google mengembalikan HTTP 429, aplikasi menampilkan batas penggunaan yang dikembalikan layanan; pengguna perlu menunggu sesuai kebijakan Google.

**Penting mengenai biaya:** kode aplikasi tidak bisa memaksa project Google tetap berada di Free Tier. Kalau project API key di AI Studio/Google Cloud ditautkan ke billing aktif atau dinaikkan ke tier berbayar, Google dapat menagih sesuai ketentuan project tersebut. Untuk benar-benar menghindari biaya, pastikan project tetap pada Free Tier dan jangan mengaktifkan billing. Saat kuota habis, aplikasi menampilkan error dan tidak mengganti model secara otomatis.

## Screenshot protection

Android tidak menyediakan API umum bagi aplikasi untuk mengganti isi screenshot sistem dengan tulisan buatan aplikasi. Karena itu, fitur tulisan khusus `YOU ARE IDIOT` **tidak diklaim sudah dibuat**. Versi ini memakai `FLAG_SECURE` sebagai fallback: Android akan menyembunyikan, menghitamkan, atau memblokir konten window yang dilindungi saat screenshot/screen recording, bergantung pada perangkat dan versi Android. Tidak ada manipulasi screenshot perangkat lain.

Perlindungan dipasang pada MainActivity, TextModeActivity, ScreenModeActivity, PinGateActivity, PinSettingsActivity, dan window Floating Bot. Window Floating Bot juga diberi `FLAG_SECURE`; Android dapat menyembunyikan window overlay tersebut, tetapi hasilnya harus diuji pada perangkat dan tidak menjamin isi aplikasi lain ikut hitam. Hasil akhirnya tetap perlu diuji pada perangkat Android sebenarnya.

## Ghost Mode

Mode yang memantau semua sentuhan global atau menyembunyikan floating bot secara otomatis tidak ditambahkan. Android tidak menyediakan listener sentuhan global biasa untuk aplikasi; pendekatan semacam itu memerlukan pemantauan Accessibility/overlay yang lebih invasif dan dapat menyamarkan overlay dari aplikasi lain. Fitur tersebut tidak boleh dianggap tersedia pada versi ini.

## Persyaratan build

- Android Studio yang mendukung Android Gradle Plugin 8.3.0.
- JDK 17.
- Android SDK Platform 34.
- Gradle 8.4 atau lebih baru yang kompatibel dengan Android Gradle Plugin 8.3.0.
- Perangkat Android minimum API 26.

**Catatan:** ZIP sumber tidak menyertakan Gradle Wrapper. Buka project dengan Android Studio, gunakan JDK 17 dan Android SDK Platform 34, lakukan Gradle Sync, lalu jalankan `assembleDebug`. Workflow GitHub Actions tersedia di `.github/workflows/android-build.yml`; setelah project didorong ke branch `main` atau workflow dijalankan manual, APK debug akan diunggah sebagai artifact `Tatsumaki-AI-debug-apk`. Build CI dan uji perangkat tetap harus benar-benar dijalankan sebelum menyatakan APK siap.

## Menyiapkan Gemini API

1. Buat atau pilih project di Google AI Studio.
2. Pastikan project menunjukkan **Free Tier** dan tidak ditautkan ke billing berbayar bila ingin menghindari biaya.
3. Buat API key sesuai petunjuk AI Studio.
4. Buka terminal Tatsumaki.
5. Ketik `/set_new_api_key`, lalu masukkan key pada baris berikutnya yang disamarkan.
6. Jika key lama sudah tersimpan, ketik `/confirm_change` sebelum memasukkan key baru; gunakan `/cancel` untuk membatalkan.
7. Jalankan `/check_api_key` atau `/diagnostics`, lalu uji permintaan teks dan gambar.

## Keamanan API key

- Nilai key yang sebelumnya tertanam dalam source telah dihapus dari source project ini.
- Penyimpanan Android Keystore melindungi key saat tersimpan di perangkat, tetapi bukan pengganti backend proxy dan tidak membuat key mustahil diekstrak dari perangkat yang telah dikompromikan.
- Jangan pernah mengirim ZIP yang berisi API key aktif.

## Screen capture dan lifecycle

- Setiap sesi capture meminta izin Android yang baru.
- Satu izin pengguna digunakan untuk satu sesi VirtualDisplay.
- `MediaProjection.Callback` didaftarkan sebelum `createVirtualDisplay()`.
- Service memakai `START_NOT_STICKY`; token MediaProjection tidak dipulihkan setelah proses dihentikan.
- Pengguna dapat menghentikan service melalui command `/stop` atau kontrol sistem Android.
- Auto Scan hanya dimulai setelah pengguna menyalakannya dari menu floating bot.

## Accessibility Services Android

Tatsumaki mendaftarkan dua layanan Accessibility opsional dengan nama dan deskripsi terpisah:

- **Tatsumaki AI - Bantuan Baca Teks (Auto Text):** ketika layanan Android ini aktif dan sakelar "Analisis teks otomatis" di Security Settings juga ON, service membaca hingga 6.000 karakter dari struktur aksesibilitas jendela aplikasi aktif dan mengirim teks tersebut ke Gemini untuk dianalisis. Struktur tersebut dapat memuat teks yang tidak sedang terlihat secara visual; kolom yang ditandai sebagai sandi oleh aplikasi dikecualikan.
- **Tatsumaki AI - Bantuan Interaksi (Auto KKM):** dapat membaca label teks dan elemen antarmuka yang dapat diakses, lalu mencoba mengetuk elemen yang cocok ketika fitur terkait di Tatsumaki memintanya.

Tatsumaki tidak mengaktifkan atau mengubah status layanan secara otomatis; status setiap layanan dikendalikan pengguna melalui Pengaturan Android. Sebelum membuka halaman sistem, Tatsumaki menampilkan penjelasan fungsi dan risiko privasi. Status masing-masing layanan ditampilkan di Security Settings dan dapat diperiksa melalui `/status_aksesibilitas` atau `/status`. Laporan `/diagnostics` juga menyertakan status tersebut.

Layanan ini umumnya muncul pada **Pengaturan Android > Aksesibilitas > Aplikasi terpasang/Downloaded apps** (nama menu dapat berbeda menurut perangkat), bukan sebagai izin runtime biasa di halaman **Info aplikasi > Izin**. Aktifkan hanya pada aplikasi dan data yang memang boleh dianalisis. Hindari data pribadi/rahasia dan nonaktifkan layanan atau sakelar aplikasi bila tidak digunakan.

## Terminal command

Semua command diawali `/`. Nomor pada `/Listcommaind` hanya penanda daftar, bukan input command. Command yang tersedia pada versi ini:

| Perintah | Fungsi |
|---|---|
| `/Listcommaind` | Daftar seluruh command yang tersedia |
| `/help` | Petunjuk terminal |
| `/about` | Informasi aplikasi |
| `/set_new_api_key` | Simpan/ganti API Key; input berikutnya disamarkan |
| `/confirm_change` | Konfirmasi penggantian API Key lama |
| `/cancel` | Batalkan input/perubahan API Key |
| `/delete_api_key` | Hapus API Key; error jika belum ada |
| `/check_api_key` | Status API Key (nilai dimasking) |
| `/ai_on`, `/ai_off` | Aktifkan/nonaktifkan permintaan AI |
| `/ai_info`, `/ai_model` | Status dan model AI |
| `/ai_personality [gaya]` | Lihat/ubah gaya persona AI |
| `/ai_reset`, `/restart_ai` | Batalkan request AI yang sedang berjalan |
| `/start`, `/stop`, `/restart_service` | Mulai/hentikan sesi Screen Assist dengan izin Android |
| `/floating_on`, `/floating_off` | Tampilkan/sembunyikan Floating Bot saat sesi aktif |
| `/floating_position`, `/floating_reset` | Lihat/reset posisi Floating Bot |
| `/status`, `/diagnostics` | Status dan laporan diagnostik |
| `/system_info`, `/version`, `/uptime` | Informasi perangkat, versi, dan uptime |
| `/check_ram`, `/check_storage`, `/check_cpu` | Informasi memori, storage, dan CPU/ABI |
| `/check_service`, `/check_overlay`, `/check_projection` | Status service dan izin |
| `/check_screenshot_protection` | Status `FLAG_SECURE` pada window Tatsumaki |
| `/check_network`, `/ping` | Status koneksi jaringan |
| `/usage`, `/usage_today`, `/usage_month`, `/usage_limit` | Statistik penggunaan dan keterangan kuota |
| `/reset_usage` | Reset statistik lokal; tidak mereset kuota Google |
| `/clear_cache` | Hapus cache aplikasi |
| `/text_mode` | Buka Text Mode |
| `/last_auto_text` | Lihat hasil Accessibility Text Assist terakhir |
| `/izin_aksesibilitas` | Tampilkan penjelasan izin, lalu buka pengaturan Accessibility Android setelah disetujui |
| `/status_aksesibilitas` | Periksa status Auto Text dan Auto KKM |

Command yang memerlukan perpindahan Activity atau alur izin ditangani oleh terminal utama. Terminal tidak menjalankan shell sistem bebas.

Lihat `AUDIT_REPORT.md` untuk status verifikasi dan keterbatasan build.

## Penilaian Siswa (tambahan)

Perintah terminal `/penilaian` membuka alat bantu penilaian guru:

- **Pilihan ganda:** masukkan kunci dan jawaban siswa per baris (`1=A`, `2=C`). Skor dihitung lokal dan deterministik berdasarkan kunci yang dimasukkan guru.
- **Esai:** masukkan rubrik dan jawaban siswa. Gemini memberi saran skor, alasan, dan rincian kriteria dalam JSON; guru tetap harus memeriksa dan menyetujui hasilnya.
- **Foto/screenshot:** tombol pembacaan gambar mengirim gambar yang dipilih ke Gemini untuk transkripsi berbantuan AI. Hasil transkripsi harus ditinjau dan dikoreksi sebelum dipakai.
- **Penyimpanan lokal:** nama siswa, nilai yang disetujui, dan komentar terakhir disimpan pada SharedPreferences lokal perangkat. Riwayat menyimpan hingga 100 penilaian terakhir. Isi jawaban, rubrik, serta foto yang dikirim diproses oleh layanan Gemini.
- **Pengisian formulir:** ketika Screen Assist/Floating Bot aktif, tombol `ISI NILAI TERAKHIR` dan `ISI KOMENTAR TERAKHIR` pada bot mengisi kolom teks yang sedang fokus. Guru harus fokuskan kolom yang benar dan memeriksa hasilnya sebelum menyimpan pada aplikasi tujuan. Tombol simpan aplikasi tujuan tidak ditekan otomatis.
- **Rekap lokal:** tombol `LIHAT RIWAYAT NILAI LOKAL` di layar Penilaian dan command `/nilai_riwayat` menampilkan hingga 100 hasil yang disetujui.
- **Auto Scroll:** tombol pada Floating Bot menggulir jendela aktif melalui Accessibility hingga halaman tidak dapat digulir lagi atau layanan dihentikan.

Alur yang disarankan: isi jawaban/kunci atau rubrik → periksa hasil → koreksi input bila perlu → tekan **Setujui & Simpan** → fokuskan kolom penilaian yang benar di aplikasi guru → tekan tombol pengisian pada Floating Bot → periksa sebelum menyimpan.

Fitur OCR menggunakan pemahaman gambar Gemini, bukan OCR offline khusus di perangkat. Ketepatan bergantung pada kualitas gambar, tulisan, dan model. Jangan mengirim informasi pribadi siswa kecuali memang diperlukan dan sesuai kebijakan sekolah.
