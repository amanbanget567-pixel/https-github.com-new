package com.cbt.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.text.TextUtils;

/** Reads the user's explicit Android Accessibility-service selections. */
public final class AccessibilityStatus {
    private AccessibilityStatus() { }

    public static boolean isServiceEnabled(Context context, Class<?> serviceClass) {
        if (context == null || serviceClass == null) return false;
        try {
            int accessibilityEnabled = Settings.Secure.getInt(
                    context.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (accessibilityEnabled != 1) return false;

            String enabledServices = Settings.Secure.getString(
                    context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (TextUtils.isEmpty(enabledServices)) return false;

            ComponentName expected = new ComponentName(context, serviceClass);
            String[] components = enabledServices.split(":");
            for (String componentValue : components) {
                ComponentName actual = ComponentName.unflattenFromString(componentValue);
                if (expected.equals(actual)) return true;
            }
        } catch (Exception ignored) {
            // A status check must fail closed instead of claiming the service is enabled.
        }
        return false;
    }

    public static String report(Context context) {
        boolean autoText = isServiceEnabled(context, AutoTextService.class);
        boolean autoKkm = isServiceEnabled(context, AutoKkmService.class);
        boolean autoTextAnalysis = AppPreferences.isAccessibilityAutoAnalysisEnabled(context);
        return "=== ACCESSIBILITY STATUS ===\n"
                + "Auto Text Service: " + status(autoText) + "\n"
                + "Auto KKM Service: " + status(autoKkm) + "\n"
                + "Analisis otomatis Auto Text di aplikasi: " + status(autoTextAnalysis) + "\n"
                + "Catatan: layanan harus diaktifkan sendiri melalui Pengaturan Aksesibilitas Android.";
    }

    public static String shortStatus(Context context) {
        return "Auto Text: " + status(isServiceEnabled(context, AutoTextService.class))
                + " | Auto KKM: " + status(isServiceEnabled(context, AutoKkmService.class));
    }

    private static String status(boolean enabled) {
        return enabled ? "AKTIF" : "NONAKTIF";
    }

    public static void showSettingsExplanation(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        String message =
                "Tatsumaki AI menyediakan dua layanan opsional. Tatsumaki tidak mengaktifkan atau mengubah "
                + "statusnya secara otomatis; kamu yang memilih masing-masing layanan di Pengaturan Android.\n\n"
                + "1. Bantuan Baca Teks (Auto Text): saat layanan Android ini aktif dan sakelar "
                + "'Analisis teks otomatis' di Tatsumaki juga dinyalakan, aplikasi membaca teks "
                + "yang tersedia pada struktur aksesibilitas jendela aplikasi aktif (maksimal 6.000 karakter per pemindaian; "
                + "kolom yang ditandai sebagai sandi oleh aplikasi dikecualikan) dan "
                + "mengirim teks tersebut ke Gemini untuk dianalisis.\n\n"
                + "2. Bantuan Interaksi (Auto KKM): dapat membaca label teks pada antarmuka yang "
                + "dapat diakses dan mencoba mengetuk elemen yang cocok ketika fitur terkait di Tatsumaki "
                + "memintanya. Untuk administrasi nilai, layanan juga dapat menggulir halaman dan mengisi kolom teks "
                + "yang sedang fokus setelah guru menekan tombol pengisian. Layanan tidak menekan tombol simpan "
                + "aplikasi tujuan secara otomatis.\n\n"
                + "Jangan aktifkan layanan bila kamu tidak setuju dengan akses tersebut. Hindari "
                + "menggunakannya saat aplikasi lain menampilkan data pribadi atau rahasia. "
                + "Status layanan bisa diperiksa lagi di Settings Tatsumaki atau dengan command "
                + "/status_aksesibilitas.";

        new AlertDialog.Builder(activity)
                .setTitle("Penjelasan Izin Aksesibilitas")
                .setMessage(message)
                .setPositiveButton("Buka Pengaturan Android", (dialog, which) -> openSettings(activity))
                .setNegativeButton("Nanti", null)
                .show();
    }

    public static void openSettings(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        try {
            activity.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            new AlertDialog.Builder(activity)
                    .setTitle("Pengaturan tidak tersedia")
                    .setMessage("Android tidak dapat membuka halaman Aksesibilitas di perangkat ini. "
                            + "Buka Pengaturan perangkat, lalu cari menu Aksesibilitas.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }
}
