package com.cbt.helper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;

public class PinSettingsActivity extends Activity {
    private EditText oldPin;
    private EditText newPin;
    private EditText confirmPin;
    private TextView accessibilityStatusView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        scroll.addView(root);
        root.setBackgroundColor(Color.BLACK);
        TextView title = new TextView(this);
        title.setText("TATSUMAKI TERMINAL\nSECURITY SETTINGS");
        title.setTextColor(Color.rgb(0,255,117));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(19);
        root.addView(title);
        TextView pinStatus = new TextView(this);
        pinStatus.setText("APP PIN STATUS: " + (PinManager.isEnabled(this) ? "ACTIVE" : "OFF"));
        pinStatus.setTextColor(Color.rgb(0, 255, 117));
        pinStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        pinStatus.setPadding(0, dp(14), 0, dp(8));
        root.addView(pinStatus);
        oldPin = addPinField(root, "PIN LAMA (jika sudah aktif)");
        newPin = addPinField(root, "PIN BARU (4-12 digit)");
        confirmPin = addPinField(root, "ULANGI PIN BARU");
        Button save = new Button(this);
        save.setText(PinManager.isEnabled(this) ? "GANTI PIN" : "AKTIFKAN PIN");
        root.addView(save);
        save.setOnClickListener(v -> savePin());
        Button disable = new Button(this);
        disable.setText("NONAKTIFKAN PIN");
        root.addView(disable);
        disable.setOnClickListener(v -> disablePin());
        Button back = new Button(this);
        back.setText("KEMBALI");
        root.addView(back);
        back.setOnClickListener(v -> finish());
        TextView note = new TextView(this);
        note.setText("Default: PIN OFF. PIN diminta saat aplikasi dibuka setelah aplikasi ditutup atau prosesnya dimulai ulang. PIN disimpan sebagai hash salted, bukan teks biasa.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(11);
        note.setPadding(0, 16, 0, 0);
        root.addView(note);

        TextView accessibilityTitle = new TextView(this);
        accessibilityTitle.setText("ACCESSIBILITY SERVICES");
        accessibilityTitle.setTextColor(Color.rgb(0, 255, 117));
        accessibilityTitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        accessibilityTitle.setTextSize(15);
        accessibilityTitle.setPadding(0, dp(22), 0, dp(6));
        root.addView(accessibilityTitle);

        TextView accessibilityIntro = new TextView(this);
        accessibilityIntro.setText("Tatsumaki menyediakan dua layanan opsional. Aplikasi tidak mengaktifkan atau mengubah statusnya otomatis; kamu memilih masing-masing layanan di Pengaturan Aksesibilitas Android.");
        accessibilityIntro.setTextColor(Color.LTGRAY);
        accessibilityIntro.setTextSize(12);
        root.addView(accessibilityIntro);

        accessibilityStatusView = new TextView(this);
        accessibilityStatusView.setTextColor(Color.rgb(0, 255, 117));
        accessibilityStatusView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        accessibilityStatusView.setTextSize(12);
        accessibilityStatusView.setPadding(0, dp(10), 0, dp(10));
        root.addView(accessibilityStatusView);

        TextView autoTextDetails = new TextView(this);
        autoTextDetails.setText("BANTUAN BACA TEKS (AUTO TEXT)\nMembaca teks yang tersedia pada struktur aksesibilitas jendela aplikasi aktif (maksimal 6.000 karakter per pemindaian) dan mengirimkannya ke Gemini hanya jika layanan Android aktif serta sakelar analisis otomatis di bawah ini dinyalakan. Kolom yang ditandai sebagai sandi oleh aplikasi dikecualikan.");
        autoTextDetails.setTextColor(Color.WHITE);
        autoTextDetails.setTextSize(12);
        autoTextDetails.setPadding(0, dp(4), 0, dp(8));
        root.addView(autoTextDetails);

        CheckBox accessibilityToggle = new CheckBox(this);
        accessibilityToggle.setTextColor(Color.WHITE);
        accessibilityToggle.setText("Aktifkan analisis teks otomatis (opsional)");
        accessibilityToggle.setChecked(AppPreferences.isAccessibilityAutoAnalysisEnabled(this));
        root.addView(accessibilityToggle);
        accessibilityToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            AppPreferences.setAccessibilityAutoAnalysisEnabled(this, checked);
            if (checked) AccessibilityStatus.showSettingsExplanation(this);
        });

        TextView autoKkmDetails = new TextView(this);
        autoKkmDetails.setText("BANTUAN INTERAKSI (AUTO KKM)\nDapat membaca label teks pada antarmuka yang dapat diakses dan mencoba mengetuk elemen yang cocok ketika fitur terkait di Tatsumaki memintanya.");
        autoKkmDetails.setTextColor(Color.WHITE);
        autoKkmDetails.setTextSize(12);
        autoKkmDetails.setPadding(0, dp(8), 0, dp(10));
        root.addView(autoKkmDetails);

        TextView accessibilityNote = new TextView(this);
        accessibilityNote.setText("Privasi: teks dari aplikasi lain dapat berisi informasi pribadi. Aktifkan hanya bila kamu memahami dan menyetujui akses tersebut. Hindari penggunaan saat membuka data rahasia.");
        accessibilityNote.setTextColor(Color.LTGRAY);
        accessibilityNote.setTextSize(11);
        root.addView(accessibilityNote);

        Button accessibilitySettings = new Button(this);
        accessibilitySettings.setText("PENJELASAN & PENGATURAN AKSESIBILITAS");
        root.addView(accessibilitySettings);
        accessibilitySettings.setOnClickListener(v -> AccessibilityStatus.showSettingsExplanation(this));
        setContentView(scroll);
        updateAccessibilityStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAccessibilityStatus();
    }

    private void updateAccessibilityStatus() {
        if (accessibilityStatusView != null) {
            accessibilityStatusView.setText(AccessibilityStatus.shortStatus(this)
                    + "\nAnalisis Auto Text di aplikasi: "
                    + (AppPreferences.isAccessibilityAutoAnalysisEnabled(this) ? "AKTIF" : "NONAKTIF"));
        }
    }

    private EditText addPinField(LinearLayout root, String hint) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        field.setHint(hint);
        field.setTextColor(Color.WHITE);
        field.setHintTextColor(Color.GRAY);
        root.addView(field, new LinearLayout.LayoutParams(-1, -2));
        return field;
    }

    private boolean verifyOldIfNeeded() {
        if (!PinManager.isEnabled(this)) return true;
        long remaining = PinManager.getRemainingLockoutMillis(this);
        if (remaining > 0L) {
            Toast.makeText(this, "Terlalu banyak percobaan. Coba lagi "
                    + ((remaining + 999L) / 1000L) + " detik lagi.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!PinManager.verify(this, oldPin.getText().toString())) {
            PinManager.recordFailedAttempt(this);
            Toast.makeText(this, "ERROR: PIN lama salah.", Toast.LENGTH_SHORT).show();
            return false;
        }
        PinManager.resetFailedAttempts(this);
        return true;
    }

    private void savePin() {
        if (!verifyOldIfNeeded()) return;
        String value = newPin.getText().toString();
        if (!PinManager.isValidPin(value)) {
            Toast.makeText(this, "PIN harus 4-12 digit angka.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!value.equals(confirmPin.getText().toString())) {
            Toast.makeText(this, "Konfirmasi PIN tidak cocok.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            if (PinManager.setPin(this, value)) {
                PinManager.setSessionUnlocked(true);
                Toast.makeText(this, "PIN berhasil diaktifkan/diperbarui.", Toast.LENGTH_SHORT).show();
                finish();
            } else Toast.makeText(this, "Gagal menyimpan PIN.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "ERROR: Penyimpanan PIN gagal.", Toast.LENGTH_LONG).show();
        }
    }

    private void disablePin() {
        if (!PinManager.isEnabled(this)) {
            Toast.makeText(this, "PIN memang belum aktif.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!verifyOldIfNeeded()) return;
        PinManager.disable(this);
        Toast.makeText(this, "PIN dinonaktifkan.", Toast.LENGTH_SHORT).show();
        finish();
    }
    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void openAccessibilitySettings() {
        AccessibilityStatus.openSettings(this);
    }

}
