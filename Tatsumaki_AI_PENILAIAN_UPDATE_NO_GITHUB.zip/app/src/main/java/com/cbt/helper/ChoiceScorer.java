package com.cbt.helper;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Pure-Java deterministic scorer for teacher-entered multiple-choice keys/answers. */
public final class ChoiceScorer {
    private static final Pattern LINE = Pattern.compile("^(?:no\\.?\\s*)?(\\d+)\\s*(?:[.)=: -]\\s*)?([A-H])$", Pattern.CASE_INSENSITIVE);

    private ChoiceScorer() { }

    public static final class Result {
        public final int correct;
        public final int total;
        public final double score;
        public final String comment;
        public final String breakdown;

        private Result(int correct, int total, double score, String comment, String breakdown) {
            this.correct = correct;
            this.total = total;
            this.score = score;
            this.comment = comment;
            this.breakdown = breakdown;
        }
    }

    public static Result calculate(String keyText, String answerText, double maxScore) {
        if (!Double.isFinite(maxScore) || maxScore <= 0 || maxScore > 1000) {
            throw new IllegalArgumentException("Nilai maksimum tidak valid.");
        }
        Map<Integer, String> key = parseLines(keyText);
        Map<Integer, String> answers = parseLines(answerText);
        if (key.isEmpty()) throw new IllegalArgumentException("Kunci jawaban belum diisi. Gunakan format 1=A.");
        for (Integer answerNumber : answers.keySet()) {
            if (!key.containsKey(answerNumber)) {
                throw new IllegalArgumentException("Jawaban siswa memuat nomor " + answerNumber + " yang tidak ada di kunci.");
            }
        }

        int correct = 0;
        StringBuilder detail = new StringBuilder("HASIL PILIHAN GANDA\n");
        for (Map.Entry<Integer, String> item : key.entrySet()) {
            String student = answers.get(item.getKey());
            boolean isCorrect = item.getValue().equals(student);
            if (isCorrect) correct++;
            detail.append(item.getKey()).append(". Kunci: ").append(item.getValue())
                    .append(" | Siswa: ").append(student == null ? "(kosong)" : student)
                    .append(" | ").append(isCorrect ? "BENAR" : "SALAH").append('\n');
        }
        double score = Math.round((maxScore * correct / key.size()) * 100.0) / 100.0;
        String comment = "Benar " + correct + " dari " + key.size() + " soal ("
                + String.format(Locale.US, "%.1f", correct * 100.0 / key.size()) + "%).";
        detail.append("\nNilai: ").append(String.format(Locale.US, "%.2f", score))
                .append(" / ").append(String.format(Locale.US, "%.2f", maxScore))
                .append("\nCatatan: nilai dihitung lokal dari kunci yang dimasukkan guru.");
        return new Result(correct, key.size(), score, comment, detail.toString());
    }

    private static Map<Integer, String> parseLines(String input) {
        Map<Integer, String> result = new LinkedHashMap<>();
        if (input == null) return result;
        String[] lines = input.split("\\r?\\n");
        for (String raw : lines) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            Matcher matcher = LINE.matcher(line);
            if (!matcher.matches()) {
                throw new IllegalArgumentException("Baris '" + line + "' tidak sesuai. Gunakan format 1=A.");
            }
            int number;
            try { number = Integer.parseInt(matcher.group(1)); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("Nomor soal tidak valid: " + line); }
            if (number < 1 || number > 500) throw new IllegalArgumentException("Nomor soal harus 1–500.");
            if (result.put(number, matcher.group(2).toUpperCase(Locale.ROOT)) != null) {
                throw new IllegalArgumentException("Nomor soal " + number + " ditulis lebih dari sekali.");
            }
        }
        return result;
    }
}
