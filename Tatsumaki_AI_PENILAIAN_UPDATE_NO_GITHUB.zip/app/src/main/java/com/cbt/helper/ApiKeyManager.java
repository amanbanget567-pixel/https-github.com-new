package com.cbt.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public final class ApiKeyManager {
    private static final String PREFS = "secure_api_key_store";
    private static final String CIPHER_TEXT = "cipher_text";
    private static final String IV = "iv";
    private static final String KEY_ALIAS = "tatsumaki_gemini_api_key_aes";
    private static final int GCM_TAG_LENGTH_BITS = 128;
    private static final int MIN_KEY_LENGTH = 20;
    private static final int MAX_KEY_LENGTH = 256;

    private ApiKeyManager() { }

    public static synchronized void save(Context context, String apiKey) throws GeneralSecurityException {
        if (context == null) throw new IllegalArgumentException("Context tidak tersedia.");
        
        // TITIK TIDAK DIHAPUS LAGI
        String normalized = apiKey == null ? "" : apiKey.trim();
        
        if (!isValidFormat(normalized)) {
            throw new IllegalArgumentException("API key harus 20-256 karakter dan hanya berisi huruf, angka, _, -, atau titik (.).");
        }

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] encrypted = cipher.doFinal(normalized.getBytes(StandardCharsets.UTF_8));

        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(IV, Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                .putString(CIPHER_TEXT, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .apply();
    }

    public static synchronized String get(Context context) {
        if (context == null) return null;
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String encodedIv = prefs.getString(IV, null);
        String encodedCipherText = prefs.getString(CIPHER_TEXT, null);
        if (encodedIv == null || encodedCipherText == null) return null;

        try {
            byte[] iv = Base64.decode(encodedIv, Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(encodedCipherText, Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv));
            String value = new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8).trim();
            return isValidFormat(value) ? value : null;
        } catch (Exception e) {
            prefs.edit().remove(IV).remove(CIPHER_TEXT).apply();
            return null;
        }
    }

    public static synchronized void delete(Context context) {
        if (context == null) return;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().remove(IV).remove(CIPHER_TEXT).apply();
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS);
        } catch (Exception ignored) { }
    }

    public static boolean isConfigured(Context context) {
        String value = get(context);
        return value != null && !value.isEmpty();
    }

    public static String masked(Context context) {
        String value = get(context);
        if (value == null || value.isEmpty()) return "Belum diatur";
        int visible = Math.min(4, value.length());
        return "••••••••" + value.substring(value.length() - visible);
    }

    private static boolean isValidFormat(String value) {
        if (value == null || value.length() < MIN_KEY_LENGTH || value.length() > MAX_KEY_LENGTH) return false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            
            // IZINKAN TITIK (.) DI SINI
            boolean allowed = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
                    
            if (!allowed) return false;
        }
        return true;
    }

    private static SecretKey getOrCreateSecretKey() throws GeneralSecurityException {
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) {
                try {
                    SecretKey existing = (SecretKey) keyStore.getKey(KEY_ALIAS, null);
                    if (existing != null) return existing;
                } catch (Exception ignored) { }
                keyStore.deleteEntry(KEY_ALIAS);
            }

            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setRandomizedEncryptionRequired(true)
                    .build();
            generator.init(spec);
            return generator.generateKey();
        } catch (GeneralSecurityException e) {
            throw e;
        } catch (Exception e) {
            throw new GeneralSecurityException("Android Keystore tidak dapat digunakan.", e);
        }
    }
}