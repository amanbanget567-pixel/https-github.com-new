package com.cbt.helper;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Teacher-facing review tool. It does not choose answers or submit student tests. */
public class AssessmentActivity extends AppCompatActivity {
    private static final int REQUEST_IMAGE = 7101;
    private static final int COLOR_BG = Color.rgb(15, 19, 17);
    private static final int COLOR_GREEN = Color.rgb(0, 220, 105);

    private EditText studentNameInput;
    private EditText maxScoreInput;
    private EditText answerKeyInput;
    private EditText responseInput;
    private EditText rubricInput;
    private TextView resultView;
    private Button choiceModeButton;
    private Button essayModeButton;
    private Button evaluateButton;
    private Button approveButton;
    private boolean essayMode;
    private boolean requestInProgress;
    private double pendingScore = -1;
    private String pendingComment = "";
    private String pendingStudent = "";
    private long inputRevision;
    private boolean activityDestroyed;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        buildUi();
        setMode(false);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(COLOR_BG);
        scroll.addView(root);

        TextView title = text("TATSUMAKI AI — PENILAIAN SISWA", 20, Color.WHITE, true);
        root.addView(title, matchWrap());
        root.addView(text("Alat bantu guru. Hasil AI/OCR perlu ditinjau sebelum disetujui. Data nama dan kode siswa disimpan lokal; isi jawaban, rubrik, dan gambar yang dikirim akan diproses oleh Gemini.", 13, Color.LTGRAY, false), spaced());

        root.addView(label("Nama siswa (opsional)"));
        studentNameInput = edit("Nama/kode siswa", false);
        root.addView(studentNameInput, matchWrap());

        root.addView(label("Nilai maksimum"));
        maxScoreInput = edit("100", false);
        maxScoreInput.setText("100");
        maxScoreInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(maxScoreInput, matchWrap());

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        choiceModeButton = button("PILIHAN GANDA");
        essayModeButton = button("ESAI");
        modeRow.addView(choiceModeButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        modeRow.addView(essayModeButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(modeRow, spaced());
        choiceModeButton.setOnClickListener(v -> setMode(false));
        essayModeButton.setOnClickListener(v -> setMode(true));

        answerKeyInput = edit("Contoh: 1=A\n2=C\n3=B", true);
        root.addView(label("Kunci jawaban — satu nomor per baris (mis. 1=A)"));
        root.addView(answerKeyInput, matchWrap());

        rubricInput = edit("Contoh rubrik:\n- Ketepatan konsep: 0–4\n- Kelengkapan penjelasan: 0–3\n- Contoh/argumentasi: 0–3", true);
        root.addView(label("Rubrik penilaian esai"));
        root.addView(rubricInput, matchWrap());

        root.addView(label("Jawaban siswa / teks hasil OCR"));
        responseInput = edit("Tempel jawaban siswa di sini...", true);
        root.addView(responseInput, matchWrap());

        Button imageButton = button("BACA TEKS DARI FOTO / SCREENSHOT");
        root.addView(imageButton, spaced());
        imageButton.setOnClickListener(v -> chooseImage());

        evaluateButton = button("PERIKSA & HITUNG NILAI");
        root.addView(evaluateButton, spaced());
        evaluateButton.setOnClickListener(v -> evaluate());

        resultView = text("Hasil penilaian akan muncul di sini.", 14, Color.WHITE, false);
        resultView.setPadding(dp(12), dp(12), dp(12), dp(12));
        resultView.setBackgroundColor(Color.rgb(28, 35, 30));
        root.addView(resultView, spaced());

        approveButton = button("SETUJUI & SIMPAN NILAI TERAKHIR");
        approveButton.setEnabled(false);
        root.addView(approveButton, spaced());
        approveButton.setOnClickListener(v -> approveResult());

        Button historyButton = button("LIHAT RIWAYAT NILAI LOKAL");
        root.addView(historyButton, spaced());
        historyButton.setOnClickListener(v -> new AlertDialog.Builder(AssessmentActivity.this)
                .setTitle("Riwayat nilai")
                .setMessage(AssessmentStore.historySummary(AssessmentActivity.this))
                .setPositiveButton("Tutup", null)
                .show());

        watchForEdits(studentNameInput);
        watchForEdits(maxScoreInput);
        watchForEdits(answerKeyInput);
        watchForEdits(responseInput);
        watchForEdits(rubricInput);

        Button done = button("KEMBALI KE TERMINAL");
        root.addView(done, spaced());
        done.setOnClickListener(v -> finish());
        setContentView(scroll);
    }

    private void setMode(boolean essay) {
        essayMode = essay;
        inputRevision++;
        answerKeyInput.setVisibility(essay ? View.GONE : View.VISIBLE);
        rubricInput.setVisibility(essay ? View.VISIBLE : View.GONE);
        choiceModeButton.setBackgroundColor(essay ? Color.DKGRAY : COLOR_GREEN);
        choiceModeButton.setTextColor(essay ? Color.WHITE : Color.BLACK);
        essayModeButton.setBackgroundColor(essay ? COLOR_GREEN : Color.DKGRAY);
        essayModeButton.setTextColor(essay ? Color.BLACK : Color.WHITE);
        resetPending("Mode penilaian berubah. Lakukan pemeriksaan ulang.");
    }

    private void evaluate() {
        if (requestInProgress) return;
        String response = value(responseInput);
        if (response.isEmpty()) {
            responseInput.setError("Masukkan jawaban siswa atau baca dari foto terlebih dahulu.");
            return;
        }
        String maxText = value(maxScoreInput);
        double maxScore;
        try {
            maxScore = Double.parseDouble(maxText.replace(',', '.'));
            if (!Double.isFinite(maxScore) || maxScore <= 0 || maxScore > 1000) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            maxScoreInput.setError("Masukkan nilai maksimum yang valid (lebih dari 0 hingga 1000).");
            return;
        }
        pendingStudent = value(studentNameInput);
        if (essayMode) evaluateEssay(response, value(rubricInput), maxScore);
        else evaluateChoice(response, value(answerKeyInput), maxScore);
    }

    private void evaluateChoice(String response, String keyText, double maxScore) {
        try {
            ChoiceScorer.Result result = ChoiceScorer.calculate(keyText, response, maxScore);
            pendingScore = result.score;
            pendingComment = result.comment;
            resultView.setText(result.breakdown);
            approveButton.setEnabled(true);
        } catch (IllegalArgumentException e) {
            resultView.setText("Input belum valid: " + e.getMessage());
            resetPending(null);
        }
    }

    private void evaluateEssay(String response, String rubric, double maxScore) {
        if (rubric.trim().isEmpty()) {
            rubricInput.setError("Rubrik perlu diisi agar penilaian bisa dipertanggungjawabkan.");
            return;
        }
        if (!ApiKeyManager.isConfigured(this)) {
            resultView.setText("API Key belum diatur. Isi melalui /set_new_api_key di terminal.");
            return;
        }
        requestInProgress = true;
        final long requestRevision = inputRevision;
        evaluateButton.setEnabled(false);
        approveButton.setEnabled(false);
        resultView.setText("Gemini sedang menilai berdasarkan rubrik. Periksa kembali hasilnya sebelum disetujui...");
        GeminiHelper.gradeEssay(this, rubric, response, maxScore, new GeminiHelper.Callback() {
            @Override public void onSuccess(String result) {
                requestInProgress = false;
                if (activityDestroyed) return;
                evaluateButton.setEnabled(true);
                if (requestRevision != inputRevision) {
                    resultView.setText("Input berubah saat Gemini menilai. Hasil lama dibuang; jalankan pemeriksaan ulang.");
                    return;
                }
                try {
                    JSONObject json = parseJsonObject(result);
                    double score = json.getDouble("score");
                    if (!Double.isFinite(score)) throw new IllegalArgumentException("Skor tidak valid.");
                    pendingScore = round2(Math.max(0, Math.min(maxScore, score)));
                    String feedback = json.optString("feedback", "Tidak ada komentar.");
                    StringBuilder display = new StringBuilder("HASIL PENILAIAN ESAI (SARAN AI)\n")
                            .append("Nilai: ").append(format(pendingScore)).append(" / ").append(format(maxScore))
                            .append("\n\nUmpan balik: ").append(feedback);
                    JSONArray criteria = json.optJSONArray("criteria");
                    if (criteria != null) {
                        display.append("\n\nRINCIAN RUBRIK:");
                        for (int i = 0; i < criteria.length(); i++) {
                            JSONObject c = criteria.optJSONObject(i);
                            if (c == null) continue;
                            display.append("\n- ").append(c.optString("name", "Kriteria"))
                                    .append(": ").append(c.optString("score", "?"))
                                    .append(" / ").append(c.optString("maxScore", "?"))
                                    .append(" — ").append(c.optString("comment", ""));
                        }
                    }
                    display.append("\n\nPerlu pemeriksaan manual: ")
                            .append(json.optBoolean("needsReview", true) ? "YA" : "disarankan tetap ditinjau")
                            .append("\nPeriksa kesesuaian skor dengan rubrik sebelum menyetujui.");
                    pendingComment = feedback;
                    resultView.setText(display.toString());
                    approveButton.setEnabled(true);
                } catch (Exception e) {
                    pendingScore = -1;
                    pendingComment = "";
                    approveButton.setEnabled(false);
                    resultView.setText("Respons penilaian belum bisa diverifikasi sebagai JSON nilai. Tidak ada nilai yang disetujui.\n" + result);
                }
            }
            @Override public void onError(String error) {
                requestInProgress = false;
                if (activityDestroyed) return;
                pendingScore = -1;
                pendingComment = "";
                evaluateButton.setEnabled(true);
                approveButton.setEnabled(false);
                resultView.setText("Penilaian gagal: " + error);
            }
        });
    }

    private void approveResult() {
        if (pendingScore < 0) return;
        String formatted = format(pendingScore);
        new AlertDialog.Builder(this)
                .setTitle("Setujui nilai")
                .setMessage("Simpan nilai " + formatted + " untuk " + (pendingStudent.isEmpty() ? "siswa ini" : pendingStudent)
                        + " sebagai nilai terakhir? Nilai baru hanya akan mengubah nilai lokal yang disimpan Tatsumaki.")
                .setNegativeButton("Periksa lagi", null)
                .setPositiveButton("Setujui", (d, w) -> {
                    AssessmentStore.approve(this, pendingStudent, formatted, pendingComment,
                            essayMode ? "Esai" : "Pilihan ganda");
                    Toast.makeText(this, "Nilai disetujui dan disimpan lokal.", Toast.LENGTH_LONG).show();
                    approveButton.setEnabled(false);
                    approveButton.setText("NILAI TERSIMPAN — LAKUKAN PENILAIAN BARU UNTUK MENGGANTI");
                }).show();
    }

    private void chooseImage() {
        if (requestInProgress) {
            Toast.makeText(this, "Permintaan sebelumnya masih diproses.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try { startActivityForResult(intent, REQUEST_IMAGE); }
        catch (Exception e) { Toast.makeText(this, "Pemilih gambar tidak tersedia.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_IMAGE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            String base64 = readImageBase64(uri);
            if (!ApiKeyManager.isConfigured(this)) {
                Toast.makeText(this, "Atur API Key terlebih dahulu.", Toast.LENGTH_LONG).show();
                return;
            }
            resetPending("Pembacaan gambar dimulai. Hasil sebelumnya tidak lagi bisa disetujui.");
            requestInProgress = true;
            final long requestRevision = inputRevision;
            evaluateButton.setEnabled(false);
            resultView.setText("Membaca teks gambar dengan Gemini. Tinjau dan koreksi teks hasil OCR sebelum penilaian...");
            GeminiHelper.extractTextFromImage(this, base64, new GeminiHelper.Callback() {
                @Override public void onSuccess(String result) {
                    requestInProgress = false;
                    if (activityDestroyed) return;
                    evaluateButton.setEnabled(true);
                    if (requestRevision != inputRevision) {
                        resultView.setText("Formulir berubah selama pembacaan gambar. Hasil OCR dibuang; ulangi pemilihan gambar.");
                        return;
                    }
                    new AlertDialog.Builder(AssessmentActivity.this)
                            .setTitle("Tinjau hasil pembacaan gambar")
                            .setMessage(result)
                            .setNegativeButton("Batal", null)
                            .setPositiveButton("Gunakan teks ini", (d, w) -> {
                                responseInput.setText(result);
                                resetPending("Teks OCR dimasukkan. Periksa salah baca sebelum menghitung nilai.");
                            }).show();
                }
                @Override public void onError(String error) {
                    requestInProgress = false;
                    if (activityDestroyed) return;
                    pendingScore = -1;
                    pendingComment = "";
                    approveButton.setEnabled(false);
                    evaluateButton.setEnabled(true);
                    resultView.setText("Pembacaan gambar gagal: " + error);
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Gagal membaca gambar: " + safeMessage(e), Toast.LENGTH_LONG).show();
        }
    }

    private String readImageBase64(Uri uri) throws Exception {
        Bitmap bitmap;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("File gambar tidak bisa dibuka.");
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            byte[] bytes = readAll(in);
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IllegalArgumentException("File bukan gambar yang valid.");
            int sample = 1;
            while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
        }
        if (bitmap == null) throw new IllegalArgumentException("Gambar tidak dapat didekode.");
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)) throw new IllegalStateException("Kompresi gambar gagal.");
            byte[] encoded = out.toByteArray();
            if (encoded.length > 7 * 1024 * 1024) throw new IllegalArgumentException("Gambar terlalu besar setelah kompresi. Pilih gambar lebih kecil.");
            return Base64.encodeToString(encoded, Base64.NO_WRAP);
        } finally { bitmap.recycle(); }
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) {
            out.write(buffer, 0, n);
            if (out.size() > 18 * 1024 * 1024) throw new IllegalArgumentException("File gambar melebihi batas 18 MB.");
        }
        return out.toByteArray();
    }

    private JSONObject parseJsonObject(String raw) throws Exception {
        String text = raw == null ? "" : raw.trim();
        if (text.startsWith("```") ) {
            int firstLine = text.indexOf('\n');
            if (firstLine >= 0) text = text.substring(firstLine + 1);
            if (text.endsWith("```")) text = text.substring(0, text.length() - 3).trim();
        }
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end <= start) throw new IllegalArgumentException("Objek JSON tidak ditemukan.");
        return new JSONObject(text.substring(start, end + 1));
    }

    private void watchForEdits(EditText input) {
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                inputRevision++;
                if (pendingScore >= 0) {
                    pendingScore = -1;
                    pendingComment = "";
                    approveButton.setEnabled(false);
                    approveButton.setText("INPUT BERUBAH — PERIKSA ULANG");
                    resultView.setText("Input berubah. Nilai hasil sebelumnya dibatalkan agar tidak tersimpan untuk jawaban yang berbeda.");
                }
            }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void resetPending(String note) {
        pendingScore = -1;
        pendingComment = "";
        pendingStudent = value(studentNameInput);
        approveButton.setEnabled(false);
        approveButton.setText("SETUJUI & SIMPAN NILAI TERAKHIR");
        if (note != null && resultView != null) resultView.setText(note);
    }

    private String value(EditText input) { return input == null || input.getText() == null ? "" : input.getText().toString().trim(); }
    private String format(double value) { return new DecimalFormat("0.##", DecimalFormatSymbols.getInstance(Locale.US)).format(value); }
    private double round2(double value) { return Math.round(value * 100.0) / 100.0; }
    private String safeMessage(Exception e) { return e == null || e.getMessage() == null ? "kesalahan tidak diketahui" : e.getMessage(); }

    private TextView label(String value) { return text(value, 13, Color.LTGRAY, true); }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextSize(size); view.setTextColor(color);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }
    private EditText edit(String hint, boolean multiline) {
        EditText view = new EditText(this);
        view.setHint(hint); view.setTextColor(Color.WHITE); view.setHintTextColor(Color.GRAY);
        view.setBackgroundColor(Color.rgb(35, 43, 38)); view.setPadding(dp(10), dp(8), dp(10), dp(8));
        view.setTextSize(14);
        if (multiline) { view.setMinLines(3); view.setGravity(android.view.Gravity.TOP); view.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); }
        else { view.setSingleLine(true); view.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); }
        return view;
    }
    private Button button(String value) {
        Button b = new Button(this); b.setText(value); b.setTextColor(Color.BLACK); b.setBackgroundColor(COLOR_GREEN); b.setAllCaps(false); return b;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams spaced() { LinearLayout.LayoutParams p = matchWrap(); p.topMargin = dp(10); p.bottomMargin = dp(6); return p; }
    @Override protected void onDestroy() {
        activityDestroyed = true;
        super.onDestroy();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
