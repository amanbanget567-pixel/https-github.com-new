package com.cbt.helper;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Stores teacher-approved latest grade and a bounded local history on this device. */
public final class AssessmentStore {
    private static final String PREFS = "teacher_assessment_store";
    private static final String GRADE = "approved_grade";
    private static final String COMMENT = "approved_comment";
    private static final String STUDENT = "approved_student";
    private static final String UPDATED = "approved_updated";
    private static final String HISTORY = "grade_history_json";
    private static final int MAX_HISTORY = 100;

    private AssessmentStore() { }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void approve(Context context, String student, String grade, String comment) {
        approve(context, student, grade, comment, "Tidak ditentukan");
    }

    public static void approve(Context context, String student, String grade, String comment, String mode) {
        if (context == null || grade == null || grade.trim().isEmpty()) {
            throw new IllegalArgumentException("Nilai yang disetujui tidak boleh kosong.");
        }
        long now = System.currentTimeMillis();
        String safeStudent = student == null ? "" : student.trim();
        String safeComment = comment == null ? "" : comment.trim();
        SharedPreferences preferences = prefs(context);
        JSONArray history;
        try { history = new JSONArray(preferences.getString(HISTORY, "[]")); }
        catch (Exception e) { history = new JSONArray(); }
        JSONObject record = new JSONObject();
        try {
            record.put("student", safeStudent);
            record.put("grade", grade.trim());
            record.put("comment", safeComment);
            record.put("mode", mode == null ? "Tidak ditentukan" : mode);
            record.put("updated", now);
            history.put(record);
        } catch (Exception e) {
            throw new IllegalStateException("Riwayat nilai tidak dapat disimpan.", e);
        }
        while (history.length() > MAX_HISTORY) {
            JSONArray trimmed = new JSONArray();
            for (int i = history.length() - MAX_HISTORY; i < history.length(); i++) {
                JSONObject item = history.optJSONObject(i);
                if (item != null) trimmed.put(item);
            }
            history = trimmed;
        }
        preferences.edit()
                .putString(GRADE, grade.trim())
                .putString(COMMENT, safeComment)
                .putString(STUDENT, safeStudent)
                .putLong(UPDATED, now)
                .putString(HISTORY, history.toString())
                .apply();
    }

    public static String getGrade(Context context) { return prefs(context).getString(GRADE, ""); }
    public static String getComment(Context context) { return prefs(context).getString(COMMENT, ""); }
    public static String getStudent(Context context) { return prefs(context).getString(STUDENT, ""); }
    public static long getUpdated(Context context) { return prefs(context).getLong(UPDATED, 0L); }
    public static boolean hasApprovedGrade(Context context) { return !getGrade(context).trim().isEmpty(); }

    public static String historySummary(Context context) {
        JSONArray history;
        try { history = new JSONArray(prefs(context).getString(HISTORY, "[]")); }
        catch (Exception e) { return "Riwayat nilai lokal tidak dapat dibaca."; }
        if (history.length() == 0) return "Belum ada riwayat nilai yang disetujui.";
        StringBuilder out = new StringBuilder("=== RIWAYAT NILAI (maksimal 100 catatan terbaru) ===\n");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        for (int i = history.length() - 1; i >= 0; i--) {
            JSONObject item = history.optJSONObject(i);
            if (item == null) continue;
            out.append(i + 1).append(". ")
                    .append(item.optString("student", "").isEmpty() ? "(tanpa nama)" : item.optString("student"))
                    .append(" | Nilai: ").append(item.optString("grade", "-"))
                    .append(" | Mode: ").append(item.optString("mode", "-"))
                    .append(" | ").append(dateFormat.format(new Date(item.optLong("updated", 0L))))
                    .append("\n   ").append(item.optString("comment", ""))
                    .append('\n');
        }
        return out.toString();
    }
}
