package com.cbt.helper;

import android.Manifest;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;

import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.Locale;

public final class SystemDiagnostics {
    private SystemDiagnostics() { }

    public static String report(Context context) {
        StringBuilder out = new StringBuilder("=== SYSTEM DIAGNOSTICS ===\n");
        out.append(checkApi(context)).append('\n');
        out.append(checkOverlay(context)).append('\n');
        out.append(AccessibilityStatus.report(context)).append('\n');
        out.append(checkNotifications(context)).append('\n');
        out.append(checkNetwork(context)).append('\n');
        out.append(checkService()).append('\n');
        out.append(checkProjection()).append('\n');
        out.append(checkMemory(context)).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        File cache = context.getCacheDir();
        out.append("Cache directory: ").append(cache != null && cache.exists() ? "OK" : "Tidak tersedia");
        return out.toString();
    }

    public static String checkApi(Context context) {
        return "API key: " + (ApiKeyManager.isConfigured(context) ? "TERPASANG (" + ApiKeyManager.masked(context) + ")" : "BELUM DIATUR");
    }

    public static String checkOverlay(Context context) {
        return "Overlay: " + (Settings.canDrawOverlays(context) ? "DIIZINKAN" : "BELUM DIIZINKAN");
    }

    public static String checkNotifications(Context context) {
        if (Build.VERSION.SDK_INT < 33) return "Notifikasi: tidak memerlukan runtime permission pada versi ini";
        boolean granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
        return "Notifikasi: " + (granted ? "DIIZINKAN" : "DITOLAK / BELUM DIMINTA");
    }

    public static String checkNetwork(Context context) {
        try {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return "Network: status tidak tersedia";
            Network active = manager.getActiveNetwork();
            if (active == null) return "Network: OFFLINE";
            NetworkCapabilities caps = manager.getNetworkCapabilities(active);
            boolean connected = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            return "Network: " + (connected ? "TERHUBUNG" : "TIDAK TERHUBUNG");
        } catch (SecurityException e) {
            return "Network: izin status jaringan tidak tersedia";
        }
    }

    public static String checkService() {
        return "ScreenModeService: " + (ScreenModeService.isActive() ? "AKTIF" : "NONAKTIF");
    }

    public static String checkProjection() {
        return "MediaProjection: " + (ScreenModeService.isProjectionActive() ? "AKTIF" : "NONAKTIF");
    }

    public static String checkMemory(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (manager == null) return "Memory: status tidak tersedia";
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(info);
        long total = info.totalMem / (1024L * 1024L);
        long available = info.availMem / (1024L * 1024L);
        return String.format(Locale.US, "Memory: %d MB tersedia dari %d MB", available, total);
    }


    public static String systemInfo(Context context) {
        return "Device: " + Build.MANUFACTURER + " " + Build.MODEL
                + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "\nABI: " + (Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "Tidak diketahui")
                + "\nApp: " + version(context);
    }

    public static String checkStorage(Context context) {
        try {
            StatFs stats = new StatFs(context.getFilesDir().getAbsolutePath());
            long available = stats.getAvailableBytes();
            long total = stats.getTotalBytes();
            return "Storage internal tersedia: " + formatBytes(available)
                    + " dari " + formatBytes(total);
        } catch (Exception e) {
            return "Storage: informasi tidak tersedia.";
        }
    }

    public static String checkCpu() {
        int cores = Runtime.getRuntime().availableProcessors();
        String abi = Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "Tidak diketahui";
        return "CPU cores tersedia untuk aplikasi: " + cores + "\nABI utama: " + abi
                + "\nCatatan: beban/frekuensi CPU real-time tidak dibaca.";
    }

    public static String uptime() {
        long totalSeconds = SystemClock.elapsedRealtime() / 1000L;
        long days = totalSeconds / 86400L;
        long hours = (totalSeconds % 86400L) / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        return String.format(Locale.US, "Device uptime: %d hari %02d:%02d:%02d", days, hours, minutes, seconds);
    }

    public static String version(Context context) {
        try {
            android.content.pm.PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return info.versionName == null ? "tidak diketahui" : info.versionName;
        } catch (Exception e) {
            return "tidak diketahui";
        }
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        return String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    public static void clearAppCache(Context context) {
        File cache = context.getCacheDir();
        deleteContents(cache);
    }

    private static void deleteContents(File directory) {
        if (directory == null || !directory.exists() || !directory.isDirectory()) return;
        File[] files = directory.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isDirectory()) deleteContents(file);
            // Cache contents only; never remove files outside getCacheDir().
            file.delete();
        }
    }
}
