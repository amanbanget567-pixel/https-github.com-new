package com.cbt.helper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import java.util.List;

public class AutoKkmService extends AccessibilityService {
    private static volatile AutoKkmService instance;
    private final Handler autoScrollHandler = new Handler(Looper.getMainLooper());
    private volatile boolean autoScrolling;
    private AutoScrollListener autoScrollListener;
    private int autoScrollSteps;
    private static final int MAX_AUTO_SCROLL_STEPS = 120;
    private final Runnable autoScrollTask = new Runnable() {
        @Override public void run() {
            if (!autoScrolling || instance != AutoKkmService.this) return;
            if (autoScrollSteps >= MAX_AUTO_SCROLL_STEPS || !scrollActiveWindowForward()) {
                stopAutoScroll();
                return;
            }
            autoScrollSteps++;
            autoScrollHandler.postDelayed(this, 900L);
        }
    };

    public interface AutoScrollListener {
        void onAutoScrollStateChanged(boolean running);
    }

    public static AutoKkmService getInstance() { return instance; }

    public void setAutoScrollListener(AutoScrollListener listener) {
        autoScrollListener = listener;
    }

    private void notifyAutoScrollState(boolean running) {
        AutoScrollListener listener = autoScrollListener;
        if (listener != null) {
            try { listener.onAutoScrollStateChanged(running); } catch (Exception ignored) { }
        }
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    /** Set text only in the currently focused editable field. Triggered by an explicit teacher tap. */
    public boolean fillTextIntoFocusedField(String value) {
        if (value == null || value.trim().isEmpty() || value.length() > 4000) return false;
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return false;
        AccessibilityNodeInfo focused = null;
        try {
            focused = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (focused == null || !focused.isEditable() || !focused.isEnabled() || focused.isPassword()) return false;
            Bundle arguments = new Bundle();
            arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
        } catch (Exception ignored) {
            return false;
        } finally {
            if (focused != null) focused.recycle();
            rootNode.recycle();
        }
    }

    public boolean isAutoScrolling() { return autoScrolling; }

    /** Repeatedly scrolls the active window; stops when no scrollable node can move forward. */
    public boolean startAutoScroll() {
        if (autoScrolling) return true;
        AccessibilityNodeInfo activeRoot = getRootInActiveWindow();
        if (activeRoot == null) return false;
        activeRoot.recycle();
        autoScrollSteps = 0;
        autoScrolling = true;
        autoScrollHandler.removeCallbacks(autoScrollTask);
        notifyAutoScrollState(true);
        autoScrollHandler.post(autoScrollTask);
        return true;
    }

    public void stopAutoScroll() {
        boolean wasRunning = autoScrolling;
        autoScrolling = false;
        autoScrollHandler.removeCallbacks(autoScrollTask);
        if (wasRunning) notifyAutoScrollState(false);
    }

    private boolean scrollActiveWindowForward() {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return false;
        try {
            if (scrollNodeForward(rootNode, 0)) return true;
            return false;
        } finally {
            rootNode.recycle();
        }
    }

    private boolean scrollNodeForward(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 35) return false;
        if (node.isScrollable() && node.isEnabled()
                && node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try {
                    if (scrollNodeForward(child, depth + 1)) return true;
                } finally {
                    child.recycle();
                }
            }
        }
        return false;
    }

    public void performClickByText(String targetText) {
        if (targetText == null || targetText.isEmpty()) return;
        String cleanTarget = targetText.replaceAll("[^a-zA-Z0-9]", "").trim();
        if (cleanTarget.isEmpty()) return;

        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;
        try {
            List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(targetText);
            if (nodes == null || nodes.isEmpty()) {
                nodes = rootNode.findAccessibilityNodeInfosByText(cleanTarget);
            }
            if (nodes == null) return;

            try {
                for (AccessibilityNodeInfo node : nodes) {
                    if (node == null) continue;
                    CharSequence nodeTextSeq = node.getText();
                    if (nodeTextSeq == null) continue;
                    String nodeText = nodeTextSeq.toString().trim();
                    String cleanNode = nodeText.replaceAll("[^a-zA-Z0-9]", "");
                    boolean isMatch = false;

                    if (cleanTarget.length() == 1) {
                        if (cleanNode.startsWith(cleanTarget)) {
                            if (cleanNode.length() == 1 || nodeText.matches("(?i)^[\\(]?" + cleanTarget + "[\\)\\.\\s:].*")) {
                                isMatch = true;
                            }
                        }
                    } else if (cleanNode.equalsIgnoreCase(cleanTarget) || cleanNode.contains(cleanTarget)) {
                        isMatch = true;
                    }

                    if (isMatch) {
                        AccessibilityNodeInfo clickableParent = getClickableNode(node);
                        if (clickableParent != null) {
                            try {
                                clickableParent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            } finally {
                                clickableParent.recycle();
                            }
                            break;
                        }
                    }
                }
            } finally {
                recycleNodes(nodes);
            }
        } finally {
            rootNode.recycle();
        }
    }

    // --- FITUR MODE CHEATER: Mencari dan mengklik tombol Next/Selanjutnya ---
    public void clickNextButton() {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;
        try {
            // Daftar teks tombol Next yang sering muncul di CBT
            String[] nextTexts = {"Next", "Selanjutnya", "Berikutnya", "Lanjut", "Simpan"};
            for (String text : nextTexts) {
                List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(text);
                if (nodes == null || nodes.isEmpty()) continue;
                try {
                    for (AccessibilityNodeInfo node : nodes) {
                        if (node == null) continue;
                        AccessibilityNodeInfo clickableParent = getClickableNode(node);
                        if (clickableParent != null) {
                            try {
                                clickableParent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            } finally {
                                clickableParent.recycle();
                            }
                            return; // Berhenti setelah klik
                        }
                    }
                } finally {
                    recycleNodes(nodes);
                }
            }
        } finally {
            rootNode.recycle();
        }
    }

    private static void recycleNodes(List<AccessibilityNodeInfo> nodes) {
        if (nodes == null) return;
        for (AccessibilityNodeInfo node : nodes) {
            if (node != null) node.recycle();
        }
    }

    private AccessibilityNodeInfo getClickableNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        AccessibilityNodeInfo current = AccessibilityNodeInfo.obtain(node);
        while (current != null) {
            if (current.isClickable()) return current;
            AccessibilityNodeInfo parent = current.getParent();
            current.recycle();
            current = parent;
        }
        return null;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        stopAutoScroll();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
