package com.cbt.helper;

import android.content.Context;

import java.security.GeneralSecurityException;
import java.util.Locale;

/** Allow-listed in-app terminal commands. It never executes operating-system shell commands. */
public class TerminalCommandSystem {
    private boolean awaitingApiKey = false;
    private boolean awaitingReplaceConfirmation = false;

    public boolean isAwaitingApiKey() {
        return awaitingApiKey;
    }

    public String execute(Context context, String rawCommand) {
        String raw = rawCommand == null ? "" : rawCommand.trim();
        if (raw.isEmpty()) return "ERROR: Perintah kosong. Ketik /help.";

        if (awaitingApiKey && "/cancel".equalsIgnoreCase(raw)) {
            awaitingApiKey = false;
            return "Input API Key dibatalkan.";
        }
        if (awaitingApiKey) {
            if (raw.startsWith("/")) {
                awaitingApiKey = false;
                return "ERROR: Input API Key dibatalkan karena menerima command. Jalankan /set_new_api_key lagi.";
            }
            awaitingApiKey = false;
            try {
                ApiKeyManager.save(context, raw);
                return "SUCCESS: API Key tersimpan secara terenkripsi. Nilainya tidak ditampilkan.";
            } catch (IllegalArgumentException e) {
                return "ERROR: API Key tidak valid. " + e.getMessage();
            } catch (GeneralSecurityException e) {
                return "ERROR: Android Keystore tidak tersedia; API Key tidak tersimpan.";
            }
        }

        String command = raw;
        String argument = "";
        int separator = raw.indexOf(' ');
        if (separator >= 0) {
            command = raw.substring(0, separator).trim();
            argument = raw.substring(separator + 1).trim();
        }
        command = command.toLowerCase(Locale.ROOT);

        switch (command) {
            case "/listcommaind":
            case "/command":
            case "/commands":
                return commandList();
            case "/help":
                return "Gunakan /Listcommaind untuk melihat daftar command. Semua command dimulai dengan '/'.";
            case "/about":
                return "TATSUMAKI TERMINAL\nAndroid Assistant\nCopyright by PhantomStore.";
            case "/status":
                return SystemDiagnostics.checkService() + "\n"
                        + SystemDiagnostics.checkProjection() + "\n"
                        + SystemDiagnostics.checkApi(context) + "\n"
                        + SystemDiagnostics.checkOverlay(context) + "\n"
                        + AccessibilityStatus.shortStatus(context);
            case "/diagnostics":
                return SystemDiagnostics.report(context);
            case "/system_info":
                return SystemDiagnostics.systemInfo(context);
            case "/check_memory":
            case "/check_ram":
                return SystemDiagnostics.checkMemory(context);
            case "/check_storage":
                return SystemDiagnostics.checkStorage(context);
            case "/check_cpu":
                return SystemDiagnostics.checkCpu();
            case "/uptime":
                return SystemDiagnostics.uptime();
            case "/version":
                return SystemDiagnostics.version(context);
            case "/check_service":
                return SystemDiagnostics.checkService();
            case "/status_aksesibilitas":
                return AccessibilityStatus.report(context);
            case "/check_overlay":
                return SystemDiagnostics.checkOverlay(context);
            case "/check_api":
            case "/check_api_key":
                return SystemDiagnostics.checkApi(context);
            case "/check_projection":
                return SystemDiagnostics.checkProjection();
            case "/check_screenshot_protection":
                return "FLAG_SECURE dipasang pada Activity Tatsumaki dan window Floating Bot. Android dapat memblokir/menyembunyikan window tersebut saat screenshot; hasil overlay tetap perlu diuji pada perangkat. Aplikasi lain tidak dimanipulasi.";
            case "/check_network":
            case "/ping":
                return SystemDiagnostics.checkNetwork(context);
            case "/usage":
                return UsageMonitor.summary(context);
            case "/usage_today":
                return UsageMonitor.summaryToday(context);
            case "/usage_month":
                return UsageMonitor.summaryMonth(context);
            case "/usage_limit":
                return UsageMonitor.limitInfo();
            case "/last_auto_text":
                return AutoTextService.getLastResult();
            case "/ai_on":
                AppPreferences.setAiEnabled(context, true);
                return "SUCCESS: AI diaktifkan.";
            case "/ai_off":
                AppPreferences.setAiEnabled(context, false);
                GeminiHelper.cancelAll();
                return "SUCCESS: AI dinonaktifkan. Request yang sedang berjalan dibatalkan.";
            case "/ai_reset":
            case "/restart_ai":
                GeminiHelper.cancelAll();
                return "Request AI yang sedang berjalan dibatalkan. Tidak ada service AI latar yang perlu direstart.";
            case "/ai_info":
                return "AI: " + (AppPreferences.isAiEnabled(context) ? "ON" : "OFF")
                        + "\nModel: " + GeminiHelper.getModelName() + " (" + GeminiHelper.getModelId() + ")"
                        + "\nPersona: " + AppPreferences.getAiPersonality(context);
            case "/ai_model":
                return "Model aktif yang dikonfigurasi: " + GeminiHelper.getModelName()
                        + " (" + GeminiHelper.getModelId() + "). Tidak ada fallback otomatis.";
            case "/ai_personality":
                if (argument.isEmpty()) return "Persona saat ini: " + AppPreferences.getAiPersonality(context)
                        + "\nUbah dengan /ai_personality <gaya singkat> (maksimal 120 karakter).";
                if (!AppPreferences.setAiPersonality(context, argument))
                    return "ERROR: Gaya persona harus 1-120 karakter.";
                return "SUCCESS: Gaya persona AI diperbarui.";
            case "/set_new_api_key":
                if (!argument.isEmpty()) {
                    return "ERROR: Jangan tulis API Key sebagai argumen command. Jalankan /set_new_api_key, lalu masukkan key pada prompt tersamarkan.";
                }
                if (ApiKeyManager.isConfigured(context)) {
                    awaitingReplaceConfirmation = true;
                    return "API Key lama terdeteksi.\nKetik /confirm_change untuk mengganti, atau /cancel untuk membatalkan.";
                }
                awaitingApiKey = true;
                return "Masukkan API Key pada baris berikutnya. Input akan disamarkan dan tidak dicatat.";
            case "/confirm_change":
                if (!awaitingReplaceConfirmation) return "ERROR: Tidak ada perubahan API Key yang menunggu konfirmasi.";
                awaitingReplaceConfirmation = false;
                awaitingApiKey = true;
                return "Konfirmasi diterima. Masukkan API Key baru pada baris berikutnya.";
            case "/cancel":
                if (awaitingReplaceConfirmation || awaitingApiKey) {
                    awaitingReplaceConfirmation = false;
                    awaitingApiKey = false;
                    return "Perubahan API Key dibatalkan.";
                }
                return "Tidak ada proses yang perlu dibatalkan.";
            case "/delete_api_key":
                if (!ApiKeyManager.isConfigured(context)) {
                    return "ERROR: Tidak ada API Key yang tersimpan. Tidak ada yang bisa dihapus.";
                }
                GeminiHelper.cancelAll();
                ApiKeyManager.delete(context);
                return "SUCCESS: API Key lokal dihapus. Request Gemini yang berjalan dibatalkan.";
            case "/clear_cache":
                SystemDiagnostics.clearAppCache(context);
                return "SUCCESS: Cache aplikasi dibersihkan. API Key dan pengaturan tidak dihapus.";
            case "/reset_usage":
                UsageMonitor.reset(context);
                return "SUCCESS: Statistik penggunaan lokal direset. Kuota project Google tidak berubah.";
            case "/start":
                return "Gunakan /start dari terminal utama untuk memulai alur izin screen capture Android.";
            case "/stop":
                return "Gunakan /stop dari terminal utama untuk menghentikan Screen Assist.";
            case "/restart_service":
                return "Gunakan /restart_service dari terminal utama. Sesi baru tetap memerlukan izin Android.";
            case "/text_mode":
                return "Membuka Text Mode melalui aplikasi.";
            case "/penilaian":
                return "Membuka Penilaian Siswa dari terminal utama.";
            case "/nilai_info":
                if (!AssessmentStore.hasApprovedGrade(context)) return "Belum ada nilai yang disetujui guru.";
                return "Nilai terakhir disetujui: " + AssessmentStore.getGrade(context)
                        + " | Siswa: " + (AssessmentStore.getStudent(context).isEmpty() ? "(tanpa nama)" : AssessmentStore.getStudent(context))
                        + " | Komentar: " + AssessmentStore.getComment(context);
            case "/nilai_riwayat":
                return AssessmentStore.historySummary(context);
            default:
                return "ERROR: Command tidak ditemukan: " + command + "\nKetik /Listcommaind untuk daftar command.";
        }
    }

    private String commandList() {
        return "========== COMMAND LIST ==========\n"
                + "[1] /Listcommaind - daftar command\n"
                + "[2] /help - petunjuk terminal\n"
                + "[3] /about - informasi aplikasi\n"
                + "[4] /set_new_api_key - atur/ganti API Key\n"
                + "[5] /confirm_change - konfirmasi penggantian key\n"
                + "[6] /cancel - batalkan input/perubahan key\n"
                + "[7] /delete_api_key - hapus API Key\n"
                + "[8] /check_api_key - status API Key\n"
                + "[9] /start - mulai Screen Assist\n"
                + "[10] /stop - hentikan Screen Assist\n"
                + "[11] /restart_service - mulai ulang sesi (izin baru)\n"
                + "[12] /ai_on - aktifkan AI\n"
                + "[13] /ai_off - nonaktifkan AI\n"
                + "[14] /ai_info - status AI\n"
                + "[15] /ai_model - model AI\n"
                + "[16] /ai_personality - atur gaya AI\n"
                + "[17] /ai_reset - batalkan request AI\n"
                + "[18] /restart_ai - batalkan request aktif\n"
                + "[19] /status - status komponen utama\n"
                + "[20] /diagnostics - diagnostik lengkap\n"
                + "[21] /system_info - informasi perangkat/aplikasi\n"
                + "[22] /check_ram - informasi RAM\n"
                + "[23] /check_storage - ruang penyimpanan\n"
                + "[24] /check_cpu - informasi prosesor\n"
                + "[25] /check_network - status jaringan\n"
                + "[26] /ping - cek konektivitas jaringan\n"
                + "[27] /uptime - waktu sejak perangkat menyala\n"
                + "[28] /version - versi aplikasi\n"
                + "[29] /check_service - status service\n"
                + "[30] /check_overlay - status izin overlay\n"
                + "[31] /check_projection - status sesi capture\n"
                + "[32] /check_screenshot_protection - status FLAG_SECURE\n"
                + "[33] /usage - statistik penggunaan\n"
                + "[34] /usage_today - request hari ini\n"
                + "[35] /usage_month - request bulan ini\n"
                + "[36] /usage_limit - info batas resmi\n"
                + "[37] /reset_usage - reset statistik tampilan\n"
                + "[38] /clear_cache - bersihkan cache aplikasi\n"
                + "[39] /text_mode - buka Text Mode\n"
                + "[40] /floating_on - tampilkan Floating Bot\n"
                + "[41] /floating_off - sembunyikan Floating Bot\n"
                + "[42] /floating_position - posisi Floating Bot\n"
                + "[43] /floating_reset - reset posisi Floating Bot\n"
                + "[44] /last_auto_text - hasil Accessibility Text Assist terakhir\n"
                + "[45] /izin_aksesibilitas - penjelasan dan pengaturan Accessibility Android\n"
                + "[46] /status_aksesibilitas - status Auto Text dan Auto KKM\n"
                + "[47] /penilaian - buka alat penilaian guru\n"
                + "[48] /nilai_info - lihat nilai terakhir yang disetujui\n"
                + "[49] /nilai_riwayat - riwayat penilaian lokal\n"
                + "==================================\n"
                + "Nomor hanya penanda daftar. Jalankan command dengan mengetik awalan '/'.";
    }
}
