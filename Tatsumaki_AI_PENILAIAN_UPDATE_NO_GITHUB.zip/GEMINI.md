# TATSUMAKI AI — PROJECT INSTRUCTIONS

## Project identity
- This is the existing Android application Tatsumaki AI.
- Android application ID: `com.cbt.helper`.
- Android Gradle Plugin: `8.3.0`.
- Gradle version used by the existing GitHub Actions workflow: `8.4`.
- JDK: `17`.
- Android SDK: compile/target SDK `34`; Build Tools `34.0.0`.
- Minimum SDK: `26`.
- Java source/target compatibility: `1.8`.

## Non-negotiable preservation rules
1. Preserve all existing application features, names, terminal commands, UI flows, settings, and behavior.
2. Do not delete, rename, replace, simplify, or silently rewrite existing files or systems.
3. Do not rebuild the application from scratch.
4. Do not change a feature's behavior merely to make implementation easier.
5. Before any change that may alter behavior, permissions, data handling, or user-visible flow, explain the exact change and ask the project owner for approval.
6. Keep existing API-key handling and optional PIN behavior intact.
7. Do not introduce ADMIN/USER roles or per-command permissions.
8. Do not add Gradle Wrapper files or a second Gradle distribution. Use the project's existing build setup.
9. Do not add, remove, or modify GitHub Actions workflows unless explicitly requested.
10. Never claim a build or device test passed unless the actual command/test was run and its result was observed.

## Safe bug-fix workflow
- Inspect the relevant source and its callers before editing.
- Identify the reproducible cause, not just the symptom.
- Prefer the smallest backward-compatible fix.
- Preserve public method names, command strings, resource identifiers, package names, and persisted preference keys.
- Check lifecycle handling, nullability, threading, permission states, and resource cleanup where relevant.
- Do not suppress exceptions or errors just to make diagnostics look clean.
- Do not log API keys, PINs, passwords, screen contents, or other private user data.
- Avoid reading or acting on password fields and sensitive input fields.
- Add tests only when they can be added without changing the application's runtime behavior.
- After editing, inspect the diff and verify that unrelated files are unchanged.
- Report every modified, added, and removed file. There must be no silent deletions.

## Existing feature areas to preserve
Preserve the existing Gemini AI integration, Text Mode, Screen Assist, Floating Bot, Auto Scan, Manual Scan, Auto KKM, Usage Monitor, Diagnostics, PIN settings, AI personality, API-key management, and terminal command system. This list is a preservation reminder, not permission to invent or replace missing features.

## Build commands for this repository
Run these commands from the project root, using JDK 17, Android SDK Platform 34, Build Tools 34.0.0, and Gradle 8.4 already installed:

Linux/macOS:
```bash
gradle --no-daemon --stacktrace :app:assembleDebug
```

Windows:
```bat
gradle.bat --no-daemon --stacktrace :app:assembleDebug
```

The existing GitHub Actions workflow also invokes:
```bash
gradle --no-daemon --stacktrace :app:assembleDebug
```

Expected Debug APK output:
```text
app/build/outputs/apk/debug/app-debug.apk
```

Do not substitute `./gradlew` or `gradlew.bat`: this repository ZIP does not include the Gradle Wrapper, and the project owner does not want Wrapper files added. Do not run `gradle wrapper`.

## Final response format for project work
Always report:
- What was inspected.
- Exact files changed.
- Exact bug and minimal fix.
- Validation actually performed and its result.
- What remains unverified, especially Gradle build and physical-device tests.
