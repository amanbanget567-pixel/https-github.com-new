# Panduan Penilaian Guru — Tatsumaki AI

## Membuka fitur
1. Buka terminal utama Tatsumaki AI.
2. Ketik `/penilaian`.
3. Pastikan API Key tersimpan dan AI aktif untuk pembacaan foto serta penilaian esai.

## Pilihan ganda
Masukkan satu nomor per baris di kotak kunci dan jawaban siswa. Format yang didukung: `1=A`, `2. C`, atau `3 B`. Skor dibagi rata berdasarkan jumlah nomor dalam kunci. Nomor yang tidak dijawab dihitung salah. Kunci kosong, nomor duplikat, dan baris tidak valid ditolak.

Pilihan ganda dihitung secara lokal tanpa meminta Gemini menentukan kunci. Karena itu, akurasi hasil bergantung pada ketepatan kunci yang dimasukkan guru.

## Esai
Masukkan rubrik yang jelas (kriteria dan bobot/tingkat nilai) serta jawaban siswa. Gemini menghasilkan saran skor, umpan balik, dan rincian kriteria. Hasil yang tidak dapat dibaca sebagai JSON skor tidak bisa disetujui. Guru tetap wajib memeriksa apakah skor sesuai rubrik.

## Foto dan screenshot
Pilih foto atau screenshot melalui tombol **Baca Teks dari Foto / Screenshot**. Gambar dikompres ke JPEG dan dikirim ke Gemini. Periksa hasil transkripsi di dialog; pilih **Gunakan teks ini** hanya setelah memperbaiki kesalahan OCR. Fitur ini adalah transkripsi berbantuan pemahaman gambar Gemini, bukan OCR offline dan bukan jaminan dapat membaca semua tulisan tangan.

## Menyetujui dan mengisi nilai
Setelah hasil penilaian benar, tekan **Setujui & Simpan Nilai Terakhir**. Nilai dan komentar terakhir serta hingga 100 catatan riwayat disimpan lokal di perangkat. Riwayat dapat dibuka dari tombol **Lihat Riwayat Nilai Lokal** atau command `/nilai_riwayat`. Saat berada di formulir penilaian guru, fokuskan kolom nilai/komentar yang benar, buka Floating Bot, lalu tekan tombol pengisian yang sesuai. Pengisian hanya mencoba mengubah kolom teks yang sedang memiliki fokus input melalui Accessibility. Periksa hasilnya; tombol simpan pada aplikasi tujuan tidak ditekan otomatis.

## Auto Scroll
Buka Floating Bot dan tekan **AUTO SCROLL** untuk memulai. Tekan lagi untuk menghentikan. Layanan mencoba menggulir container yang dapat digulir pada jendela aktif dan berhenti jika tidak ada lagi aksi scroll yang berhasil.

## Privasi dan batasan
- Nama/kode siswa, nilai yang disetujui, komentar, dan hingga 100 riwayat nilai disimpan lokal melalui SharedPreferences. Penyimpanan ini bukan enkripsi database khusus dan dapat tunduk pada pengaturan backup Android perangkat.
- Isi esai, rubrik, dan foto yang dipilih dikirim ke Gemini saat meminta OCR/penilaian. Pastikan penggunaan sesuai kebijakan sekolah dan persetujuan yang berlaku.
- Elemen Accessibility berbeda antar aplikasi. Pengisian nilai tidak dapat dijamin pada custom widget, WebView, atau aplikasi yang tidak mengekspos kolom input melalui Accessibility.
- OCR gambar dan saran nilai esai dapat salah. Guru adalah pengambil keputusan akhir.
