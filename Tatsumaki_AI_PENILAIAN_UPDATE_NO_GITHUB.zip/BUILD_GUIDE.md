# Tatsumaki AI — Build Guide

This guide prepares the existing Android project for a reproducible Debug APK build. It does not rename, remove, or redesign any existing application feature or command.

## Project build configuration

| Setting | Current project value |
|---|---|
| Android Gradle Plugin | 8.3.0 |
| Gradle required | 8.4 |
| JDK for Gradle/AGP | 17 |
| Compile SDK | 34 |
| Build Tools | 34.0.0 |
| Minimum SDK | 26 |
| Target SDK | 34 |
| Java source/target compatibility | 1.8 |
| Application ID | `com.cbt.helper` |
| Version | `1.1.2` (versionCode 4) |

## Build locally

1. Install Android Studio and the Android SDK Platform 34.
2. Install Android SDK Build Tools 34.0.0 from SDK Manager.
3. Set the Gradle JDK to JDK 17 in Android Studio.
4. Pastikan Gradle 8.4 tersedia pada mesin build. Repository ini memang tidak memakai Gradle Wrapper; jangan jalankan `gradle wrapper` dan jangan menambahkan folder `.gradle` cache ke ZIP.

5. Build Debug APK langsung dari Gradle yang terpasang:

   **Windows**
   ```bat
   gradle.bat --no-daemon --stacktrace :app:assembleDebug
   ```

   **Linux/macOS**
   ```bash
   gradle --no-daemon --stacktrace :app:assembleDebug
   ```

6. The APK should be created at:

   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```

The generated Debug APK is signed with Android's debug key. A release APK requires a separately configured signing key; no release keystore is included in this project.

## Build using GitHub Actions

The added workflow is located at `.github/workflows/android-build.yml`.

It installs JDK 17, Android SDK Platform 34 and Build Tools 34.0.0, uses Gradle 8.4, and runs `:app:assembleDebug`. After a successful run, download the artifact named `Tatsumaki-AI-debug-apk` from the workflow run's **Artifacts** section.

The workflow intentionally invokes the installed Gradle distribution directly because this source ZIP did not include a Gradle Wrapper.

## Important scope notes

- Existing Java source files, resource files, application IDs, version values, feature labels, and terminal command names are preserved in this build-preparation pass.
- No existing file is deleted.
- No API key, PIN, signing keystore, or personal credential is bundled in the ZIP.
- A successful CI build proves compilation and APK packaging only. Device tests are still required for Accessibility, MediaProjection, overlay behavior, Gemini API requests, PIN flows, and other runtime features.
- Multi-model/provider selection is not implemented in the current source tree; this build-preparation pass does not invent or silently add that separate feature.
