package com.cbt.helper;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_OVERLAY = 1;
    private static final int REQ_CAPTURE = 2;
    private static final int REQ_NOTIF = 3;

    private MediaProjectionManager projectionManager;
    private EditText terminalInput;
    private TextView terminalOutput;
    private ScrollView terminalScroll;
    private TerminalCommandSystem terminal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Android secure-window behavior hides or blocks screenshots of this app window.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        if (PinManager.isEnabled(this) && !PinManager.isSessionUnlocked()) {
            startActivity(new Intent(this, PinGateActivity.class));
            finish();
            return;
        }
        if (!PinManager.isEnabled(this)) PinManager.setSessionUnlocked(true);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        terminal = new TerminalCommandSystem();
        buildInterface();
        refreshStatus();
    }

    private void buildInterface() {
        terminalScroll = new ScrollView(this);
        terminalScroll.setFillViewport(true);
        terminalScroll.setBackgroundColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(dp(18), dp(24), dp(18), dp(18));
        root.setGravity(Gravity.TOP);
        terminalScroll.addView(root);

        FrameLayout header = new FrameLayout(this);
        TextView title = new TextView(this);
        title.setText("================================\n       TATSUMAKI TERMINAL\n================================");
        title.setTextColor(Color.parseColor("#00FF75"));
        title.setTextSize(15);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, 0, 0, dp(18));
        header.addView(title, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        TextView settingsMenu = new TextView(this);
        settingsMenu.setText("⋮");
        settingsMenu.setTextColor(Color.parseColor("#00FF75"));
        settingsMenu.setTextSize(26);
        settingsMenu.setContentDescription("Security Settings");
        settingsMenu.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams menuParams = new FrameLayout.LayoutParams(dp(36), dp(42), Gravity.END | Gravity.TOP);
        header.addView(settingsMenu, menuParams);
        settingsMenu.setOnClickListener(v -> {
            PopupMenu menu = new PopupMenu(MainActivity.this, settingsMenu);
            menu.getMenu().add("Security Settings");
            menu.setOnMenuItemClickListener(item -> {
                startActivity(new Intent(MainActivity.this, PinSettingsActivity.class));
                return true;
            });
            menu.show();
        });
        root.addView(header, matchWrap());

        terminalOutput = makeText("[1] /Listcommaind", Color.parseColor("#9BFF9B"), 13);
        terminalOutput.setTypeface(Typeface.MONOSPACE);
        terminalOutput.setTextIsSelectable(true);
        terminalOutput.setPadding(dp(4), dp(4), dp(4), dp(12));
        root.addView(terminalOutput, matchWrap());

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView prompt = makeText(">", Color.parseColor("#00FF75"), 16);
        prompt.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        prompt.setPadding(0, 0, dp(8), 0);
        inputRow.addView(prompt, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        terminalInput = new EditText(this);
        terminalInput.setSingleLine(true);
        terminalInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND);
        terminalInput.setInputType(InputType.TYPE_CLASS_TEXT);
        terminalInput.setHint("ketik command...");
        terminalInput.setTextColor(Color.parseColor("#00FF75"));
        terminalInput.setHintTextColor(Color.parseColor("#557755"));
        terminalInput.setTypeface(Typeface.MONOSPACE);
        terminalInput.setBackgroundColor(Color.parseColor("#101810"));
        terminalInput.setPadding(dp(10), dp(8), dp(10), dp(8));
        inputRow.addView(terminalInput, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(inputRow, matchWrap());

        terminalInput.setOnEditorActionListener((textView, actionId, event) -> {
            executeTerminalCommand();
            return true;
        });
        setContentView(terminalScroll);
    }

    private void beginPermissionFlow() {
        if (ScreenModeService.isActive()) {
            Toast.makeText(this, "Screen Assist sudah aktif. Hentikan sesi yang berjalan sebelum memulai sesi baru.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!ApiKeyManager.isConfigured(this)) {
            appendTerminal("ERROR: Atur API Key terlebih dahulu dengan /set_new_api_key.");
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        continuePermissionFlow();
    }

    private void continuePermissionFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Intent overlayIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(overlayIntent, REQ_OVERLAY);
            return;
        }
        startCaptureConsent();
    }

    private void startCaptureConsent() {
        if (projectionManager == null) {
            Toast.makeText(this, "MediaProjection tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show();
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) {
            // Continue once even when notification permission is denied; Android still manages FGS visibility.
            continuePermissionFlow();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startCaptureConsent();
            else Toast.makeText(this, "Izin overlay belum diberikan.", Toast.LENGTH_LONG).show();
            return;
        }
        if (requestCode == REQ_CAPTURE) {
            if (resultCode != Activity.RESULT_OK || data == null) {
                Toast.makeText(this, "Izin screen capture dibatalkan.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent serviceIntent = new Intent(this, ScreenModeService.class);
            serviceIntent.putExtra("code", resultCode);
            serviceIntent.putExtra("data", data);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent);
                else startService(serviceIntent);
        
            } catch (Exception e) {
                Toast.makeText(this, "Gagal memulai service: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void executeTerminalCommand() {
        if (terminalInput == null) return;
        String command = terminalInput.getText() == null ? "" : terminalInput.getText().toString().trim();
        if (command.isEmpty()) return;

        boolean wasWaitingForKey = terminal.isAwaitingApiKey();
        boolean containsInlineKey = command.toLowerCase().startsWith("/set_new_api_key ");
        String output;
        if (wasWaitingForKey) {
            output = terminal.execute(this, command);
        } else if ("/start".equalsIgnoreCase(command)) {
            if (ScreenModeService.isActive()) output = "Screen Assist sudah aktif.";
            else if (!ApiKeyManager.isConfigured(this)) output = "ERROR: API Key belum diatur. Jalankan /set_new_api_key.";
            else {
                beginPermissionFlow();
                output = "Memulai alur izin Android. Selesaikan prompt izin yang tampil.";
            }
        } else if ("/stop".equalsIgnoreCase(command)) {
            stopScreenService();
            output = "Perintah stop dijalankan.";
        } else if ("/restart_service".equalsIgnoreCase(command)) {
            stopScreenService();
            output = "Service dihentikan. Jalankan /start untuk meminta izin Android yang baru.";
        } else if ("/text_mode".equalsIgnoreCase(command)) {
            startActivity(new Intent(this, TextModeActivity.class));
            output = "Membuka Text Mode.";
        } else if ("/floating_on".equalsIgnoreCase(command)) {
            output = ScreenModeService.setFloatingVisible(true)
                    ? "SUCCESS: Floating Bot ditampilkan." : "ERROR: Floating Bot belum aktif.";
        } else if ("/floating_off".equalsIgnoreCase(command)) {
            output = ScreenModeService.setFloatingVisible(false)
                    ? "SUCCESS: Floating Bot disembunyikan." : "ERROR: Floating Bot belum aktif.";
        } else if ("/floating_reset".equalsIgnoreCase(command)) {
            output = ScreenModeService.resetFloatingPosition()
                    ? "SUCCESS: Posisi Floating Bot dikembalikan." : "ERROR: Floating Bot belum aktif.";
        } else if ("/floating_position".equalsIgnoreCase(command)) {
            output = ScreenModeService.floatingPosition();
        } else {
            output = terminal.execute(this, command);
        }

        if (!wasWaitingForKey && !containsInlineKey) appendTerminal("> " + command);
        else appendTerminal("> [INPUT DISEMBUNYIKAN]");
        appendTerminal(output);
        terminalInput.setText("");
        terminalInput.setInputType(terminal.isAwaitingApiKey()
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT);
        terminalInput.setHint(terminal.isAwaitingApiKey() ? "API key disamarkan" : "ketik command...");
        refreshStatus();
    }

    private void appendTerminal(String line) {
        if (terminalOutput == null) return;
        String current = terminalOutput.getText().toString();
        String next = current + "\n" + line;
        if (next.length() > 12000) next = next.substring(next.length() - 12000);
        terminalOutput.setText(next);
        if (terminalScroll != null) terminalScroll.post(() -> terminalScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void stopScreenService() {
        stopService(new Intent(this, ScreenModeService.class));
    }

    private void refreshStatus() {
        // Status is queried on demand through terminal commands; no dashboard panels are shown.
    }

    private TextView makeText(String value, int color, float size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }
    @Override
    protected void onDestroy() {
        if (isFinishing() && PinManager.isEnabled(this)) {
            PinManager.setSessionUnlocked(false);
        }
        super.onDestroy();
    }

}
