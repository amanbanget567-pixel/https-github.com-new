package com.cbt.helper;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.LruCache;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenModeService extends Service {
    private static final String CHANNEL_ID = "tatsumaki_screen_assist";
    private static final int NOTIFICATION_ID = 4101;
    private static final int CLICK_THRESHOLD = 10;
    
    // VARIABEL FITUR BARU
    private long autoScanInterval = 15000L; 
    private boolean autoPilotEnabled = false;
    private int totalSolved = 0;

    private static volatile boolean active;
    private static volatile boolean projectionActive;
    private static volatile ScreenModeService instance;

    private MediaProjection mediaProjection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private WindowManager windowManager;

    private LinearLayout mainContainer;
    private ImageView botImage;
    private LinearLayout menuLayout;
    private TextView textResult;
    private TextView textDevInfo;
    private TextView textStats;
    private Button autoScanButton;
    private Button manualScanButton;
    private Button askTextButton;
    private Button speedButton;
    private Button autoPilotButton;
    private Button themeButton;
    private Button autoScrollButton;
    private WindowManager.LayoutParams layoutParams;

    private boolean menuOpen;
    private boolean autoScanEnabled;
    private boolean projectionStopped;
    private boolean isDarkTheme = true;
    
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService captureExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analysisInProgress = new AtomicBoolean(false);
    private final LruCache<String, String> answerCache = new LruCache<>(30);
    private int requestCount;
    private int displayWidth;
    private int displayHeight;
    private int displayDensity;

    private int initialX;
    private int initialY;
    private int initialTouchX;
    private int initialTouchY;
    private boolean dragging;
    private android.animation.ObjectAnimator floatingAnimator;
    private android.animation.AnimatorSet clickAnimator;

    public static boolean isActive() { return active; }
    public static boolean isProjectionActive() { return projectionActive; }

    public static boolean setFloatingVisible(boolean visible) {
        ScreenModeService service = instance;
        if (service == null || service.mainContainer == null) return false;
        service.mainHandler.post(() -> {
            if (service.mainContainer != null) service.mainContainer.setVisibility(visible ? View.VISIBLE : View.GONE);
        });
        return true;
    }

    public static boolean resetFloatingPosition() {
        ScreenModeService service = instance;
        if (service == null || service.layoutParams == null || service.windowManager == null || service.mainContainer == null) return false;
        service.mainHandler.post(() -> {
            if (service.layoutParams != null && service.mainContainer != null) {
                service.layoutParams.x = service.dp(24);
                service.layoutParams.y = service.dp(120);
                try { service.windowManager.updateViewLayout(service.mainContainer, service.layoutParams); } catch (Exception ignored) { }
            }
        });
        return true;
    }

    public static String floatingPosition() {
        ScreenModeService service = instance;
        if (service == null || service.layoutParams == null) return "Floating Bot tidak aktif.";
        float density = service.getResources().getDisplayMetrics().density;
        return "Floating Bot position: X=" + Math.round(service.layoutParams.x / density) + "dp, Y=" + Math.round(service.layoutParams.y / density) + "dp";
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startForegroundNotification();
        } catch (Exception e) {
            Log.e("TatsumakiAI", "Gagal memulai foreground notification Screen Assist", e);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (intent == null) { stopSelf(startId); return START_NOT_STICKY; }
        if (mediaProjection != null || active) { return START_NOT_STICKY; }

        int resultCode = intent.getIntExtra("code", 0);
        Intent resultData = getProjectionResultData(intent);
        if (resultCode != android.app.Activity.RESULT_OK || resultData == null) { stopSelf(startId); return START_NOT_STICKY; }

        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (manager == null) throw new IllegalStateException("MediaProjectionManager tidak tersedia.");
            mediaProjection = manager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) throw new IllegalStateException("Izin screen capture tidak valid.");

            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    super.onStop();
                    projectionStopped = true; projectionActive = false; active = false;
                    releaseCaptureResources(false); stopSelf();
                }
            };
            mediaProjection.registerCallback(projectionCallback, mainHandler);
            setupVirtualDisplay(); setupFloatingBot(); projectionActive = true; active = true; updateDeveloperInfo();
        } catch (Exception e) {
            showStatus("Gagal memulai screen assist: " + safeMessage(e)); stopSelf(startId); return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    private Intent getProjectionResultData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) return intent.getParcelableExtra("data", Intent.class);
        return intent.getParcelableExtra("data");
    }

    private void startForegroundNotification() {
        createNotificationChannel();
        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Tatsumaki Screen Assist aktif")
                    .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build();
        } else {
            notification = new Notification.Builder(this).setContentTitle("Tatsumaki Screen Assist aktif").setSmallIcon(android.R.drawable.ic_menu_camera).build();
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Screen Assist", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void setupVirtualDisplay() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        displayWidth = metrics.widthPixels; displayHeight = metrics.heightPixels; displayDensity = metrics.densityDpi;
        imageReader = ImageReader.newInstance(displayWidth, displayHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay("TatsumakiCapture", displayWidth, displayHeight,
                displayDensity, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);
        if (virtualDisplay == null) {
            throw new IllegalStateException("VirtualDisplay tidak berhasil dibuat.");
        }
    }

    private final Runnable autoScanRunnable = new Runnable() {
        @Override public void run() {
            if (autoScanEnabled && active) { captureScreen(); mainHandler.postDelayed(this, autoScanInterval); }
        }
    };

    private void startAutoScan() {
        mainHandler.removeCallbacks(autoScanRunnable); autoScanEnabled = true;
        if (autoScanButton != null) {
            autoScanButton.setText("⏹ AUTO SCAN: ON");
            autoScanButton.setTextColor(Color.parseColor("#FF4444"));
        }
        setResultText("> Auto Scan aktif. Mencari soal...");
        mainHandler.postDelayed(autoScanRunnable, 1200L);
    }

    private boolean isCurrentSession() {
        return active && instance == this;
    }

    private void stopAutoScan() {
        autoScanEnabled = false; mainHandler.removeCallbacks(autoScanRunnable);
        if (autoScanButton != null) {
            autoScanButton.setText("▶ AUTO SCAN: OFF");
            autoScanButton.setTextColor(isDarkTheme ? Color.parseColor("#00FF75") : Color.parseColor("#000000"));
        }
        if (textResult != null && active) textResult.setText("> Auto Scan nonaktif.");
    }

    private void toggleMenu() { if (menuLayout != null) { menuOpen = !menuOpen; menuLayout.setVisibility(menuOpen ? View.VISIBLE : View.GONE); } }

    private void showTextInputDialog() {
        EditText input = new EditText(this); input.setTextColor(Color.BLACK); input.setHint("Ketik atau paste teks di sini...");
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Tanya Tatsumaki").setView(input)
                .setNegativeButton("BATAL", (d, which) -> { })
                .setPositiveButton("TANYA", (d, which) -> { String text = input.getText() == null ? "" : input.getText().toString().trim(); if (text.isEmpty()) setResultText("> Teks masih kosong."); else askText(text); }).create();
        Window dialogWindow = dialog.getWindow();
        if (dialogWindow != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) dialogWindow.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            dialogWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        try { dialog.show(); } catch (Exception e) { setResultText("> Dialog tidak dapat dibuka: " + safeMessage(e)); }
    }

    private void startFloatingAnimation() {
        if (botImage == null) return; stopFloatingAnimation();
        floatingAnimator = android.animation.ObjectAnimator.ofFloat(botImage, "translationY", -dp(6), dp(6));
        floatingAnimator.setDuration(1500); floatingAnimator.setRepeatMode(android.animation.ValueAnimator.REVERSE); floatingAnimator.setRepeatCount(android.animation.ValueAnimator.INFINITE); floatingAnimator.start();
    }

    private void stopFloatingAnimation() { if (floatingAnimator != null) { floatingAnimator.cancel(); floatingAnimator = null; } }

    private void startClickAnimation() {
        if (botImage == null) return; stopFloatingAnimation();
        if (clickAnimator != null) clickAnimator.cancel();
        android.animation.ObjectAnimator scaleX = android.animation.ObjectAnimator.ofFloat(botImage, "scaleX", 1f, 0.82f, 1f);
        android.animation.ObjectAnimator scaleY = android.animation.ObjectAnimator.ofFloat(botImage, "scaleY", 1f, 0.82f, 1f);
        clickAnimator = new android.animation.AnimatorSet(); clickAnimator.playTogether(scaleX, scaleY); clickAnimator.setDuration(280);
        clickAnimator.addListener(new android.animation.AnimatorListenerAdapter() { @Override public void onAnimationEnd(android.animation.Animator animation) { if (active) startFloatingAnimation(); } });
        clickAnimator.start();
    }

    private void captureScreen() {
        if (!AppPreferences.isAiEnabled(this)) { stopAutoScan(); setResultText("> AI nonaktif."); return; }
        if (!active || imageReader == null || captureExecutor.isShutdown()
                || !analysisInProgress.compareAndSet(false, true)) {
            if (analysisInProgress.get()) setResultText("> Permintaan sebelumnya masih diproses."); else setResultText("> Screen capture belum siap."); return;
        }
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) { analysisInProgress.set(false); setResultText("> Frame belum tersedia."); return; }
            final Image capturedImage = image;
            captureExecutor.execute(() -> processCapturedImage(capturedImage));
        } catch (Exception e) {
            if (image != null) image.close(); analysisInProgress.set(false); setResultText("> Gagal ambil layar: " + safeMessage(e));
        }
    }

    private void processCapturedImage(Image image) {
        Bitmap paddedBitmap = null; Bitmap outputBitmap = null;
        try {
            if (image.getPlanes() == null || image.getPlanes().length == 0) throw new IllegalStateException("Data frame tidak tersedia.");
            Image.Plane plane = image.getPlanes()[0]; ByteBuffer buffer = plane.getBuffer().duplicate();
            int pixelStride = plane.getPixelStride(); int rowStride = plane.getRowStride();
            if (pixelStride <= 0 || rowStride <= 0) throw new IllegalStateException("Stride gambar tidak valid.");
            int width = image.getWidth(); int height = image.getHeight(); int paddedWidth = rowStride / pixelStride;
            if (paddedWidth < width) throw new IllegalStateException("Ukuran buffer gambar tidak valid.");
            paddedBitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
            buffer.rewind(); paddedBitmap.copyPixelsFromBuffer(buffer);
            if (paddedWidth == width) { outputBitmap = paddedBitmap; paddedBitmap = null; } else { outputBitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, width, height); }
        } catch (Exception e) { showStatus("> Gagal proses frame: " + safeMessage(e));
        } finally { image.close(); if (paddedBitmap != null && !paddedBitmap.isRecycled()) paddedBitmap.recycle(); }

        if (outputBitmap == null) { analysisInProgress.set(false); return; }
        final Bitmap bitmapForEncoding = outputBitmap;
        try { captureExecutor.execute(() -> encodeAndSend(bitmapForEncoding)); } catch (Exception e) {
            if (!bitmapForEncoding.isRecycled()) bitmapForEncoding.recycle(); analysisInProgress.set(false); showStatus("> Gagal jalankan encoder: " + safeMessage(e));
        }
    }

    private void encodeAndSend(Bitmap bitmap) {
        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            boolean compressed = bitmap.compress(Bitmap.CompressFormat.JPEG, 65, output);
            if (!compressed) throw new IllegalStateException("Kompresi gambar gagal.");
            String base64 = Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
            requestCount++; showAnswerResult("> Menganalisis gambar..."); updateDeveloperInfo();

            GeminiHelper.askImage(getApplicationContext(), base64, false, new GeminiHelper.Callback() {
                @Override public void onSuccess(String result) {
                    analysisInProgress.set(false);
                    if (!isCurrentSession()) return;
                    answerCache.put("last_image", result);
                    showAnswerResult("> AI Menjawab:\n" + result);
                    
                    totalSolved++; // Statistik
                    if (textStats != null) textStats.setText("Jawaban AI: " + totalSolved);

                    AutoKkmService autoKkm = AutoKkmService.getInstance();
                    if (autoKkm != null) {
                        autoKkm.performClickByText(result);
                        // Mode Cheater
                        if (autoPilotEnabled) {
                            mainHandler.postDelayed(() -> {
                                if (isCurrentSession() && autoPilotEnabled
                                        && AutoKkmService.getInstance() == autoKkm) {
                                    autoKkm.clickNextButton();
                                }
                            }, 1000);
                        }
                    }
                    updateDeveloperInfo();
                }
                @Override public void onError(String error) {
                    analysisInProgress.set(false);
                    if (!isCurrentSession()) return;
                    if (error != null && (error.toLowerCase(java.util.Locale.ROOT).contains("batas lokal harian")
                            || error.toLowerCase(java.util.Locale.ROOT).contains("api error 429"))) { stopAutoScan(); showAnswerResult("> Auto Scan dihentikan. " + error); } else { showAnswerResult("> Gagal: " + error); }
                    updateDeveloperInfo();
                }
            });
        } catch (Exception e) { analysisInProgress.set(false); showStatus("> Gagal siapkan gambar: " + safeMessage(e));
        } finally { if (!bitmap.isRecycled()) bitmap.recycle(); }
    }

    private void askText(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String cached = answerCache.get(text); if (cached != null) { setResultText("> (Cache) " + cached); return; }
        setResultText("> Memproses teks...");
        GeminiHelper.askText(getApplicationContext(), text, false, new GeminiHelper.Callback() {
            @Override public void onSuccess(String result) {
                if (!isCurrentSession()) return;
                answerCache.put(text, result); showAnswerResult("> " + result); updateDeveloperInfo();
            }
            @Override public void onError(String error) {
                if (!isCurrentSession()) return;
                showAnswerResult("> Error: " + error); updateDeveloperInfo();
            }
        });
    }

    private void updateDeveloperInfo() {
        if (textDevInfo == null) return;
        mainHandler.post(() -> { if (textDevInfo != null) textDevInfo.setText("Sesi: Aktif | Capture: " + requestCount); });
    }

    private void setResultText(String text) {
        mainHandler.post(() -> {
            if (textResult != null) textResult.setText(text == null ? "" : text);
        });
    }

    /** Ensure AI answers and API errors are visible instead of remaining inside the closed menu. */
    private void showAnswerResult(String text) {
        mainHandler.post(() -> {
            if (textResult != null) textResult.setText(text == null ? "" : text);
            if (menuLayout != null && menuLayout.getVisibility() != View.VISIBLE) {
                menuOpen = true;
                menuLayout.setVisibility(View.VISIBLE);
            }
        });
    }

    private void showStatus(String text) { setResultText(text); }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private String safeMessage(Exception e) { String message = e == null ? null : e.getMessage(); return message == null || message.trim().isEmpty() ? "kesalahan tidak diketahui" : (message.length() > 160 ? message.substring(0, 160) : message); }

    private void setupFloatingBot() {
        if (!Settings.canDrawOverlays(this)) { showStatus("Izin overlay tidak aktif."); return; }
        
        layoutParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_SECURE, PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START; layoutParams.x = dp(24); layoutParams.y = dp(120);

        mainContainer = new LinearLayout(this); mainContainer.setOrientation(LinearLayout.VERTICAL); mainContainer.setPadding(dp(4), dp(4), dp(4), dp(4));
        
        updateContainerTheme();

        FrameLayout dragHandle = new FrameLayout(this); dragHandle.setLayoutParams(new LinearLayout.LayoutParams(dp(56), dp(56)));
        botImage = new ImageView(this);
        botImage.setImageResource(R.drawable.bot_lucu);
        botImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        botImage.setAdjustViewBounds(true);
        dragHandle.addView(botImage, new FrameLayout.LayoutParams(-1, -1)); mainContainer.addView(dragHandle);

        menuLayout = new LinearLayout(this); menuLayout.setOrientation(LinearLayout.VERTICAL); menuLayout.setVisibility(View.GONE); menuLayout.setPadding(dp(8), dp(8), dp(8), dp(8));

        textResult = new TextView(this); textResult.setTextColor(isDarkTheme ? Color.WHITE : Color.BLACK); textResult.setTextSize(12); textResult.setText("> Menunggu perintah..."); textResult.setMaxWidth(dp(200)); menuLayout.addView(textResult);
        
        textDevInfo = new TextView(this); textDevInfo.setTextColor(isDarkTheme ? Color.LTGRAY : Color.DKGRAY); textDevInfo.setTextSize(10); textDevInfo.setText("Sesi: Aktif | Capture: 0"); menuLayout.addView(textDevInfo);
        
        textStats = new TextView(this); textStats.setTextColor(Color.parseColor("#00FF75")); textStats.setTextSize(10); textStats.setText("Jawaban AI: 0"); menuLayout.addView(textStats);

        autoScanButton = new Button(this); autoScanButton.setText("▶ AUTO SCAN: OFF"); autoScanButton.setTextSize(11); autoScanButton.setBackgroundColor(Color.parseColor("#333333")); autoScanButton.setTextColor(Color.parseColor("#00FF75"));
        autoScanButton.setOnClickListener(v -> { if (autoScanEnabled) stopAutoScan(); else startAutoScan(); startClickAnimation(); }); menuLayout.addView(autoScanButton);

        manualScanButton = new Button(this); manualScanButton.setText("MANUAL SCAN");
        manualScanButton.setTextSize(11); manualScanButton.setBackgroundColor(Color.parseColor("#333333"));
        manualScanButton.setTextColor(Color.WHITE);
        manualScanButton.setOnClickListener(v -> { captureScreen(); startClickAnimation(); });
        menuLayout.addView(manualScanButton);

        askTextButton = new Button(this); askTextButton.setText("TANYA TEKS");
        askTextButton.setTextSize(11); askTextButton.setBackgroundColor(Color.parseColor("#333333"));
        askTextButton.setTextColor(Color.WHITE);
        askTextButton.setOnClickListener(v -> { showTextInputDialog(); startClickAnimation(); });
        menuLayout.addView(askTextButton);

        autoScrollButton = new Button(this);
        autoScrollButton.setText("AUTO SCROLL: OFF");
        autoScrollButton.setTextSize(11);
        autoScrollButton.setBackgroundColor(Color.parseColor("#333333"));
        autoScrollButton.setTextColor(Color.WHITE);
        autoScrollButton.setOnClickListener(v -> {
            AutoKkmService accessibility = AutoKkmService.getInstance();
            if (accessibility == null) {
                showStatus("> Aktifkan layanan Bantuan Interaksi di Pengaturan Aksesibilitas Android.");
                return;
            }
            accessibility.setAutoScrollListener(running -> mainHandler.post(() -> {
                if (autoScrollButton != null) autoScrollButton.setText(running ? "AUTO SCROLL: ON" : "AUTO SCROLL: OFF");
            }));
            if (accessibility.isAutoScrolling()) {
                accessibility.stopAutoScroll();
                showStatus("> Auto Scroll dihentikan.");
            } else if (accessibility.startAutoScroll()) {
                showStatus("> Auto Scroll aktif. Tekan tombol lagi untuk berhenti; batas perlindungan 120 langkah.");
            } else {
                showStatus("> Tidak ada halaman aktif yang bisa digulir.");
            }
        });
        menuLayout.addView(autoScrollButton);

        Button fillGradeButton = new Button(this);
        fillGradeButton.setText("ISI NILAI TERAKHIR (SETUJU)");
        fillGradeButton.setTextSize(11);
        fillGradeButton.setBackgroundColor(Color.parseColor("#245A3A"));
        fillGradeButton.setTextColor(Color.WHITE);
        fillGradeButton.setOnClickListener(v -> fillApprovedAssessmentField(false));
        menuLayout.addView(fillGradeButton);

        Button fillCommentButton = new Button(this);
        fillCommentButton.setText("ISI KOMENTAR TERAKHIR");
        fillCommentButton.setTextSize(11);
        fillCommentButton.setBackgroundColor(Color.parseColor("#245A3A"));
        fillCommentButton.setTextColor(Color.WHITE);
        fillCommentButton.setOnClickListener(v -> fillApprovedAssessmentField(true));
        menuLayout.addView(fillCommentButton);

        speedButton = new Button(this); speedButton.setText("Kecepatan: 15 Detik"); speedButton.setTextSize(11); speedButton.setBackgroundColor(Color.parseColor("#333333")); speedButton.setTextColor(Color.WHITE);
        speedButton.setOnClickListener(v -> {
            if (autoScanInterval == 15000L) { autoScanInterval = 5000L; speedButton.setText("Kecepatan: 5 Detik"); }
            else if (autoScanInterval == 5000L) { autoScanInterval = 30000L; speedButton.setText("Kecepatan: 30 Detik"); }
            else { autoScanInterval = 15000L; speedButton.setText("Kecepatan: 15 Detik"); }
        }); menuLayout.addView(speedButton);

        autoPilotButton = new Button(this); autoPilotButton.setText("Mode Cheater: OFF"); autoPilotButton.setTextSize(11); autoPilotButton.setBackgroundColor(Color.parseColor("#333333")); autoPilotButton.setTextColor(Color.WHITE);
        autoPilotButton.setOnClickListener(v -> {
            autoPilotEnabled = !autoPilotEnabled;
            autoPilotButton.setText("Mode Cheater: " + (autoPilotEnabled ? "ON" : "OFF"));
            autoPilotButton.setTextColor(autoPilotEnabled ? Color.parseColor("#00FF75") : Color.WHITE);
        }); menuLayout.addView(autoPilotButton);

        themeButton = new Button(this); themeButton.setText("Tema: Gelap"); themeButton.setTextSize(11); themeButton.setBackgroundColor(Color.parseColor("#333333")); themeButton.setTextColor(Color.WHITE);
        themeButton.setOnClickListener(v -> {
            isDarkTheme = !isDarkTheme;
            themeButton.setText("Tema: " + (isDarkTheme ? "Gelap" : "Terang"));
            updateContainerTheme();
            textResult.setTextColor(isDarkTheme ? Color.WHITE : Color.BLACK);
            textDevInfo.setTextColor(isDarkTheme ? Color.LTGRAY : Color.DKGRAY);
        }); menuLayout.addView(themeButton);

        Button btnHide = new Button(this); btnHide.setText("Sembunyikan"); btnHide.setTextSize(11); btnHide.setBackgroundColor(Color.parseColor("#FF4444")); btnHide.setTextColor(Color.WHITE);
        btnHide.setOnClickListener(v -> setFloatingVisible(false)); menuLayout.addView(btnHide);

        mainContainer.addView(menuLayout, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dragHandle.setOnClickListener(v -> toggleMenu());
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = layoutParams.x; initialY = layoutParams.y; initialTouchX = (int) event.getRawX(); initialTouchY = (int) event.getRawY(); dragging = false; return false;
                    case MotionEvent.ACTION_MOVE:
                        int deltaX = (int) event.getRawX() - initialTouchX; int deltaY = (int) event.getRawY() - initialTouchY;
                        if (Math.abs(deltaX) > CLICK_THRESHOLD || Math.abs(deltaY) > CLICK_THRESHOLD) {
                            dragging = true; layoutParams.x = initialX + deltaX; layoutParams.y = initialY + deltaY;
                            try { windowManager.updateViewLayout(mainContainer, layoutParams); } catch (Exception ignored) { }
                        }
                        return false;
                    default: return false;
                }
            }
        });

        try { windowManager.addView(mainContainer, layoutParams); startFloatingAnimation(); } catch (Exception e) { showStatus("Gagal tampilkan floating bot: " + safeMessage(e)); }
    }

    private void fillApprovedAssessmentField(boolean comment) {
        AutoKkmService accessibility = AutoKkmService.getInstance();
        if (accessibility == null) {
            showStatus("> Layanan Bantuan Interaksi belum aktif.");
            return;
        }
        String value = comment ? AssessmentStore.getComment(this) : AssessmentStore.getGrade(this);
        if (value == null || value.trim().isEmpty()) {
            showStatus("> Belum ada " + (comment ? "komentar" : "nilai") + " yang disetujui guru.");
            return;
        }
        boolean filled = accessibility.fillTextIntoFocusedField(value);
        if (filled) {
            showStatus("> " + (comment ? "Komentar" : "Nilai") + " terakhir berhasil dimasukkan ke kolom yang sedang fokus. Periksa sebelum menyimpan di aplikasi tujuan.");
        } else {
            showStatus("> Gagal mengisi. Fokuskan kolom teks/nilai yang dapat diedit pada aplikasi tujuan, lalu tekan tombol ini lagi.");
        }
    }

    private void updateContainerTheme() {
        if (mainContainer == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(isDarkTheme ? "#CC000000" : "#CCFFFFFF"));
        bg.setCornerRadius(dp(16)); mainContainer.setBackground(bg);
    }

    private void releaseCaptureResources(boolean stopProjection) {
        stopAutoScan(); stopFloatingAnimation();
        if (clickAnimator != null) { clickAnimator.cancel(); clickAnimator = null; }
        if (virtualDisplay != null) { try { virtualDisplay.release(); } catch (Exception ignored) { } virtualDisplay = null; }
        if (imageReader != null) { try { imageReader.setOnImageAvailableListener(null, null); } catch (Exception ignored) { } try { imageReader.close(); } catch (Exception ignored) { } imageReader = null; }
        if (mainContainer != null && windowManager != null) { try { if (mainContainer.getParent() != null) windowManager.removeViewImmediate(mainContainer); } catch (Exception ignored) { } mainContainer = null; }
        analysisInProgress.set(false);
        botImage = null; menuLayout = null; textResult = null; textDevInfo = null; textStats = null;
        autoScanButton = null; manualScanButton = null; askTextButton = null;
        speedButton = null; autoPilotButton = null; themeButton = null; autoScrollButton = null;
        AutoKkmService accessibility = AutoKkmService.getInstance();
        if (accessibility != null) {
            accessibility.setAutoScrollListener(null);
            accessibility.stopAutoScroll();
        }

        if (stopProjection && mediaProjection != null && !projectionStopped) {
            projectionStopped = true;
            try { if (projectionCallback != null) mediaProjection.unregisterCallback(projectionCallback); } catch (Exception ignored) { }
            try { mediaProjection.stop(); } catch (Exception ignored) { }
        }
        if (stopProjection) mediaProjection = null;
        if (captureExecutor != null && !captureExecutor.isShutdown()) captureExecutor.shutdownNow();
    }

    @Override public void onDestroy() {
        active = false; projectionActive = false; if (instance == this) instance = null; releaseCaptureResources(true);
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
