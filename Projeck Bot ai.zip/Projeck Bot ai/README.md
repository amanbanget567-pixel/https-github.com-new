# Tatsumaki AI / CBT Helper — Android Studio Project

Versi sumber: **1.1.2**.

Project ini mempertahankan aset, floating bot, Text Mode, sesi screen capture berbasis izin Android, API Key Manager terenkripsi, diagnostics, usage monitor, dan command router sambil merapikan halaman utama sesuai desain terminal. Pembaruan 1.1.2 memusatkan halaman utama pada terminal, memindahkan pengelolaan API Key ke command, menambahkan PIN opsional dan AI Control, serta memperbaiki statistik penggunaan dan navigasi command.

## Fitur yang tersedia

- Halaman utama menggunakan tampilan terminal hitam-hijau monospaced dengan judul `TATSUMAKI TERMINAL`, satu command awal `[1] /Listcommaind`, dan prompt `>`. Command lain baru ditampilkan setelah `/Listcommaind` dipanggil.
- Welcome/Copyright tidak ditampilkan di halaman utama; judul terminal tetap.
- API Key Manager hanya dapat dioperasikan melalui command terminal, bukan panel Settings.
- Floating bot dengan animasi, menu, kontrol transparansi, dan posisi yang bisa dipindahkan.
- Screen Assist menggunakan MediaProjection setelah persetujuan Android dan foreground service yang terlihat oleh sistem.
- Scan manual dan Auto Scan yang hanya mulai setelah pengguna menyalakannya. Interval Auto Scan adalah 15 detik; permintaan diserialkan melalui antrean OkHttp dan kuota resmi tetap ditentukan Google.
- Text Mode dan input teks melalui floating bot.
- API Key Manager dengan AES/GCM dan kunci enkripsi yang disimpan di Android Keystore.
- System Diagnostics melalui command untuk status API, overlay, notifikasi, jaringan, service, projection, RAM, storage, CPU/ABI, uptime, dan versi.
- Usage Monitor lokal untuk jumlah request, berhasil/gagal, perkiraan byte terkirim, statistik hari/bulan, dan waktu request terakhir. Kuota resmi tetap mengikuti project Google AI Studio; tidak ada angka kuota lokal yang diklaim sebagai kuota Google.
- AI Control melalui command untuk mengaktifkan/menonaktifkan AI, melihat model/status, mengubah gaya persona, dan membatalkan request aktif.
- Floating Bot dapat ditampilkan/disembunyikan dan posisinya direset melalui command saat sesi aktif.
- PIN aplikasi opsional (default OFF), diaktifkan/diubah/dimatikan dari menu Security Settings (ikon ⋮ di header terminal, bukan command); PIN diverifikasi menggunakan hash PBKDF2 salted, bukan plaintext.
- Terminal dengan perintah allowlist; tidak menjalankan shell bebas.
- Accessibility Text Assist nonaktif secara default dan hanya bekerja setelah pengguna mengaktifkan sakelar pada Security Settings serta mengaktifkan Accessibility Service Android.
- Screenshot protection menggunakan `FLAG_SECURE` pada Activity milik Tatsumaki dan pada window Floating Bot. Perilaku overlay perlu diuji pada perangkat Android karena implementasi OEM dapat berbeda; ini tidak menyembunyikan konten aplikasi lain.

## Gemini API dan Free Tier

Aplikasi menggunakan endpoint `gemini-2.5-flash:generateContent` untuk permintaan teks dan gambar. API key dikirim melalui header `x-goog-api-key`. Tidak ada fallback otomatis ke model lain atau model berbayar.

Gemini 2.5 Flash tercantum dengan harga input dan output **gratis pada Free Tier**. Batas RPM, TPM, dan RPD ditentukan menurut project dan tingkat penggunaan; angka yang aktif harus dilihat di AI Studio. Batas request dihitung pada tingkat project, bukan per API key. Lihat dokumentasi resmi:

- Pricing: https://ai.google.dev/gemini-api/docs/pricing
- Rate limits: https://ai.google.dev/gemini-api/docs/rate-limits
- GenerateContent: https://ai.google.dev/api/generate-content

Aplikasi tidak memaksakan angka RPM/RPD lokal yang belum tentu cocok dengan project pengguna. Request dicatat oleh Usage Monitor, sementara batas RPM/TPM/RPD resmi diterapkan oleh Google pada tingkat project. Auto Scan memakai interval 15 detik untuk mengurangi intensitas request. Jika Google mengembalikan HTTP 429, aplikasi menampilkan batas penggunaan yang dikembalikan layanan; pengguna perlu menunggu sesuai kebijakan Google.

**Penting mengenai biaya:** kode aplikasi tidak bisa memaksa project Google tetap berada di Free Tier. Kalau project API key di AI Studio/Google Cloud ditautkan ke billing aktif atau dinaikkan ke tier berbayar, Google dapat menagih sesuai ketentuan project tersebut. Untuk benar-benar menghindari biaya, pastikan project tetap pada Free Tier dan jangan mengaktifkan billing. Saat kuota habis, aplikasi menampilkan error dan tidak mengganti model secara otomatis.

## Screenshot protection

Android tidak menyediakan API umum bagi aplikasi untuk mengganti isi screenshot sistem dengan tulisan buatan aplikasi. Karena itu, fitur tulisan khusus `YOU ARE IDIOT` **tidak diklaim sudah dibuat**. Versi ini memakai `FLAG_SECURE` sebagai fallback: Android akan menyembunyikan, menghitamkan, atau memblokir konten window yang dilindungi saat screenshot/screen recording, bergantung pada perangkat dan versi Android. Tidak ada manipulasi screenshot perangkat lain.

Perlindungan dipasang pada MainActivity, TextModeActivity, ScreenModeActivity, PinGateActivity, PinSettingsActivity, dan window Floating Bot. Window Floating Bot juga diberi `FLAG_SECURE`; Android dapat menyembunyikan window overlay tersebut, tetapi hasilnya harus diuji pada perangkat dan tidak menjamin isi aplikasi lain ikut hitam. Hasil akhirnya tetap perlu diuji pada perangkat Android sebenarnya.

## Ghost Mode

Mode yang memantau semua sentuhan global atau menyembunyikan floating bot secara otomatis tidak ditambahkan. Android tidak menyediakan listener sentuhan global biasa untuk aplikasi; pendekatan semacam itu memerlukan pemantauan Accessibility/overlay yang lebih invasif dan dapat menyamarkan overlay dari aplikasi lain. Fitur tersebut tidak boleh dianggap tersedia pada versi ini.

## Persyaratan build

- Android Studio yang mendukung Android Gradle Plugin 8.3.0.
- JDK 17.
- Android SDK Platform 34.
- Gradle 8.4 atau lebih baru yang kompatibel dengan Android Gradle Plugin 8.3.0.
- Perangkat Android minimum API 26.

**Catatan:** ZIP sumber tidak menyertakan Gradle Wrapper. Buka project dengan Android Studio, gunakan JDK 17 dan Android SDK Platform 34, lakukan Gradle Sync, lalu jalankan `assembleDebug`. Workflow GitHub Actions tersedia di `.github/workflows/android-build.yml`; setelah project didorong ke branch `main` atau workflow dijalankan manual, APK debug akan diunggah sebagai artifact `Tatsumaki-debug-apk`. Build CI dan uji perangkat tetap harus benar-benar dijalankan sebelum menyatakan APK siap.

## Menyiapkan Gemini API

1. Buat atau pilih project di Google AI Studio.
2. Pastikan project menunjukkan **Free Tier** dan tidak ditautkan ke billing berbayar bila ingin menghindari biaya.
3. Buat API key sesuai petunjuk AI Studio.
4. Buka terminal Tatsumaki.
5. Ketik `/set_new_api_key`, lalu masukkan key pada baris berikutnya yang disamarkan.
6. Jika key lama sudah tersimpan, ketik `/confirm_change` sebelum memasukkan key baru; gunakan `/cancel` untuk membatalkan.
7. Jalankan `/check_api_key` atau `/diagnostics`, lalu uji permintaan teks dan gambar.

## Keamanan API key

- Nilai key yang sebelumnya tertanam dalam source telah dihapus dari source project ini.
- Penyimpanan Android Keystore melindungi key saat tersimpan di perangkat, tetapi bukan pengganti backend proxy dan tidak membuat key mustahil diekstrak dari perangkat yang telah dikompromikan.
- Jangan pernah mengirim ZIP yang berisi API key aktif.

## Screen capture dan lifecycle

- Setiap sesi capture meminta izin Android yang baru.
- Satu izin pengguna digunakan untuk satu sesi VirtualDisplay.
- `MediaProjection.Callback` didaftarkan sebelum `createVirtualDisplay()`.
- Service memakai `START_NOT_STICKY`; token MediaProjection tidak dipulihkan setelah proses dihentikan.
- Pengguna dapat menghentikan service melalui command `/stop` atau kontrol sistem Android.
- Auto Scan hanya dimulai setelah pengguna menyalakannya dari menu floating bot.

## Accessibility Text Assist

Fitur ini mati secara default. Ketika diaktifkan, service dapat membaca teks jendela aplikasi aktif dan mengirimkannya ke Gemini sesuai interval dan antrean request aplikasi. Aktifkan hanya pada aplikasi dan data yang memang boleh dianalisis. Matikan sakelar aplikasi dan nonaktifkan Accessibility Service Android untuk menghentikan kemampuan tersebut.

## Terminal command

Semua command diawali `/`. Nomor pada `/Listcommaind` hanya penanda daftar, bukan input command. Command yang tersedia pada versi ini:

| Perintah | Fungsi |
|---|---|
| `/Listcommaind` | Daftar seluruh command yang tersedia |
| `/help` | Petunjuk terminal |
| `/about` | Informasi aplikasi |
| `/set_new_api_key` | Simpan/ganti API Key; input berikutnya disamarkan |
| `/confirm_change` | Konfirmasi penggantian API Key lama |
| `/cancel` | Batalkan input/perubahan API Key |
| `/delete_api_key` | Hapus API Key; error jika belum ada |
| `/check_api_key` | Status API Key (nilai dimasking) |
| `/ai_on`, `/ai_off` | Aktifkan/nonaktifkan permintaan AI |
| `/ai_info`, `/ai_model` | Status dan model AI |
| `/ai_personality [gaya]` | Lihat/ubah gaya persona AI |
| `/ai_reset`, `/restart_ai` | Batalkan request AI yang sedang berjalan |
| `/start`, `/stop`, `/restart_service` | Mulai/hentikan sesi Screen Assist dengan izin Android |
| `/floating_on`, `/floating_off` | Tampilkan/sembunyikan Floating Bot saat sesi aktif |
| `/floating_position`, `/floating_reset` | Lihat/reset posisi Floating Bot |
| `/status`, `/diagnostics` | Status dan laporan diagnostik |
| `/system_info`, `/version`, `/uptime` | Informasi perangkat, versi, dan uptime |
| `/check_ram`, `/check_storage`, `/check_cpu` | Informasi memori, storage, dan CPU/ABI |
| `/check_service`, `/check_overlay`, `/check_projection` | Status service dan izin |
| `/check_screenshot_protection` | Status `FLAG_SECURE` pada window Tatsumaki |
| `/check_network`, `/ping` | Status koneksi jaringan |
| `/usage`, `/usage_today`, `/usage_month`, `/usage_limit` | Statistik penggunaan dan keterangan kuota |
| `/reset_usage` | Reset statistik lokal; tidak mereset kuota Google |
| `/clear_cache` | Hapus cache aplikasi |
| `/text_mode` | Buka Text Mode |
| `/last_auto_text` | Lihat hasil Accessibility Text Assist terakhir |

Command yang memerlukan perpindahan Activity atau alur izin ditangani oleh terminal utama. Terminal tidak menjalankan shell sistem bebas.

Lihat `AUDIT_REPORT.md` untuk status verifikasi dan keterbatasan build.
