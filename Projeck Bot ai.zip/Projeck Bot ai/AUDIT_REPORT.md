# Laporan Audit dan Perubahan — Tatsumaki AI

Tanggal: 8 November 2026  
Sumber: `Tatsumaki_AI_Android_Studio_v1.1.1.zip`  
Versi source hasil perubahan: **1.1.2**

## Ringkasan perubahan

| File | Perubahan |
|---|---|
| `MainActivity.java` | Halaman utama diubah menjadi terminal minimalis hitam-hijau. Hanya judul, satu command awal `[1] /Listcommaind`, prompt `>`, dan menu Security Settings. Panel API Key, diagnostics, usage, tombol Screen Assist, dan daftar fitur tidak lagi memenuhi halaman utama. |
| `TerminalCommandSystem.java` | Menambahkan `/Listcommaind`, daftar command bernomor, `/about`, konfirmasi ganti API Key, pembatalan, AI Control, diagnostics tambahan, usage period, dan penanganan error delete key kosong. Tetap allowlist; tidak menjalankan shell bebas. |
| `ApiKeyManager.java` | Mekanisme AES/GCM + Android Keystore yang sudah ada dipertahankan. API Key sekarang dikelola dari terminal. |
| `AppPreferences.java` | Menambahkan status AI ON/OFF dan persona AI yang tersimpan lokal; Accessibility Text Assist tetap opt-in dan default OFF. |
| `GeminiHelper.java` | Prompt persona dibaca dari preferensi; AI OFF menolak request; request OkHttp diserialkan (maksimum satu request aktif per dispatcher/host); error 429 menyertakan petunjuk `Retry-After` bila server mengirim header. Tidak ada fallback model otomatis. |
| `UsageMonitor.java` | Menghapus batas lokal buatan 5 RPM/100 RPD yang tidak mewakili kuota project. Statistik request, berhasil/gagal, byte terkirim, hari, dan bulan tetap dicatat. Kuota resmi mengikuti project Google. |
| `SystemDiagnostics.java` | Menambahkan informasi perangkat, storage, CPU/ABI, uptime, dan versi aplikasi. Nilai CPU yang ditampilkan adalah jumlah core/ABI, bukan load CPU real-time. |
| `ScreenModeService.java` | Menambahkan kontrol command untuk menampilkan/menyembunyikan Floating Bot dan reset/baca posisi ketika service aktif. Lifecycle MediaProjection yang sudah ada dipertahankan. |
| `PinManager.java` | Baru: PIN opsional dengan PBKDF2-HMAC-SHA256 + salt acak, 150.000 iterasi, dan verifikasi constant-time. Default PIN OFF. Ada lockout 30 detik setelah lima percobaan gagal. |
| `PinGateActivity.java` | Baru: layar PIN saat aplikasi dimulai ulang ketika PIN aktif; window dilindungi `FLAG_SECURE`. |
| `PinSettingsActivity.java` | Baru: aktifkan, ganti, atau nonaktifkan PIN melalui Settings; perubahan memerlukan PIN lama bila sudah aktif. Sakelar Accessibility Text Assist yang sebelumnya ada di halaman utama dipindahkan ke Settings agar fitur lama tetap bisa diatur. |
| `AndroidManifest.xml` | Mendaftarkan activity PIN, mengubah label aplikasi menjadi Tatsumaki AI, dan mengatur `adjustResize` pada terminal. |
| `app/build.gradle` | Versi dinaikkan ke 1.1.2 / versionCode 4. |
| `.github/workflows/android-build.yml` | Baru: workflow CI untuk menyiapkan JDK 17, Gradle 8.4, Android SDK 34, menjalankan `assembleDebug`, dan mengunggah APK debug sebagai artifact. Workflow belum dijalankan dari lingkungan ini. |
| `README.md` | Dokumentasi diperbarui untuk perilaku terminal, command, PIN, kuota, dan batas pengujian. |

## Command yang tersedia

`/Listcommaind` menampilkan daftar command bernomor. Nomor hanya label daftar, bukan input command. Semua command tetap harus diketik dengan awalan `/`.

Command utama: `/help`, `/about`, `/set_new_api_key`, `/confirm_change`, `/cancel`, `/delete_api_key`, `/check_api_key`, `/ai_on`, `/ai_off`, `/ai_info`, `/ai_model`, `/ai_personality`, `/ai_reset`, `/restart_ai`, `/start`, `/stop`, `/restart_service`, `/floating_on`, `/floating_off`, `/floating_position`, `/floating_reset`, `/status`, `/diagnostics`, `/system_info`, `/check_ram`, `/check_storage`, `/check_cpu`, `/check_network`, `/ping`, `/uptime`, `/version`, `/check_service`, `/check_overlay`, `/check_projection`, `/check_screenshot_protection`, `/usage`, `/usage_today`, `/usage_month`, `/usage_limit`, `/reset_usage`, `/clear_cache`, `/text_mode`, dan `/last_auto_text`.

`/settings` bukan command. PIN dan sakelar Accessibility Text Assist dikelola melalui menu Security Settings (ikon ⋮) di header terminal. API Key tidak dikelola dari Settings.

## Perbaikan perilaku yang diverifikasi secara statis

- `/delete_api_key` sekarang menghasilkan ERROR jika API Key belum tersimpan.
- `/set_new_api_key` meminta konfirmasi jika key lama sudah ada; `/confirm_change` melanjutkan input key; `/cancel` membatalkan.
- Input API Key dimasukkan dalam mode password dan baris inputnya tidak ditulis ke riwayat terminal.
- API Key tetap dienkripsi dengan AES/GCM dan Android Keystore.
- Halaman utama tidak lagi menampilkan panel API Key atau dashboard diagnostik/usage.
- Command yang ditampilkan di `/Listcommaind` dipetakan ke implementasi yang tersedia; tidak menampilkan placeholder command untuk chat history/export/debug log yang belum ada.
- AI OFF benar-benar memblokir permintaan teks/gambar; AI ON mengaktifkannya kembali.
- Request Gemini diserialkan agar tidak membanjiri endpoint secara bersamaan. HTTP 429 tetap ditangani sebagai batas project; tidak ada upaya memalsukan atau melewati kuota.
- PIN tidak disimpan sebagai plaintext; ada salt acak dan lockout setelah lima percobaan gagal.
- Screenshot protection menggunakan `FLAG_SECURE` pada Activity Tatsumaki dan window Floating Bot. Perilaku overlay tetap perlu diuji pada perangkat; aplikasi lain tidak dimanipulasi.
- Screen capture tetap memerlukan persetujuan MediaProjection Android dan foreground service yang terlihat; Accessibility Text Assist tetap nonaktif secara default.

## Batasan yang belum boleh diklaim selesai

- Belum ada riwayat chat persisten, `/clear_chat`, `/export_chat`, atau `/chat_history` karena aplikasi saat ini tidak memiliki subsistem penyimpanan riwayat chat yang aman.
- Belum ada backup/restore settings, debug log manager, mode maintenance, atau CPU load real-time.
- Retry otomatis setelah HTTP 429 belum dibuat; aplikasi menghormati error server dan menampilkan `Retry-After` bila tersedia. Request antre melalui dispatcher OkHttp, bukan bypass kuota.
- PIN mengunci saat aplikasi ditutup/Activity utama selesai atau proses aplikasi dimulai kembali. Penguncian ulang otomatis setiap kali aplikasi berpindah ke background belum dibuat.
- Floating Bot hanya bisa dikendalikan lewat command ketika ScreenModeService aktif; mematikan bot tidak menghentikan MediaProjection.
- Tulisan khusus `YOU ARE IDIOT` pada screenshot tidak dibuat karena Android tidak menyediakan API umum untuk mengganti hasil screenshot sistem. `FLAG_SECURE` hanya dapat menyembunyikan/memblokir window Tatsumaki sesuai perilaku perangkat.
- Window overlay Floating Bot kini juga diberi `FLAG_SECURE`, tetapi perilaku screenshot overlay harus diuji pada perangkat/OEM; tidak ada jaminan konten aplikasi lain ikut disembunyikan.

## Hasil pemeriksaan

| Pemeriksaan | Status |
|---|---|
| ZIP sumber berhasil diekstrak dan file dienumerasi | PASS |
| XML AndroidManifest dapat diparse | PASS (validasi XML) |
| Accessibility service XML dapat diparse | PASS (validasi XML) |
| Aset PNG tetap tersedia | PASS (file tetap ada; tidak diubah) |
| API Key Manager masih memakai AES/GCM + Android Keystore | PASS (inspeksi source) |
| Command `/Listcommaind` dan command list tersedia | PASS (inspeksi source) |
| `/delete_api_key` memeriksa key sebelum menghapus | PASS (inspeksi source) |
| API Key prompt tidak dicatat di terminal | PASS (inspeksi source) |
| PIN salted hash dan lockout tersedia | PASS (inspeksi source) |
| Uji alur command API Key dengan harness Java dan dependency Android dimock | PASS — key baru, konfirmasi ganti, cancel state, delete tanpa key, delete dengan key, dan daftar command |
| Uji logika PIN dengan harness Java dan SharedPreferences/Base64 dimock | PASS — default OFF, set/verify, PIN salah, lockout lima percobaan, dan disable |
| Uji UsageMonitor dengan SharedPreferences mock | PASS — request count, success count, hitungan hari ini, dan reset statistik |
| Cakupan command list | PASS — 44 command unik, seluruhnya memiliki route di terminal utama/router |
| AI ON/OFF terhubung ke request teks dan gambar | PASS (inspeksi source) |
| Request dispatcher dibatasi satu request aktif | PASS (inspeksi source) |
| Pemeriksaan delimiter/braces source | PASS (pemeriksaan leksikal sederhana pada seluruh file Java) |
| `javac` syntax pass penuh Android | NOT RUN — tidak tersedia Android SDK/AndroidX/OkHttp classpath; pemeriksaan source delimiter dan harness unit terpisah PASS |
| Gradle Sync / `assembleDebug` | NOT RUN — Gradle/Gradle Wrapper dan Android SDK tidak tersedia di lingkungan ini |
| Instalasi dan runtime pada perangkat Android | NOT RUN — tidak ada perangkat/emulator terhubung |
| Uji API Gemini live | NOT RUN — tidak meminta atau menanam API Key pengguna |
| Uji screenshot pada perangkat | NOT RUN — perlu perangkat Android sebenarnya |

## Build

ZIP sumber yang diterima tidak menyertakan Gradle Wrapper. Lingkungan ini tidak memiliki Gradle atau Android SDK, jadi APK tidak dapat dibangun di sini. Project kini memiliki workflow GitHub Actions yang dapat membangun APK setelah di-push ke `main` atau dijalankan manual. Workflow tersebut belum dieksekusi dari sini. Jangan anggap source ini sudah lolos build/runtime sampai CI berhasil dan APK diuji pada perangkat Android.
