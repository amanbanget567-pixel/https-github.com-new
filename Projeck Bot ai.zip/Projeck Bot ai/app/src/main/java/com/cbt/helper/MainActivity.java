package com.cbt.helper;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_OVERLAY = 1;
    private static final int REQ_CAPTURE = 2;
    private static final int REQ_NOTIF = 3;
    private MediaProjectionManager mpm;
    private Button btnStart, btnStop;
    private EditText etApiKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(50, 50, 50, 50);
        root.setGravity(Gravity.TOP);

        TextView tvWelcome = new TextView(this);
        tvWelcome.setText("WELCOME TO\nPHANTOM DARK AI");
        tvWelcome.setTextColor(Color.parseColor("#00FF00"));
        tvWelcome.setTextSize(28);
        tvWelcome.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tvWelcome.setPadding(0, 0, 0, 20);

        TextView tvCredit = new TextView(this);
        tvCredit.setText("Created by: PhantomStore\nVersion: 1.0.0 (Rootkit)\n---------------------------");
        tvCredit.setTextColor(Color.parseColor("#00AA00"));
        tvCredit.setTextSize(14);
        tvCredit.setTypeface(Typeface.MONOSPACE);
        tvCredit.setPadding(0, 0, 0, 40);

        TextView tvLabel = new TextView(this);
        tvLabel.setText("Gemini API Key:");
        tvLabel.setTextColor(Color.WHITE);
        tvLabel.setTypeface(Typeface.MONOSPACE);
        tvLabel.setTextSize(14);

        etApiKey = new EditText(this);
        etApiKey.setTextColor(Color.parseColor("#00FF00"));
        etApiKey.setHintTextColor(Color.parseColor("#005500"));
        etApiKey.setBackgroundColor(Color.parseColor("#111111"));
        etApiKey.setTypeface(Typeface.MONOSPACE);
        etApiKey.setPadding(20, 20, 20, 20);
        // Isi default API Key lu di sini
        etApiKey.setText("AQ.Ab8RN6KjgRpGWEPx3m_HOQ68CfN8a_RvwTYacs5M2PRymQv0uQ"); 

        btnStart = new Button(this);
        btnStart.setText("[ START SYSTEM ]");
        btnStart.setTextColor(Color.BLACK);
        btnStart.setBackgroundColor(Color.parseColor("#00FF00"));
        btnStart.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        
        btnStop = new Button(this);
        btnStop.setText("[ STOP SYSTEM ]");
        btnStop.setTextColor(Color.WHITE);
        btnStop.setBackgroundColor(Color.parseColor("#FF0000"));
        btnStop.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        btnStop.setVisibility(View.GONE);

        btnStart.setOnClickListener(v -> {
            String inputKey = etApiKey.getText().toString().trim();
            if(!inputKey.isEmpty()) {
                GeminiHelper.setApiKey(inputKey);
            }
            checkPermissions();
        });

        btnStop.setOnClickListener(v -> {
            stopService(new Intent(MainActivity.this, ScreenModeService.class));
            btnStart.setVisibility(View.VISIBLE);
            btnStop.setVisibility(View.GONE);
        });

        root.addView(tvWelcome);
        root.addView(tvCredit);
        root.addView(tvLabel);
        root.addView(etApiKey);
        root.addView(btnStart);
        root.addView(btnStop);

        setContentView(root);
    }

    private void checkPermissions() {
        // 1. Izin Notifikasi
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                return;
            }
        }
        // 2. Izin Overlay
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
        } else {
            startCapture();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) checkPermissions();
    }

    private void startCapture() {
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startCapture();
        } else if (requestCode == REQ_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Intent svc = new Intent(this, ScreenModeService.class);
                svc.putExtra("code", resultCode);
                svc.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
                else startService(svc);
                
                btnStart.setVisibility(View.GONE);
                btnStop.setVisibility(View.VISIBLE);
            }
        }
    }
}