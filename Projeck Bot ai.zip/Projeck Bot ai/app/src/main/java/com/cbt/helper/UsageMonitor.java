package com.cbt.helper;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;

/** Local request statistics. Google remains the authority for project RPM/TPM/RPD quotas. */
public final class UsageMonitor {
    private static final String PREFS = "usage_monitor";
    private static final String REQUESTS = "requests";
    private static final String SUCCEEDED = "succeeded";
    private static final String FAILED = "failed";
    private static final String LAST_REQUEST = "last_request";
    private static final String SENT_BYTES = "sent_bytes";
    private static final String TIMESTAMPS = "request_timestamps";

    private UsageMonitor() { }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Records an attempted request without inventing a local Google quota. */
    public static synchronized String tryStartRequest(Context context, long bytesSent) {
        if (context == null) return "Konteks aplikasi tidak tersedia.";
        SharedPreferences stats = prefs(context);
        long now = System.currentTimeMillis();
        List<Long> timestamps = readTimestamps(stats.getString(TIMESTAMPS, ""), now);
        timestamps.add(now);
        stats.edit()
                .putInt(REQUESTS, stats.getInt(REQUESTS, 0) + 1)
                .putLong(LAST_REQUEST, now)
                .putLong(SENT_BYTES, stats.getLong(SENT_BYTES, 0L) + Math.max(0L, bytesSent))
                .putString(TIMESTAMPS, joinTimestamps(timestamps))
                .apply();
        return null;
    }

    public static synchronized void requestSucceeded(Context context) {
        SharedPreferences p = prefs(context);
        p.edit().putInt(SUCCEEDED, p.getInt(SUCCEEDED, 0) + 1).apply();
    }

    public static synchronized void requestFailed(Context context) {
        SharedPreferences p = prefs(context);
        p.edit().putInt(FAILED, p.getInt(FAILED, 0) + 1).apply();
    }

    public static synchronized String summaryToday(Context context) {
        return "Request hari ini: " + countForPeriod(context, true);
    }

    public static synchronized String summaryMonth(Context context) {
        return "Request bulan ini: " + countForPeriod(context, false);
    }

    public static String limitInfo() {
        return "Tatsumaki tidak memasang angka kuota lokal buatan. Batas RPM/TPM/RPD mengikuti project dan tier API di Google AI Studio; respons 429 dari Google harus dihormati.";
    }

    private static int countForPeriod(Context context, boolean today) {
        SharedPreferences p = prefs(context);
        Calendar now = Calendar.getInstance();
        int count = 0;
        for (Long timestamp : readTimestamps(p.getString(TIMESTAMPS, ""), System.currentTimeMillis())) {
            Calendar item = Calendar.getInstance();
            item.setTimeInMillis(timestamp);
            boolean same = item.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                    && (today ? item.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
                    : item.get(Calendar.MONTH) == now.get(Calendar.MONTH));
            if (same) count++;
        }
        return count;
    }

    private static List<Long> readTimestamps(String encoded, long now) {
        List<Long> values = new ArrayList<>();
        if (encoded == null || encoded.isEmpty()) return values;
        String[] parts = encoded.split(",");
        long oldest = now - 35L * 24L * 60L * 60L * 1000L;
        for (String part : parts) {
            try {
                long value = Long.parseLong(part);
                if (value >= oldest && value <= now) values.add(value);
            } catch (NumberFormatException ignored) { }
        }
        return values;
    }

    private static String joinTimestamps(List<Long> values) {
        StringBuilder out = new StringBuilder();
        for (Long value : values) {
            if (out.length() > 0) out.append(',');
            out.append(value);
        }
        return out.toString();
    }

    public static synchronized String summary(Context context) {
        SharedPreferences p = prefs(context);
        int requests = p.getInt(REQUESTS, 0);
        int succeeded = p.getInt(SUCCEEDED, 0);
        int failed = p.getInt(FAILED, 0);
        long last = p.getLong(LAST_REQUEST, 0L);
        long bytes = p.getLong(SENT_BYTES, 0L);
        String lastText = last == 0L ? "Belum ada" : DateFormat.getDateTimeInstance(
                DateFormat.SHORT, DateFormat.SHORT, Locale.getDefault()).format(new Date(last));
        return "Usage Monitor\nRequest tercatat: " + requests + "\nBerhasil: " + succeeded
                + "\nGagal: " + failed + "\nData terkirim: " + formatBytes(bytes)
                + "\nRequest terakhir: " + lastText
                + "\n" + summaryToday(context) + "\n" + summaryMonth(context)
                + "\nKuota resmi: mengikuti batas project Google AI Studio.";
    }

    /** Resets visible statistics only; it cannot reset or alter Google's project quota. */
    public static synchronized void reset(Context context) {
        prefs(context).edit().clear().apply();
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        return String.format(Locale.US, "%.2f MB", bytes / (1024.0 * 1024.0));
    }
}
