package com.cbt.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Local PIN verifier. Only a salted PBKDF2 hash is persisted; the PIN is never stored in plaintext. */
public final class PinManager {
    private static final String PREFS = "tatsumaki_pin_settings";
    private static final String SALT = "pin_salt";
    private static final String HASH = "pin_hash";
    private static final String FAILED_ATTEMPTS = "failed_attempts";
    private static final String LOCK_UNTIL = "lock_until";
    private static final int ITERATIONS = 150000;
    private static final int KEY_BITS = 256;
    private static volatile boolean sessionUnlocked = false;

    private PinManager() { }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context context) {
        return prefs(context).contains(SALT) && prefs(context).contains(HASH);
    }

    public static boolean isSessionUnlocked() { return sessionUnlocked; }
    public static void setSessionUnlocked(boolean unlocked) { sessionUnlocked = unlocked; }

    public static boolean setPin(Context context, String pin) throws Exception {
        if (!isValidPin(pin)) return false;
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        byte[] hash = derive(pin.toCharArray(), salt);
        return prefs(context).edit()
                .putString(SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString(HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
                .remove(FAILED_ATTEMPTS).remove(LOCK_UNTIL)
                .commit();
    }

    public static boolean verify(Context context, String pin) {
        if (pin == null || !isEnabled(context)) return false;
        try {
            SharedPreferences p = prefs(context);
            byte[] salt = Base64.decode(p.getString(SALT, ""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(p.getString(HASH, ""), Base64.NO_WRAP);
            byte[] actual = derive(pin.toCharArray(), salt);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }

    public static void disable(Context context) {
        prefs(context).edit().remove(SALT).remove(HASH)
                .remove(FAILED_ATTEMPTS).remove(LOCK_UNTIL).commit();
        sessionUnlocked = true;
    }

    public static long getRemainingLockoutMillis(Context context) {
        return Math.max(0L, prefs(context).getLong(LOCK_UNTIL, 0L) - System.currentTimeMillis());
    }

    public static void recordFailedAttempt(Context context) {
        SharedPreferences p = prefs(context);
        int attempts = p.getInt(FAILED_ATTEMPTS, 0) + 1;
        if (attempts >= 5) {
            p.edit().putInt(FAILED_ATTEMPTS, 0)
                    .putLong(LOCK_UNTIL, System.currentTimeMillis() + 30_000L).apply();
        } else {
            p.edit().putInt(FAILED_ATTEMPTS, attempts).apply();
        }
    }

    public static void resetFailedAttempts(Context context) {
        prefs(context).edit().remove(FAILED_ATTEMPTS).remove(LOCK_UNTIL).apply();
    }

    public static boolean isValidPin(String pin) {
        if (pin == null || pin.length() < 4 || pin.length() > 12) return false;
        for (int i = 0; i < pin.length(); i++) {
            if (pin.charAt(i) < '0' || pin.charAt(i) > '9') return false;
        }
        return true;
    }

    private static byte[] derive(char[] pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin, salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
            java.util.Arrays.fill(pin, '\0');
        }
    }
}
