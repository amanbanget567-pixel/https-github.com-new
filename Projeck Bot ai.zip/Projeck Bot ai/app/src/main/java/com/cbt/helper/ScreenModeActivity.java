package com.cbt.helper;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class ScreenModeActivity extends AppCompatActivity {
    private static final int REQ_OVERLAY = 11;
    private static final int REQ_CAPTURE = 12;
    private static final int REQ_NOTIFICATIONS = 13;
    private MediaProjectionManager projectionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Android secure-window behavior hides or blocks screenshots of this app window.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (!ApiKeyManager.isConfigured(this)) {
            Toast.makeText(this, "Atur Gemini API Key melalui terminal dengan /set_new_api_key terlebih dahulu.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        requestNotificationPermissionOrContinue();
    }

    private void requestNotificationPermissionOrContinue() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        } else {
            checkOverlayPermission();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS) checkOverlayPermission();
    }

    private void checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
        } else {
            startCaptureConsent();
        }
    }

    private void startCaptureConsent() {
        if (projectionManager == null) {
            Toast.makeText(this, "MediaProjection tidak tersedia.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startCaptureConsent();
            else finish();
            return;
        }
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, ScreenModeService.class);
                serviceIntent.putExtra("code", resultCode);
                serviceIntent.putExtra("data", data);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent);
                    else startService(serviceIntent);
                } catch (Exception e) {
                    Toast.makeText(this, "Service gagal dimulai: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            finish();
        }
    }
}
