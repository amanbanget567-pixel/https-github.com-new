package com.cbt.helper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PinGateActivity extends Activity {
    private EditText pinInput;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        if (!PinManager.isEnabled(this)) {
            PinManager.setSessionUnlocked(true);
            openMain();
            return;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.BLACK);
        TextView title = new TextView(this);
        title.setText("TATSUMAKI TERMINAL\n==============================\nSECURITY LOCK");
        title.setTextColor(Color.rgb(0,255,117));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        pinInput = new EditText(this);
        pinInput.setSingleLine(true);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setHint("ENTER PIN");
        pinInput.setTextColor(Color.WHITE);
        pinInput.setHintTextColor(Color.GRAY);
        root.addView(pinInput, new LinearLayout.LayoutParams(-1, -2));
        Button unlock = new Button(this);
        unlock.setText("UNLOCK");
        root.addView(unlock, new LinearLayout.LayoutParams(-1, -2));
        unlock.setOnClickListener(v -> {
            long remaining = PinManager.getRemainingLockoutMillis(this);
            if (remaining > 0L) {
                Toast.makeText(this, "Terlalu banyak percobaan. Coba lagi " + ((remaining + 999L) / 1000L) + " detik lagi.", Toast.LENGTH_LONG).show();
                return;
            }
            if (PinManager.verify(this, pinInput.getText().toString())) {
                PinManager.resetFailedAttempts(this);
                PinManager.setSessionUnlocked(true);
                openMain();
            } else {
                PinManager.recordFailedAttempt(this);
                pinInput.setText("");
                Toast.makeText(this, "ERROR: PIN salah.", Toast.LENGTH_SHORT).show();
            }
        });
        setContentView(root);
    }

    private void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
