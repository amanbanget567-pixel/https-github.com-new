package com.cbt.helper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Toast;

public class PinSettingsActivity extends Activity {
    private EditText oldPin;
    private EditText newPin;
    private EditText confirmPin;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        scroll.addView(root);
        root.setBackgroundColor(Color.BLACK);
        TextView title = new TextView(this);
        title.setText("TATSUMAKI TERMINAL\nSECURITY SETTINGS");
        title.setTextColor(Color.rgb(0,255,117));
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setTextSize(19);
        root.addView(title);
        TextView pinStatus = new TextView(this);
        pinStatus.setText("APP PIN STATUS: " + (PinManager.isEnabled(this) ? "ACTIVE" : "OFF"));
        pinStatus.setTextColor(Color.rgb(0, 255, 117));
        pinStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        pinStatus.setPadding(0, dp(14), 0, dp(8));
        root.addView(pinStatus);
        oldPin = addPinField(root, "PIN LAMA (jika sudah aktif)");
        newPin = addPinField(root, "PIN BARU (4-12 digit)");
        confirmPin = addPinField(root, "ULANGI PIN BARU");
        Button save = new Button(this);
        save.setText(PinManager.isEnabled(this) ? "GANTI PIN" : "AKTIFKAN PIN");
        root.addView(save);
        save.setOnClickListener(v -> savePin());
        Button disable = new Button(this);
        disable.setText("NONAKTIFKAN PIN");
        root.addView(disable);
        disable.setOnClickListener(v -> disablePin());
        Button back = new Button(this);
        back.setText("KEMBALI");
        root.addView(back);
        back.setOnClickListener(v -> finish());
        TextView note = new TextView(this);
        note.setText("Default: PIN OFF. PIN diminta saat aplikasi dibuka setelah aplikasi ditutup atau prosesnya dimulai ulang. PIN disimpan sebagai hash salted, bukan teks biasa.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(11);
        note.setPadding(0, 16, 0, 0);
        root.addView(note);

        TextView accessibilityTitle = new TextView(this);
        accessibilityTitle.setText("ACCESSIBILITY TEXT ASSIST");
        accessibilityTitle.setTextColor(Color.rgb(0, 255, 117));
        accessibilityTitle.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        accessibilityTitle.setPadding(0, 22, 0, 4);
        root.addView(accessibilityTitle);
        CheckBox accessibilityToggle = new CheckBox(this);
        accessibilityToggle.setTextColor(Color.WHITE);
        accessibilityToggle.setText("Izinkan analisis teks dari aplikasi aktif");
        accessibilityToggle.setChecked(AppPreferences.isAccessibilityAutoAnalysisEnabled(this));
        root.addView(accessibilityToggle);
        TextView accessibilityNote = new TextView(this);
        accessibilityNote.setText("Nonaktif secara default. Jika diaktifkan dan Accessibility Service Android juga dinyalakan, teks pada jendela aplikasi aktif dapat dikirim ke Gemini. Jangan aktifkan saat membuka data pribadi atau sensitif.");
        accessibilityNote.setTextColor(Color.LTGRAY);
        accessibilityNote.setTextSize(11);
        root.addView(accessibilityNote);
        accessibilityToggle.setOnCheckedChangeListener((buttonView, checked) -> {
            AppPreferences.setAccessibilityAutoAnalysisEnabled(this, checked);
            if (checked) {
                Toast.makeText(this, "Aktifkan Tatsumaki AI pada daftar Accessibility Android.", Toast.LENGTH_LONG).show();
                openAccessibilitySettings();
            }
        });
        Button accessibilitySettings = new Button(this);
        accessibilitySettings.setText("BUKA PENGATURAN ACCESSIBILITY ANDROID");
        root.addView(accessibilitySettings);
        accessibilitySettings.setOnClickListener(v -> openAccessibilitySettings());
        setContentView(scroll);
    }

    private EditText addPinField(LinearLayout root, String hint) {
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        field.setHint(hint);
        field.setTextColor(Color.WHITE);
        field.setHintTextColor(Color.GRAY);
        root.addView(field, new LinearLayout.LayoutParams(-1, -2));
        return field;
    }

    private boolean verifyOldIfNeeded() {
        if (PinManager.isEnabled(this) && !PinManager.verify(this, oldPin.getText().toString())) {
            Toast.makeText(this, "ERROR: PIN lama salah.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void savePin() {
        if (!verifyOldIfNeeded()) return;
        String value = newPin.getText().toString();
        if (!PinManager.isValidPin(value)) {
            Toast.makeText(this, "PIN harus 4-12 digit angka.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!value.equals(confirmPin.getText().toString())) {
            Toast.makeText(this, "Konfirmasi PIN tidak cocok.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            if (PinManager.setPin(this, value)) {
                PinManager.setSessionUnlocked(true);
                Toast.makeText(this, "PIN berhasil diaktifkan/diperbarui.", Toast.LENGTH_SHORT).show();
                finish();
            } else Toast.makeText(this, "Gagal menyimpan PIN.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "ERROR: Penyimpanan PIN gagal.", Toast.LENGTH_LONG).show();
        }
    }

    private void disablePin() {
        if (!PinManager.isEnabled(this)) {
            Toast.makeText(this, "PIN memang belum aktif.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!verifyOldIfNeeded()) return;
        PinManager.disable(this);
        Toast.makeText(this, "PIN dinonaktifkan.", Toast.LENGTH_SHORT).show();
        finish();
    }
    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Pengaturan Accessibility tidak dapat dibuka.", Toast.LENGTH_SHORT).show();
        }
    }

}
