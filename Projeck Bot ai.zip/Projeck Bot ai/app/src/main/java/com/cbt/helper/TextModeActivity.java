package com.cbt.helper;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TextModeActivity extends AppCompatActivity {
    private EditText inputText;
    private TextView answerText;
    private Button askButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Android secure-window behavior hides or blocks screenshots of this app window.
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        buildInterface();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#121212"));
        int padding = dp(20);
        layout.setPadding(padding, padding, padding, padding);
        scroll.addView(layout);

        TextView title = new TextView(this);
        title.setText("TATSUMAKI TEXT ASSIST");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        layout.addView(title);

        inputText = new EditText(this);
        inputText.setHint("Ketik atau paste teks di sini...");
        inputText.setTextColor(Color.WHITE);
        inputText.setHintTextColor(Color.GRAY);
        inputText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        inputText.setMinLines(4);
        layout.addView(inputText);

        askButton = new Button(this);
        askButton.setText("Tanya AI");
        askButton.setBackgroundColor(Color.parseColor("#3700B3"));
        askButton.setTextColor(Color.WHITE);
        layout.addView(askButton);

        answerText = new TextView(this);
        answerText.setTextColor(Color.parseColor("#BB86FC"));
        answerText.setTextSize(16);
        answerText.setPadding(0, dp(24), 0, 0);
        layout.addView(answerText);
        setContentView(scroll);

        askButton.setOnClickListener(v -> askTatsumaki());
    }

    private void askTatsumaki() {
        String prompt = inputText.getText() == null ? "" : inputText.getText().toString().trim();
        if (prompt.isEmpty()) {
            Toast.makeText(this, "Masukkan teks terlebih dahulu.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!ApiKeyManager.isConfigured(this)) {
            answerText.setText("API Key belum diatur. Jalankan /set_new_api_key di terminal utama.");
            return;
        }
        askButton.setEnabled(false);
        answerText.setText("Menganalisis...");
        GeminiHelper.askText(this, prompt, false, new GeminiHelper.Callback() {
            @Override
            public void onSuccess(String result) {
                askButton.setEnabled(true);
                answerText.setText(result);
            }

            @Override
            public void onError(String error) {
                askButton.setEnabled(true);
                answerText.setText("Error: " + error);
            }
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
