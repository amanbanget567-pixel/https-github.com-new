package com.cbt.helper;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TextModeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#121212"));
        layout.setPadding(40, 40, 40, 40);

        EditText inputSoal = new EditText(this);
        inputSoal.setHint("Ketik atau paste soal di sini...");
        inputSoal.setTextColor(Color.WHITE);
        inputSoal.setHintTextColor(Color.GRAY);

        Button btnTanya = new Button(this);
        btnTanya.setText("Tanya AI");
        btnTanya.setBackgroundColor(Color.parseColor("#3700B3"));
        btnTanya.setTextColor(Color.WHITE);

        TextView textJawaban = new TextView(this);
        textJawaban.setTextColor(Color.parseColor("#BB86FC"));
        textJawaban.setTextSize(16);
        textJawaban.setPadding(0, 30, 0, 0);

        layout.addView(inputSoal);
        layout.addView(btnTanya);
        layout.addView(textJawaban);
        setContentView(layout);

        btnTanya.setOnClickListener(v -> {
            String soal = inputSoal.getText().toString();
            if (soal.isEmpty()) return;
            textJawaban.setText("Menganalisis...");
            
            // PERBAIKAN PARAMETER: ADA false
            GeminiHelper.askText(soal, false, new GeminiHelper.Callback() {
                @Override
                public void onSuccess(String result) { textJawaban.setText(result); }
                @Override
                public void onError(String error) { textJawaban.setText("Error: " + error); }
            });
        });
    }
}