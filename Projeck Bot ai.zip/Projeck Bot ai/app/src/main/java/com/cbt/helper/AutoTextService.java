package com.cbt.helper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import android.util.LruCache;

public class AutoTextService extends AccessibilityService {
    private static final long SCAN_INTERVAL_MS = 5000L;
    private static final int MAX_TEXT_LENGTH = 6000;
    private final StringBuilder screenText = new StringBuilder();
    private final LruCache<String, String> recentlyProcessed = new LruCache<>(40);
    private static volatile String lastResult = "Belum ada hasil auto text.";
    private long lastScanTime;
    private boolean requestInProgress;

    public static String getLastResult() {
        return lastResult;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !AppPreferences.isAccessibilityAutoAnalysisEnabled(this)) return;
        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;

        CharSequence packageName = event.getPackageName();
        if (packageName != null && getPackageName().contentEquals(packageName)) return;
        long now = System.currentTimeMillis();
        if (requestInProgress || now - lastScanTime < SCAN_INTERVAL_MS) return;

        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;
        try {
            screenText.setLength(0);
            extractText(rootNode, 0);
            String text = screenText.toString().trim();
            if (text.length() <= 10 || recentlyProcessed.get(text) != null) return;

            lastScanTime = now;
            requestInProgress = true;
            GeminiHelper.askText(this, text, false, new GeminiHelper.Callback() {
                @Override
                public void onSuccess(String result) {
                    recentlyProcessed.put(text, result);
                    lastResult = result;
                    requestInProgress = false;
                }

                @Override
                public void onError(String error) {
                    requestInProgress = false;
                }
            });
        } finally {
            rootNode.recycle();
        }
    }

    private void extractText(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 40 || screenText.length() >= MAX_TEXT_LENGTH) return;
        CharSequence value = node.getText();
        if (value != null && value.length() > 0) {
            if (screenText.length() > 0) screenText.append(' ');
            int remaining = MAX_TEXT_LENGTH - screenText.length();
            screenText.append(value.subSequence(0, Math.min(value.length(), remaining)));
        }
        int children = node.getChildCount();
        for (int i = 0; i < children && screenText.length() < MAX_TEXT_LENGTH; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try {
                    extractText(child, depth + 1);
                } finally {
                    child.recycle();
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
        requestInProgress = false;
    }

    @Override
    public void onDestroy() {
        requestInProgress = false;
        super.onDestroy();
    }
}
