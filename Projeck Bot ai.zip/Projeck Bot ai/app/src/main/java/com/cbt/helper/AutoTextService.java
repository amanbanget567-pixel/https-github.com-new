package com.cbt.helper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.HashMap;

public class AutoTextService extends AccessibilityService {
    private StringBuilder screenText = new StringBuilder();
    private long lastScanTime = 0;
    private static HashMap<String, String> memoriJawaban = new HashMap<>(); 

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            AccessibilityNodeInfo rootNode = getRootInActiveWindow();
            if (rootNode == null) return;
            if (System.currentTimeMillis() - lastScanTime < 5000) return; 
            
            screenText.setLength(0);
            extractText(rootNode);
            String text = screenText.toString().trim();

            if (!text.isEmpty() && text.length() > 10) {
                lastScanTime = System.currentTimeMillis();
                
                if (memoriJawaban.containsKey(text)) {
                    return;
                }

                // PERBAIKAN PARAMETER: ADA false
                GeminiHelper.askText(text, false, new GeminiHelper.Callback() {
                    @Override public void onSuccess(String result) { 
                        memoriJawaban.put(text, result);
                    }
                    @Override public void onError(String error) { }
                });
            }
        }
    }

    private void extractText(AccessibilityNodeInfo node) {
        if (node == null) return;
        if (node.getText() != null) screenText.append(node.getText().toString()).append(" ");
        for (int i = 0; i < node.getChildCount(); i++) extractText(node.getChild(i));
    }

    @Override public void onInterrupt() {}
}