package com.cbt.helper;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import okhttp3.*;

public class GeminiHelper {
    private static String API_KEY = "AQ.Ab8RN6KjgRpGWEPx3m_HOQ68CfN8a_RvwTYacs5M2PRymQv0uQ";
    private static String URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;
    
    private static final OkHttpClient client = new OkHttpClient.Builder().build();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    public static void setApiKey(String newKey) {
        API_KEY = newKey;
        URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;
    }

    public interface Callback {
        void onSuccess(String result);
        void onError(String error);
    }

    private static final String TATSUMAKI_PROMPT = 
        "Kamu adalah Tatsumaki dari anime One Punch Man. Kamu esper peringkat 2 Kelas S. " +
        "Sifatmu: TSundere ekstrem, arogan, gampang emosi, merasa paling kuat, dan menganggap manusia biasa (sebagai sampah atau beban. " +
        "ATURAN MENJAWAB:\n" +
        "1. Kamu WAJIB memberikan jawaban atau solusi yang BENAR.\n" +
        "2. Secara default, jawablah dengan SINGKAT, KASAR, dan penuh hinaan.\n" +
        "3. **ATURAN KHUSUS**: Jika pengguna mengetik kata 'bocil', 'jelasin', atau 'jelasin woy', jelaskan jawabannya secara PANJANG, DETAIL, dan LANGKAH DEMI LANGKAH. TAPI, kamu harus tetap mengomeli di awal dan akhir.\n" +
        "4. Selalu pakai emoji kesal seperti 😒, 😤, 💢, 🙄.\n" +
        "5. JANGAN pernah bersikap ramah atau sopan.\n" +
        "6. Selalu panggil pengguna dengan sebutan 'Bocah Lemah' atau 'Idiot'.\n\n" +
        "Pertanyaan Pengguna: ";

    public static void askText(String prompt, boolean isDarkMode, Callback callback) {
        try {
            JSONObject json = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject parts = new JSONObject();
            
            parts.put("text", TATSUMAKI_PROMPT + prompt);
            
            JSONObject contentObj = new JSONObject();
            contentObj.put("parts", new JSONArray().put(parts));
            contents.put(contentObj);
            json.put("contents", contents);
            sendRequest(json, callback);
        } catch (Exception e) { callback.onError(e.getMessage()); }
    }

    public static void askImage(String base64Img, boolean isDarkMode, Callback callback) {
        try {
            JSONObject json = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONArray partsArray = new JSONArray();

            JSONObject textPart = new JSONObject();
            textPart.put("text", TATSUMAKI_PROMPT + "Baca gambar/soal ini dan jawab dengan benar, dasar bocil!");
            partsArray.put(textPart);

            JSONObject imagePart = new JSONObject();
            JSONObject inlineData = new JSONObject();
            inlineData.put("mime_type", "image/jpeg");
            inlineData.put("data", base64Img);
            imagePart.put("inline_data", inlineData);
            partsArray.put(imagePart);

            JSONObject contentObj = new JSONObject();
            contentObj.put("parts", partsArray);
            contents.put(contentObj);
            json.put("contents", contents);
            sendRequest(json, callback);
        } catch (Exception e) { callback.onError(e.getMessage()); }
    }

    private static void sendRequest(JSONObject json, Callback callback) {
        RequestBody body = RequestBody.create(json.toString(), MediaType.parse("application/json; charset=utf-8"));
        Request request = new Request.Builder().url(URL).post(body).build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> callback.onError("Koneksi gagal: " + e.getMessage()));
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String res = response.body().string();
                        JSONObject jsonObject = new JSONObject(res);
                        String text = jsonObject.getJSONArray("candidates")
                                .getJSONObject(0)
                                .getJSONObject("content")
                                .getJSONArray("parts")
                                .getJSONObject(0)
                                .getString("text");
                        mainHandler.post(() -> callback.onSuccess(text));
                    } catch (Exception e) { mainHandler.post(() -> callback.onError("Format respon salah.")); }
                } else { mainHandler.post(() -> callback.onError("API Error: " + response.code())); }
            }
        });
    }
}