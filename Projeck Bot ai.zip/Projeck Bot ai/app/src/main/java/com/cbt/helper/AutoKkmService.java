package com.cbt.helper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class AutoKkmService extends AccessibilityService {
    private static AutoKkmService instance;

    public static AutoKkmService getInstance() {
        return instance;
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    public void performClickByText(String targetText) {
        if (targetText == null || targetText.isEmpty()) return;

        // Membersihkan teks jawaban dari AI (misal "(A)" jadi "A")
        String cleanTarget = targetText.replaceAll("[^a-zA-Z0-9]", "").trim();
        if (cleanTarget.isEmpty()) return;

        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;

        List<AccessibilityNodeInfo> nodes = rootNode.findAccessibilityNodeInfosByText(targetText);
        if (nodes.isEmpty()) {
            nodes = rootNode.findAccessibilityNodeInfosByText(cleanTarget);
        }

        for (AccessibilityNodeInfo node : nodes) {
            CharSequence nodeTextSeq = node.getText();
            if (nodeTextSeq == null) continue;
            
            String nodeText = nodeTextSeq.toString().trim();
            String cleanNode = nodeText.replaceAll("[^a-zA-Z0-9]", "");
            boolean isMatch = false;

            if (cleanTarget.length() == 1) {
                // Jika AI jawab 1 huruf (A, B, C, D, E)
                if (cleanNode.startsWith(cleanTarget)) {
                    if (cleanNode.length() == 1 || nodeText.matches("(?i)^[\\(]?" + cleanTarget + "[\\)\\.\\s:].*")) {
                        isMatch = true;
                    }
                }
            } else {
                // Jika jawaban essay atau angka (misal "12" atau "3.5")
                if (cleanNode.equalsIgnoreCase(cleanTarget) || cleanNode.contains(cleanTarget)) {
                    isMatch = true;
                }
            }

            if (isMatch) {
                AccessibilityNodeInfo clickableParent = getClickableNode(node);
                if (clickableParent != null) {
                    clickableParent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    break; // Hanya klik 1 kali
                }
            }
        }
    }

    private AccessibilityNodeInfo getClickableNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isClickable()) return node;
        
        AccessibilityNodeInfo parent = node.getParent();
        while (parent != null) {
            if (parent.isClickable()) return parent;
            parent = parent.getParent();
        }
        return null;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override
    public void onInterrupt() {}
}