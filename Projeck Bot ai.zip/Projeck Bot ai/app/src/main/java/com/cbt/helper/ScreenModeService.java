package com.cbt.helper;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScreenModeService extends Service {
    private static final String CHANNEL_ID = "tatsumaki_screen_assist";
    private static final int NOTIFICATION_ID = 4101;
    private static final int CLICK_THRESHOLD = 10;
    private static final long AUTO_SCAN_INTERVAL_MS = 15000L; // Jeda 15 detik

    private static volatile boolean active;
    private static volatile boolean projectionActive;
    private static volatile ScreenModeService instance;

    private MediaProjection mediaProjection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private WindowManager windowManager;

    private LinearLayout mainContainer;
    private FrameLayout botContainer;
    private ImageView botImage;
    private LinearLayout menuLayout;
    private TextView textResult;
    private TextView textDevInfo;
    private Button autoScanButton;
    private WindowManager.LayoutParams layoutParams;

    private boolean menuOpen;
    private boolean autoScanEnabled;
    private boolean projectionStopped;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService captureExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean analysisInProgress = new AtomicBoolean(false);
    private final LruCache<String, String> answerCache = new LruCache<>(30);
    private int requestCount;
    private int displayWidth;
    private int displayHeight;
    private int displayDensity;

    private float initialX;
    private float initialY;
    private int initialTouchX;
    private int initialTouchY;
    private boolean dragging;
    private android.animation.ObjectAnimator floatingAnimator;
    private android.animation.AnimatorSet clickAnimator;

    public static boolean isActive() {
        return active;
    }

    public static boolean isProjectionActive() {
        return projectionActive;
    }

    public static boolean setFloatingVisible(boolean visible) {
        ScreenModeService service = instance;
        if (service == null || service.mainContainer == null) return false;
        service.mainHandler.post(() -> {
            if (service.mainContainer != null) service.mainContainer.setVisibility(visible ? View.VISIBLE : View.GONE);
        });
        return true;
    }

    public static boolean resetFloatingPosition() {
        ScreenModeService service = instance;
        if (service == null || service.layoutParams == null || service.windowManager == null || service.mainContainer == null) return false;
        service.mainHandler.post(() -> {
            if (service.layoutParams != null && service.mainContainer != null) {
                service.layoutParams.x = service.dp(24);
                service.layoutParams.y = service.dp(120);
                try { service.windowManager.updateViewLayout(service.mainContainer, service.layoutParams); }
                catch (Exception ignored) { }
            }
        });
        return true;
    }

    public static String floatingPosition() {
        ScreenModeService service = instance;
        if (service == null || service.layoutParams == null) return "Floating Bot tidak aktif.";
        float density = service.getResources().getDisplayMetrics().density;
        return "Floating Bot position: X=" + Math.round(service.layoutParams.x / density)
                + "dp, Y=" + Math.round(service.layoutParams.y / density) + "dp";
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // 1. WAJIB PANGGIL INI DULUAN SEBELUM APAPUN (Mencegah Crash di Android 14)
        startForegroundNotification(); 

        if (intent == null) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (mediaProjection != null || active) {
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra("code", 0);
        Intent resultData = getProjectionResultData(intent);
        if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        try {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (manager == null) throw new IllegalStateException("MediaProjectionManager tidak tersedia.");
            mediaProjection = manager.getMediaProjection(resultCode, resultData);
            if (mediaProjection == null) throw new IllegalStateException("Izin screen capture tidak valid.");

            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    super.onStop();
                    projectionStopped = true;
                    projectionActive = false;
                    active = false;
                    releaseCaptureResources(false);
                    stopSelf();
                }
            };
            mediaProjection.registerCallback(projectionCallback, mainHandler);
            setupVirtualDisplay();
            setupFloatingBot();
            projectionActive = true;
            active = true;
            updateDeveloperInfo();
        } catch (SecurityException e) {
            showStatus("Izin screen capture ditolak Android: " + safeMessage(e));
            stopSelf(startId);
            return START_NOT_STICKY;
        } catch (Exception e) {
            showStatus("Gagal memulai screen assist: " + safeMessage(e));
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        return START_NOT_STICKY;
    }

    private Intent getProjectionResultData(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33) return intent.getParcelableExtra("data", Intent.class);
        return intent.getParcelableExtra("data");
    }

    private void startForegroundNotification() {
        createNotificationChannel();
        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Tatsumaki Screen Assist aktif")
                    .setContentText("Screen capture berjalan dengan izin Android. Ketuk STOP untuk mengakhiri.")
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .setOngoing(true)
                    .build();
        } else {
            notification = new Notification.Builder(this)
                    .setContentTitle("Tatsumaki Screen Assist aktif")
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .build();
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Screen Assist", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void setupVirtualDisplay() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        displayWidth = metrics.widthPixels;
        displayHeight = metrics.heightPixels;
        displayDensity = metrics.densityDpi;

        imageReader = ImageReader.newInstance(displayWidth, displayHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay("TatsumakiCapture",
                displayWidth, displayHeight, displayDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);
    }

    private final Runnable autoScanRunnable = new Runnable() {
        @Override
        public void run() {
            if (autoScanEnabled && active) {
                captureScreen();
                mainHandler.postDelayed(this, AUTO_SCAN_INTERVAL_MS);
            }
        }
    };

    private void startAutoScan() {
        mainHandler.removeCallbacks(autoScanRunnable);
        autoScanEnabled = true;
        if (autoScanButton != null) autoScanButton.setText("⏹ AUTO SCAN: ON");
        setResultText("> Auto Scan aktif. Mencari soal...");
        mainHandler.postDelayed(autoScanRunnable, 1200L);
    }

    private void stopAutoScan() {
        autoScanEnabled = false;
        mainHandler.removeCallbacks(autoScanRunnable);
        if (autoScanButton != null) autoScanButton.setText("▶ AUTO SCAN: OFF");
        if (textResult != null && active) textResult.setText("> Auto Scan nonaktif.");
    }

    private void toggleMenu() {
        if (menuLayout == null) return;
        menuOpen = !menuOpen;
        menuLayout.setVisibility(menuOpen ? View.VISIBLE : View.GONE);
    }

    private void showTextInputDialog() {
        EditText input = new EditText(this);
        input.setTextColor(Color.BLACK);
        input.setHint("Ketik atau paste teks di sini...");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Tanya Tatsumaki")
                .setView(input)
                .setNegativeButton("BATAL", (d, which) -> { })
                .setPositiveButton("TANYA", (d, which) -> {
                    String text = input.getText() == null ? "" : input.getText().toString().trim();
                    if (text.isEmpty()) setResultText("> Teks masih kosong.");
                    else askText(text);
                })
                .create();
        Window dialogWindow = dialog.getWindow();
        if (dialogWindow != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialogWindow.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            }
            dialogWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
        try {
            dialog.show();
        } catch (Exception e) {
            setResultText("> Dialog tidak dapat dibuka: " + safeMessage(e));
        }
    }

    private void startFloatingAnimation() {
        if (botImage == null) return;
        stopFloatingAnimation();
        floatingAnimator = android.animation.ObjectAnimator.ofFloat(botImage, "translationY", -dp(6), dp(6));
        floatingAnimator.setDuration(1500);
        floatingAnimator.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        floatingAnimator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        floatingAnimator.start();
    }

    private void stopFloatingAnimation() {
        if (floatingAnimator != null) {
            floatingAnimator.cancel();
            floatingAnimator = null;
        }
    }

    private void startClickAnimation() {
        if (botImage == null) return;
        stopFloatingAnimation();
        if (clickAnimator != null) clickAnimator.cancel();
        android.animation.ObjectAnimator scaleX = android.animation.ObjectAnimator.ofFloat(botImage, "scaleX", 1f, 0.82f, 1f);
        android.animation.ObjectAnimator scaleY = android.animation.ObjectAnimator.ofFloat(botImage, "scaleY", 1f, 0.82f, 1f);
        clickAnimator = new android.animation.AnimatorSet();
        clickAnimator.playTogether(scaleX, scaleY);
        clickAnimator.setDuration(280);
        clickAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (active) startFloatingAnimation();
            }
        });
        clickAnimator.start();
    }

    private void captureScreen() {
        if (!AppPreferences.isAiEnabled(this)) {
            stopAutoScan();
            setResultText("> AI nonaktif. Jalankan /ai_on dari terminal untuk mengaktifkan kembali.");
            return;
        }
        if (!active || imageReader == null || !analysisInProgress.compareAndSet(false, true)) {
            if (analysisInProgress.get()) setResultText("> Permintaan sebelumnya masih diproses.");
            else setResultText("> Screen capture belum siap.");
            return;
        }

        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                analysisInProgress.set(false);
                setResultText("> Frame belum tersedia. Coba lagi sebentar.");
                return;
            }
            final Image capturedImage = image;
            captureExecutor.execute(() -> processCapturedImage(capturedImage));
        } catch (Exception e) {
            if (image != null) image.close();
            analysisInProgress.set(false);
            setResultText("> Gagal mengambil layar: " + safeMessage(e));
        }
    }

    private void processCapturedImage(Image image) {
        Bitmap paddedBitmap = null;
        Bitmap outputBitmap = null;
        try {
            if (image.getPlanes() == null || image.getPlanes().length == 0) {
                throw new IllegalStateException("Data frame tidak tersedia.");
            }
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer().duplicate();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            if (pixelStride <= 0 || rowStride <= 0) throw new IllegalStateException("Stride gambar tidak valid.");

            int width = image.getWidth();
            int height = image.getHeight();
            int paddedWidth = rowStride / pixelStride;
            if (paddedWidth < width) throw new IllegalStateException("Ukuran buffer gambar tidak valid.");

            paddedBitmap = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888);
            buffer.rewind();
            paddedBitmap.copyPixelsFromBuffer(buffer);
            if (paddedWidth == width) {
                outputBitmap = paddedBitmap;
                paddedBitmap = null;
            } else {
                outputBitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, width, height);
            }
        } catch (Exception e) {
            showStatus("> Gagal memproses frame: " + safeMessage(e));
        } finally {
            image.close();
            if (paddedBitmap != null && !paddedBitmap.isRecycled()) paddedBitmap.recycle();
        }

        if (outputBitmap == null) {
            analysisInProgress.set(false);
            return;
        }
        final Bitmap bitmapForEncoding = outputBitmap;
        try {
            captureExecutor.execute(() -> encodeAndSend(bitmapForEncoding));
        } catch (Exception e) {
            if (!bitmapForEncoding.isRecycled()) bitmapForEncoding.recycle();
            analysisInProgress.set(false);
            showStatus("> Gagal menjalankan encoder: " + safeMessage(e));
        }
    }

    private void encodeAndSend(Bitmap bitmap) {
        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            boolean compressed = bitmap.compress(Bitmap.CompressFormat.JPEG, 65, output);
            if (!compressed) throw new IllegalStateException("Kompresi gambar gagal.");
            byte[] bytes = output.toByteArray();
            String base64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
            requestCount++;
            showStatus("> Menganalisis soal...");
            updateDeveloperInfo();

            GeminiHelper.askImage(getApplicationContext(), base64, false, new GeminiHelper.Callback() {
                @Override public void onSuccess(String result) {
                    analysisInProgress.set(false);
                    answerCache.put("last_image", result);
                    setResultText("> AI Menjawab: " + result);
                    
                    // --- LOGIKA KLIK OTOMATIS DI SINI ---
                    AutoKkmService autoKkm = AutoKkmService.getInstance();
                    if (autoKkm != null) {
                        autoKkm.performClickByText(result);
                    }
                    // ------------------------------------

                    updateDeveloperInfo();
                }
                @Override public void onError(String error) {
                    analysisInProgress.set(false);
                    if (error != null && error.toLowerCase(java.util.Locale.ROOT).contains("batas lokal harian")) {
                        stopAutoScan();
                        setResultText("> Auto Scan dihentikan. " + error);
                    } else {
                        setResultText("> Gagal: " + error);
                    }
                    updateDeveloperInfo();
                }
            });
        } catch (Exception e) {
            analysisInProgress.set(false);
            showStatus("> Gagal menyiapkan gambar: " + safeMessage(e));
        } finally {
            if (!bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private void askText(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String cached = answerCache.get(text);
        if (cached != null) {
            setResultText("> (Cache) " + cached);
            return;
        }
        setResultText("> Memproses teks...");
        GeminiHelper.askText(getApplicationContext(), text, false, new GeminiHelper.Callback() {
            @Override public void onSuccess(String result) {
                answerCache.put(text, result);
                setResultText("> " + result);
                updateDeveloperInfo();
            }
            @Override public void onError(String error) {
                setResultText("> Error: " + error);
                updateDeveloperInfo();
            }
        });
    }

    private void updateDeveloperInfo() {
        if (textDevInfo == null) return;
        mainHandler.post(() -> {
            if (textDevInfo != null) {
                textDevInfo.setText("Sesi: Aktif | Capture: " + requestCount + " | " + UsageMonitor.summary(this).replace('\n', ' '));
            }
        });
    }

    private void setResultText(String text) {
        mainHandler.post(() -> {
            if (textResult != null) textResult.setText(text == null ? "" : text);
        });
    }

    private void showStatus(String text) {
        setResultText(text);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String safeMessage(Exception e) {
        String message = e == null ? null : e.getMessage();
        if (message == null || message.trim().isEmpty()) return "kesalahan tidak diketahui";
        return message.length() > 160 ? message.substring(0, 160) : message;
    }

    private void setupFloatingBot() {
        if (!Settings.canDrawOverlays(this)) {
            showStatus("Izin overlay tidak aktif. Buka pengaturan untuk memberikan izin.");
            return;
        }

        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = dp(24);
        layoutParams.y = dp(120);

        mainContainer = new LinearLayout(this);
        mainContainer.setOrientation(LinearLayout.VERTICAL);
        mainContainer.setPadding(dp(4), dp(4), dp(4), dp(4));
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#CC000000"));
        bg.setCornerRadius(dp(16));
        mainContainer.setBackground(bg);

        FrameLayout dragHandle = new FrameLayout(this);
        dragHandle.setLayoutParams(new LinearLayout.LayoutParams(dp(56), dp(56)));
        botImage = new ImageView(this);
        botImage.setImageResource(android.R.drawable.ic_menu_search); 
        botImage.setColorFilter(Color.parseColor("#00FF75")); 
        dragHandle.addView(botImage, new FrameLayout.LayoutParams(-1, -1));
        mainContainer.addView(dragHandle);

        menuLayout = new LinearLayout(this);
        menuLayout.setOrientation(LinearLayout.VERTICAL);
        menuLayout.setVisibility(View.GONE);
        menuLayout.setPadding(dp(8), dp(8), dp(8), dp(8));

        textResult = new TextView(this);
        textResult.setTextColor(Color.WHITE);
        textResult.setTextSize(12);
        textResult.setText("> Menunggu perintah...");
        textResult.setMaxWidth(dp(200));
        menuLayout.addView(textResult);

        textDevInfo = new TextView(this);
        textDevInfo.setTextColor(Color.LTGRAY);
        textDevInfo.setTextSize(10);
        textDevInfo.setText("Sesi: Aktif | Capture: 0");
        menuLayout.addView(textDevInfo);

        autoScanButton = new Button(this);
        autoScanButton.setText("▶ AUTO SCAN: OFF");
        autoScanButton.setTextSize(11);
        autoScanButton.setBackgroundColor(Color.parseColor("#333333"));
        autoScanButton.setTextColor(Color.parseColor("#00FF75"));
        autoScanButton.setOnClickListener(v -> {
            if (autoScanEnabled) stopAutoScan();
            else startAutoScan();
            startClickAnimation();
        });
        menuLayout.addView(autoScanButton);

        Button btnText = new Button(this);
        btnText.setText("Ketik Manual (Tanya)");
        btnText.setTextSize(11);
        btnText.setBackgroundColor(Color.parseColor("#333333"));
        btnText.setTextColor(Color.WHITE);
        btnText.setOnClickListener(v -> showTextInputDialog());
        menuLayout.addView(btnText);

        Button btnHide = new Button(this);
        btnHide.setText("Sembunyikan");
        btnHide.setTextSize(11);
        btnHide.setBackgroundColor(Color.parseColor("#FF4444"));
        btnHide.setTextColor(Color.WHITE);
        btnHide.setOnClickListener(v -> setFloatingVisible(false));
        menuLayout.addView(btnHide);

        mainContainer.addView(menuLayout, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dragHandle.setOnClickListener(v -> toggleMenu());
        dragHandle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = layoutParams.x;
                        initialY = layoutParams.y;
                        initialTouchX = (int) event.getRawX();
                        initialTouchY = (int) event.getRawY();
                        dragging = false;
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        int deltaX = (int) event.getRawX() - initialTouchX;
                        int deltaY = (int) event.getRawY() - initialTouchY;
                        if (Math.abs(deltaX) > CLICK_THRESHOLD || Math.abs(deltaY) > CLICK_THRESHOLD) {
                            dragging = true;
                            layoutParams.x = initialX + deltaX;
                            layoutParams.y = initialY + deltaY;
                            try { windowManager.updateViewLayout(mainContainer, layoutParams); }
                            catch (Exception ignored) { }
                        }
                        return false;
                    default:
                        return false;
                }
            }
        });

        try {
            windowManager.addView(mainContainer, layoutParams);
            startFloatingAnimation();
        } catch (Exception e) {
            showStatus("Gagal menampilkan floating bot: " + safeMessage(e));
        }
    }

    private void releaseCaptureResources(boolean stopProjection) {
        stopAutoScan();
        stopFloatingAnimation();
        if (clickAnimator != null) {
            clickAnimator.cancel();
            clickAnimator = null;
        }
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Exception ignored) { }
            virtualDisplay = null;
        }
        if (imageReader != null) {
            try { imageReader.setOnImageAvailableListener(null, null); } catch (Exception ignored) { }
            try { imageReader.close(); } catch (Exception ignored) { }
            imageReader = null;
        }
        if (mainContainer != null && windowManager != null) {
            try {
                if (mainContainer.getParent() != null) windowManager.removeViewImmediate(mainContainer);
            } catch (Exception ignored) { }
            mainContainer = null;
        }
        botContainer = null;
        botImage = null;
        menuLayout = null;
        textResult = null;
        textDevInfo = null;
        autoScanButton = null;

        if (stopProjection && mediaProjection != null && !projectionStopped) {
            projectionStopped = true;
            try {
                if (projectionCallback != null) mediaProjection.unregisterCallback(projectionCallback);
            } catch (Exception ignored) { }
            try { mediaProjection.stop(); } catch (Exception ignored) { }
        }
        if (stopProjection) mediaProjection = null;
        if (captureExecutor != null && !captureExecutor.isShutdown()) captureExecutor.shutdownNow();
    }

    @Override
    public void onDestroy() {
        active = false;
        projectionActive = false;
        if (instance == this) instance = null;
        releaseCaptureResources(true);
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
