package com.cbt.helper;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;

public class ScreenModeService extends Service {
    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader reader;
    private WindowManager wm;
    
    private LinearLayout mainContainer;
    private FrameLayout botContainer;
    private ImageView botImage;
    private LinearLayout menuLayout;
    private TextView textResult;
    private TextView textDevInfo; 
    
    private boolean isMenuOpen = false;
    private boolean isAutoScanActive = false;
    private Handler autoScanHandler = new Handler(Looper.getMainLooper());

    private HashMap<String, String> memoriJawaban = new HashMap<>();
    private int requestCount = 0;

    private WindowManager.LayoutParams layoutParams;
    private float initialX, initialY;
    private int initialTouchX, initialTouchY;
    private boolean isDragging = false;
    private static final int CLICK_THRESHOLD = 10;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        
        Notification notification = new Notification.Builder(this, "svc")
                .setContentTitle("Bot Assist Aktif")
                .setSmallIcon(android.R.drawable.ic_menu_camera).build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, notification);
        }

        int code = intent.getIntExtra("code", 0);
        Intent data = intent.getParcelableExtra("data");
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        
        try {
            mp = mpm.getMediaProjection(code, data);
        } catch (Exception e) {
            e.printStackTrace();
            stopSelf();
            return START_NOT_STICKY;
        }

        setupFloatingBot();
        setupVirtualDisplay();

        return START_STICKY;
    }

    private void setupFloatingBot() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        mainContainer = new LinearLayout(this);
        mainContainer.setOrientation(LinearLayout.VERTICAL);
        mainContainer.setGravity(Gravity.CENTER);

        botContainer = new FrameLayout(this);
        botImage = new ImageView(this);
        
        botImage.setImageResource(R.drawable.bot_lucu); 
        botImage.setScaleType(ImageView.ScaleType.FIT_CENTER); 
        
        int sizeInDp = 80;
        float scale = getResources().getDisplayMetrics().density;
        int sizeInPx = (int) (sizeInDp * scale + 0.5f);
        FrameLayout.LayoutParams imgParams = new FrameLayout.LayoutParams(sizeInPx, sizeInPx);
        botImage.setLayoutParams(imgParams);

        botContainer.addView(botImage);
        startAnimasiMelayang();

        botContainer.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = layoutParams.x; initialY = layoutParams.y;
                        initialTouchX = (int) event.getRawX(); initialTouchY = (int) event.getRawY();
                        isDragging = false;
                        botImage.clearAnimation();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int deltaX = (int) event.getRawX() - initialTouchX;
                        int deltaY = (int) event.getRawY() - initialTouchY;
                        if (Math.abs(deltaX) > CLICK_THRESHOLD || Math.abs(deltaY) > CLICK_THRESHOLD) isDragging = true;
                        if (isDragging) {
                            layoutParams.x = (int) initialX + deltaX;
                            layoutParams.y = (int) initialY + deltaY;
                            wm.updateViewLayout(mainContainer, layoutParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDragging) {
                            startAnimasiKlik();
                            toggleMenu();
                        } else {
                            startAnimasiMelayang();
                        }
                        return true;
                }
                return false;
            }
        });

        menuLayout = new LinearLayout(this);
        menuLayout.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(30f);
        shape.setColor(Color.parseColor("#EE121212"));
        menuLayout.setBackground(shape);
        menuLayout.setPadding(30, 30, 30, 30);
        menuLayout.setVisibility(View.GONE);

        textDevInfo = new TextView(this);
        textDevInfo.setText("Requests: 0 | Quota: Safe");
        textDevInfo.setTextColor(Color.GRAY);
        textDevInfo.setTextSize(10);
        textDevInfo.setPadding(0, 0, 0, 10);

        Button btnAutoScan = new Button(this);
        btnAutoScan.setText("▶ AUTO SCAN: OFF");
        btnAutoScan.setTextColor(Color.YELLOW);
        btnAutoScan.setBackgroundColor(Color.TRANSPARENT);
        btnAutoScan.setOnClickListener(v -> {
            isAutoScanActive = !isAutoScanActive;
            btnAutoScan.setText(isAutoScanActive ? "⏸ AUTO SCAN: ON" : "▶ AUTO SCAN: OFF");
            if (isAutoScanActive) startAutoScan(); else stopAutoScan();
        });

        Button btnGambar = new Button(this);
        btnGambar.setText("📸 SCAN SEKARANG");
        btnGambar.setTextColor(Color.GREEN);
        btnGambar.setBackgroundColor(Color.TRANSPARENT);
        btnGambar.setOnClickListener(v -> { textResult.setText("> Menganalisa..."); captureScreen(); });

        Button btnTeks = new Button(this);
        btnTeks.setText("⌨ INPUT SOAL UJIAN");
        btnTeks.setTextColor(Color.CYAN);
        btnTeks.setBackgroundColor(Color.TRANSPARENT);
        btnTeks.setOnClickListener(v -> showTextInputDialog());

        SeekBar sliderAlpha = new SeekBar(this);
        sliderAlpha.setMax(100);
        sliderAlpha.setProgress(100);
        sliderAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                botImage.setAlpha(progress / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        textResult = new TextView(this);
        textResult.setText("> Ready...");
        textResult.setTextColor(Color.WHITE);
        textResult.setTextSize(12);
        textResult.setPadding(0, 10, 0, 0);

        menuLayout.addView(textDevInfo);
        menuLayout.addView(btnAutoScan);
        menuLayout.addView(btnGambar); 
        menuLayout.addView(btnTeks);
        menuLayout.addView(sliderAlpha);
        menuLayout.addView(textResult);
        
        mainContainer.addView(botContainer); 
        mainContainer.addView(menuLayout);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        layoutParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = 100; layoutParams.y = 200;
        wm.addView(mainContainer, layoutParams);
    }

    private Runnable autoScanRunnable = new Runnable() {
        @Override
        public void run() {
            if (isAutoScanActive) {
                captureScreen();
                autoScanHandler.postDelayed(this, 5000); 
            }
        }
    };

    private void startAutoScan() {
        autoScanHandler.post(autoScanRunnable);
        textResult.setText("> Auto Scan Aktif...");
    }

    private void stopAutoScan() {
        autoScanHandler.removeCallbacks(autoScanRunnable);
        textResult.setText("> Auto Scan Nonaktif...");
    }

    private void toggleMenu() {
        isMenuOpen = !isMenuOpen;
        menuLayout.setVisibility(isMenuOpen ? View.VISIBLE : View.GONE);
    }

    private void showTextInputDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Input Soal Ujian");
        final EditText input = new EditText(this);
        input.setTextColor(Color.BLACK);
        builder.setView(input);
        builder.setPositiveButton("TANYA", (dialog, which) -> {
            String soal = input.getText().toString();
            if(memoriJawaban.containsKey(soal)) {
                textResult.setText("> (Memori) " + memoriJawaban.get(soal));
            } else {
                tanyaAI(soal);
            }
        });
        builder.show();
    }

    private void startAnimasiMelayang() {
        android.animation.ObjectAnimator animator = android.animation.ObjectAnimator.ofFloat(botImage, "translationY", -20f, 20f);
        animator.setDuration(1500);
        animator.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        animator.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        animator.start();
    }

    private void startAnimasiKlik() {
        android.animation.ObjectAnimator scaleX = android.animation.ObjectAnimator.ofFloat(botImage, "scaleX", 1f, 0.8f, 1f);
        android.animation.ObjectAnimator scaleY = android.animation.ObjectAnimator.ofFloat(botImage, "scaleY", 1f, 0.8f, 1f);
        scaleX.setDuration(300); scaleY.setDuration(300);
        scaleX.start(); scaleY.start();
        scaleY.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) { startAnimasiMelayang(); }
        });
    }

    private void setupVirtualDisplay() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        reader = ImageReader.newInstance(dm.widthPixels / 2, dm.heightPixels / 2, PixelFormat.RGBA_8888, 2);
        vd = mp.createVirtualDisplay("ScreenCapture", dm.widthPixels / 2, dm.heightPixels / 2, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
    }

    private void captureScreen() {
        Image img = reader.acquireLatestImage();
        if (img == null) return;
        try {
            ByteBuffer buffer = img.getPlanes()[0].getBuffer();
            Bitmap bmp = Bitmap.createBitmap(img.getWidth(), img.getHeight(), Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buffer);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 60, baos);
            String base64Img = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
            
            requestCount++; 
            textDevInfo.setText("Requests: " + requestCount + " | API Safe");

            GeminiHelper.askImage(base64Img, false, new GeminiHelper.Callback() {
                @Override public void onSuccess(String result) { 
                    textResult.setText("> " + result); 
                }
                @Override public void onError(String error) { 
                    textResult.setText("> Gagal: " + error); 
                    if(error.contains("429")) {
                        textDevInfo.setText("WARNING: API Rate Limit!");
                        textDevInfo.setTextColor(Color.RED);
                    }
                }
            });
        } finally { img.close(); }
    }

    private void tanyaAI(String soal) {
        textResult.setText("> Memproses...");
        GeminiHelper.askText(soal, false, new GeminiHelper.Callback() {
            @Override public void onSuccess(String result) { 
                memoriJawaban.put(soal, result);
                textResult.setText("> " + result); 
            }
            @Override public void onError(String error) { 
                textResult.setText("> Error: " + error); 
            }
        });
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("svc", "Service", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopAutoScan();
        if (vd != null) vd.release();
        if (mp != null) mp.stop();
        if (mainContainer != null && wm != null) wm.removeView(mainContainer);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}